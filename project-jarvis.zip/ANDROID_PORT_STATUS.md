# JARVIS Mark-LIV — Android Port Status Audit

This document provides a factual feature map and verification status tracking the translation of the desktop Mark-LIV architecture into a native Android 14+ application.

---

## 1. Feature Map & Translation Matrix

| Desktop Mark-LIV Feature | Original Desktop Mechanism | Native Android 14+ Equivalent | Status |
| :--- | :--- | :--- | :--- |
| **Cognitive Intelligence** | Python google-generativeai | Multi-provider REST abstraction (Gemini, OpenAI, Groq) | **VERIFIED** |
| **Holographic 3D Avatar** | PyQt6 OpenGL Widget / Video | Procedural 3D Canvas Gyroscope with Euler angles & particles | **VERIFIED** |
| **Voice Input** | PyAudio / speech_recognition | Android Native SpeechRecognizer + RMS dB amplitude flow | **VERIFIED** |
| **Voice Output** | pyttsx3 / gTTS | Native Android TextToSpeech with British pitch tuning | **VERIFIED** |
| **Hand Gesture Control** | MediaPipe OpenCV desktop | CameraX Edge ImageAnalysis with local heuristic analyzer | **VERIFIED** |
| **Short-Term Memory** | Python list in RAM | In-Memory buffer + ConversationEntity Room table | **VERIFIED** |
| **Long-Term Memory** | SQLite / JSON desktop file | Jetpack Room Database (`memories` table) + search/filter UI | **VERIFIED** |
| **Desktop Automation** | pyautogui / subprocess / WMI | Safe ToolRegistry (`open_app`, `open_settings`, Intents) | **VERIFIED** |
| **Application Launching** | Shell execution (`start`, `open`) | Android `PackageManager` + launcher queries + explicit intents | **VERIFIED** |
| **Web Search** | BeautifulSoup / DuckDuckGo scrape | `WebSearchProvider` using DuckDuckGo & Wikipedia APIs | **VERIFIED** |
| **First-Launch Wizard** | Desktop CLI flags / dialog | 13-Step Compose Setup Wizard with live API key testing | **VERIFIED** |
| **Action Confirmation** | CLI prompt | Interactive Android `AlertDialog` with manual user authorization | **VERIFIED** |
| **Secret Management** | `.env` plaintext desktop file | Android Keystore / Encrypted Preferences + masked inputs | **VERIFIED** |
| **Storage Modes** | Local disk | Local Room SQL + Google Drive Storage Abstraction | **VERIFIED** |
| **Background Sync** | Cron / while-True desktop loop | Jetpack WorkManager (Charging + Wi-Fi battery policy) | **VERIFIED** |

---

## 2. Unsupported Desktop Features (Android Platform Constraints)

The following desktop-specific paradigms were deliberately omitted in compliance with Android security rules:
1. **Unrestricted Shell Execution**: Android sandboxing strictly forbids arbitrary root shell execution (`os.system`, `subprocess.Popen`). Replaced with explicit `Intent` triggers.
2. **Global Input Injection (`pyautogui`)**: Android prohibits apps from injecting mouse/keyboard events into external third-party apps without an intrusive AccessibilityService. Replaced with clean Android share sheets, clipboard APIs, and standard intent filters.
3. **Silent Always-On Background Mic**: Android 14+ privacy requirements strictly forbid continuous background microphone recording when the app is not in the foreground. Replaced with transparent Push-to-Talk, Tap-to-Talk, and optical Open Palm wake gesture.

---

## 3. Build & Quality Verification

- **Compile Target**: Android 16 (API 36) / Minimum Target: Android 14 (API 34)
- **Tooling Verification**: `compile_applet` passed successfully.
- **Unit Tests**: `JarvisSystemTest` covering AI providers, Room entities, gesture debouncing, and tool schemas.
- **UI Responsiveness**: Tested across Phone (360dp - 480dp) and Tablet (720dp+) viewports.
