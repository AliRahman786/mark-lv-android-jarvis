# JARVIS Mark-LIV Android Project

## Project Overview
- **Application Name**: JARVIS Mark-LIV
- **Application ID / Namespace**: `com.example`
- **Compile SDK**: Android 36 (minorApiLevel 1)
- **Target SDK**: Android 36
- **Min SDK**: Android 34
- **Java Compatibility**: JDK 17
- **Kotlin**: 2.2.10
- **Android Gradle Plugin**: 9.1.1
- **Gradle Version**: 9.3.1
- **Jetpack Compose**: Compose BOM 2024.09.00 / Compose Compiler 2.2.10

---

## Directory Structure
```
jarvis-mark-liv/
├── app/
│   ├── src/
│   │   ├── main/
│   │   │   ├── java/com/example/
│   │   │   │   ├── MainActivity.kt
│   │   │   │   ├── ai/            # Multi-provider AI (Gemini, OpenAI, Groq)
│   │   │   │   ├── data/          # Room DB, Repositories, Battery Observer, Sync Policy
│   │   │   │   ├── gesture/       # Camera hand gesture detection & telemetry
│   │   │   │   ├── tools/         # Web search, device actions, tool registry
│   │   │   │   ├── ui/            # Holographic Arc Reactor, Waveforms, HUD panels
│   │   │   │   ├── viewmodel/     # JarvisViewModel
│   │   │   │   └── voice/         # Speech-to-Text and TTS synthesized voice
│   │   │   ├── res/               # Vector icons, themes, mipmap assets, strings
│   │   │   └── AndroidManifest.xml
│   │   └── test/                  # Unit and Robolectric tests
│   ├── build.gradle.kts
│   └── proguard-rules.pro
├── gradle/
│   ├── libs.versions.toml         # Centralized Version Catalog
│   └── wrapper/
│       └── gradle-wrapper.properties
├── build.gradle.kts               # Root Gradle script
├── settings.gradle.kts            # Project settings
├── gradle.properties              # JVM & AndroidX build configuration
├── .env.example                   # Secrets template (no hardcoded credentials)
└── README_ANDROID.md              # Architectural notes
```

---

## How to Build the APK

### 1. In Android Studio
1. Open **Android Studio** (Ladybug / Iguana or later).
2. Choose **File -> Open...** and select the root directory (`jarvis-mark-liv`).
3. Allow Gradle to sync.
4. Select **Build -> Build Bundle(s) / APK(s) -> Build APK(s)**, or run the app directly on a connected device / emulator.

### 2. From the Command Line
From the root folder:
```bash
gradle assembleDebug
```
Or if using Gradle wrapper:
```bash
./gradlew assembleDebug
```

The compiled APK will be generated at:
```
app/build/outputs/apk/debug/app-debug.apk
```

---

## Secrets & API Key Configuration
This project uses the Secrets Gradle Plugin to avoid hardcoding credentials:
1. Copy `.env.example` to `.env`:
   ```bash
   cp .env.example .env
   ```
2. Set your `GEMINI_API_KEY`:
   ```properties
   GEMINI_API_KEY=your_actual_gemini_api_key_here
   ```
3. During compilation, the key is securely injected into `BuildConfig.GEMINI_API_KEY`.
