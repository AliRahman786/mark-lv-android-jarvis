package com.example

import com.example.ai.AiNetworkUtils
import com.example.ai.AiResponse
import com.example.ai.ChatMessage
import com.example.ai.GeminiProvider
import com.example.ai.GroqProvider
import com.example.ai.OpenAiProvider
import com.example.ai.ToolCallRequest
import com.example.data.model.ConversationEntity
import com.example.data.model.MemoryEntity
import com.example.data.model.ReminderEntity
import com.example.data.prefs.PreferencesManager
import com.example.gesture.GestureController
import com.example.gesture.GestureType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.net.SocketTimeoutException
import java.net.UnknownHostException

class JarvisSystemTest {

    @Test
    fun testMemoryEntityDefaults() {
        val memory = MemoryEntity(
            content = "User preference: Iron Man Armor Mark-LIV",
            category = MemoryEntity.CATEGORY_PREFERENCE,
            tags = "armor,suit,tactical",
            importance = 3
        )

        assertEquals("User preference: Iron Man Armor Mark-LIV", memory.content)
        assertEquals(MemoryEntity.CATEGORY_PREFERENCE, memory.category)
        assertEquals("armor,suit,tactical", memory.tags)
        assertEquals(3, memory.importance)
        assertTrue(memory.createdAt > 0L)
        assertTrue(memory.updatedAt > 0L)
    }

    @Test
    fun testConversationEntityCreation() {
        val message = ConversationEntity(
            sender = "USER",
            content = "What is the orbital trajectory of the ISS?"
        )

        assertEquals("USER", message.sender)
        assertEquals("What is the orbital trajectory of the ISS?", message.content)
        assertNull(message.toolName)
        assertNull(message.toolArgs)
        assertNull(message.toolResult)
        assertNull(message.imageUrl)
    }

    @Test
    fun testConversationEntityToolMetadata() {
        val toolMessage = ConversationEntity(
            sender = "JARVIS",
            content = "Coordinates located for Stark Tower.",
            toolName = "maps_search",
            toolArgs = "{\"location\":\"Stark Tower\"}",
            toolResult = "Targeting coordinates on Maps for: Stark Tower"
        )

        assertEquals("JARVIS", toolMessage.sender)
        assertEquals("maps_search", toolMessage.toolName)
        assertEquals("{\"location\":\"Stark Tower\"}", toolMessage.toolArgs)
        assertEquals("Targeting coordinates on Maps for: Stark Tower", toolMessage.toolResult)
    }

    @Test
    fun testReminderEntityCreation() {
        val reminder = ReminderEntity(
            title = "Calibrate quantum arc reactor",
            dueTimestamp = System.currentTimeMillis() + 3600000L,
            priority = "HIGH"
        )

        assertEquals("Calibrate quantum arc reactor", reminder.title)
        assertEquals("HIGH", reminder.priority)
        assertFalse(reminder.isCompleted)
    }

    @Test
    fun testAiProviderDefinitions() {
        val gemini = GeminiProvider()
        val openai = OpenAiProvider()
        val groq = GroqProvider()

        assertEquals("GEMINI", gemini.id)
        assertEquals("OPENAI", openai.id)
        assertEquals("GROQ", groq.id)

        assertEquals("gemini-3.5-flash", gemini.defaultModel)
        assertEquals("gpt-4o", openai.defaultModel)
        assertEquals("llama-3.3-70b-versatile", groq.defaultModel)

        assertTrue(gemini.supportedModels.contains("gemini-3.5-flash"))
        assertTrue(gemini.supportedModels.contains("gemini-3.1-pro-preview"))
        assertTrue(openai.supportedModels.contains("gpt-4o"))
        assertTrue(openai.supportedModels.contains("gpt-4o-mini"))
        assertTrue(groq.supportedModels.contains("llama-3.3-70b-versatile"))
        assertTrue(groq.supportedModels.contains("llama-3.1-8b-instant"))
    }

    @Test
    fun testAiNetworkUtilsRateLimit() {
        val errorJson = "{\"error\":{\"message\":\"Rate limit exceeded. Please wait.\"}}"
        val msg = AiNetworkUtils.parseErrorMessage("Gemini", 429, errorJson)
        assertTrue(msg.contains("Rate Limit Exceeded // 429"))
        assertTrue(msg.contains("Rate limit exceeded"))
    }

    @Test
    fun testAiNetworkUtilsAuthenticationError() {
        val errorJson = "{\"error\":{\"message\":\"API key not valid.\"}}"
        val msg = AiNetworkUtils.parseErrorMessage("OpenAI", 401, errorJson)
        assertTrue(msg.contains("Authentication Failed // 401"))
    }

    @Test
    fun testAiNetworkUtilsServerOutage() {
        val msg = AiNetworkUtils.parseErrorMessage("Groq", 503, "{}")
        assertTrue(msg.contains("Server Outage // 503"))
    }

    @Test
    fun testAiNetworkUtilsNetworkExceptions() {
        val timeoutEx = SocketTimeoutException("Read timed out")
        val timeoutMsg = AiNetworkUtils.parseException("Gemini", timeoutEx)
        assertTrue(timeoutMsg.contains("[Gemini Timeout]"))

        val offlineEx = UnknownHostException("Unable to resolve host")
        val offlineMsg = AiNetworkUtils.parseException("OpenAI", offlineEx)
        assertTrue(offlineMsg.contains("[OpenAI Offline]"))
    }

    @Test
    fun testGestureControllerStateAndCooldown() {
        val controller = GestureController()
        var triggeredAction: GestureType? = null
        controller.onGestureAction = { triggeredAction = it }

        // When camera is inactive, gestures should not trigger
        controller.setCameraActive(false)
        controller.onRawGestureDetected(GestureType.OPEN_PALM, 0.9f)
        assertNull(triggeredAction)

        // When camera is active, gesture triggers
        controller.setCameraActive(true)
        controller.onRawGestureDetected(GestureType.OPEN_PALM, 0.95f)
        assertEquals(GestureType.OPEN_PALM, triggeredAction)
        assertNotNull(controller.currentGesture.value)
        assertEquals(GestureType.OPEN_PALM, controller.currentGesture.value?.type)

        // Immediate subsequent gesture within cooldown window must be suppressed
        triggeredAction = null
        controller.onRawGestureDetected(GestureType.FIST, 0.9f)
        assertNull("Subsequent gesture must be debounced by cooldown window", triggeredAction)
    }

    @Test
    fun testGestureTypesEnum() {
        val palm = GestureType.OPEN_PALM
        val fist = GestureType.FIST
        val swipeLeft = GestureType.SWIPE_LEFT
        val swipeRight = GestureType.SWIPE_RIGHT
        val pinch = GestureType.PINCH_INDEX
        val twoFingers = GestureType.TWO_FINGERS

        assertEquals("Open Palm", palm.displayName)
        assertEquals("Closed Fist", fist.displayName)
        assertEquals("Swipe Left", swipeLeft.displayName)
        assertEquals("Swipe Right", swipeRight.displayName)
        assertEquals("Pinch Index", pinch.displayName)
        assertEquals("Two Fingers", twoFingers.displayName)
    }

    @Test
    fun testChatMessageAndToolCallDataClasses() {
        val call = ToolCallRequest(
            id = "call_123",
            name = "maps_search",
            argumentsJson = "{\"location\":\"Avengers Facility\"}"
        )
        val response = AiResponse(
            text = "Plotting trajectory.",
            toolCalls = listOf(call),
            isStreamingFinished = true
        )

        assertEquals("Plotting trajectory.", response.text)
        assertEquals(1, response.toolCalls.size)
        assertEquals("maps_search", response.toolCalls[0].name)
        assertEquals("call_123", response.toolCalls[0].id)
    }

    @Test
    fun testPreferencesManagerConstants() {
        assertEquals("GEMINI", PreferencesManager.PROVIDER_GEMINI)
        assertEquals("OPENAI", PreferencesManager.PROVIDER_OPENAI)
        assertEquals("GROQ", PreferencesManager.PROVIDER_GROQ)
        assertEquals("DEVICE", PreferencesManager.STORAGE_DEVICE)
        assertEquals("CLOUD_DRIVE", PreferencesManager.STORAGE_CLOUD_DRIVE)
    }

    @Test
    fun testWorkManagerSyncPolicyConstraints() {
        val constraints = com.example.data.sync.JarvisSyncPolicyManager.createBatteryOptimizedConstraints()
        assertTrue("Sync policy must require charging to preserve battery life", constraints.requiresCharging())
        assertTrue("Sync policy must require battery not low", constraints.requiresBatteryNotLow())
        assertEquals(
            "Sync policy must require unmetered Wi-Fi network",
            androidx.work.NetworkType.UNMETERED,
            constraints.requiredNetworkType
        )

        // Test configurable constraints
        val relaxedConstraints = com.example.data.sync.JarvisSyncPolicyManager.createBatteryOptimizedConstraints(
            requiresCharging = false,
            requiresWifi = false
        )
        assertFalse(relaxedConstraints.requiresCharging())
        assertEquals(androidx.work.NetworkType.CONNECTED, relaxedConstraints.requiredNetworkType)
    }

    @Test
    fun testMemoryMaintenanceSyncWorkerKeys() {
        assertEquals("maintained_memories", com.example.data.sync.MemoryMaintenanceSyncWorker.KEY_MAINTAINED_MEMORIES)
        assertEquals("processed_logs", com.example.data.sync.MemoryMaintenanceSyncWorker.KEY_PROCESSED_LOGS)
        assertEquals("sync_result", com.example.data.sync.MemoryMaintenanceSyncWorker.KEY_SYNC_RESULT)
        assertEquals("timestamp", com.example.data.sync.MemoryMaintenanceSyncWorker.KEY_TIMESTAMP)
        assertEquals("battery_status", com.example.data.sync.MemoryMaintenanceSyncWorker.KEY_BATTERY_STATUS)
        assertEquals("network_type", com.example.data.sync.MemoryMaintenanceSyncWorker.KEY_NETWORK_TYPE)
    }

    @Test
    fun testSyncPolicyPreferencesKeys() {
        assertEquals("sync_charging_required", PreferencesManager.KEY_SYNC_CHARGING_REQUIRED)
        assertEquals("sync_wifi_required", PreferencesManager.KEY_SYNC_WIFI_REQUIRED)
        assertEquals("sync_interval_hours", PreferencesManager.KEY_SYNC_INTERVAL_HOURS)
        assertEquals("last_sync_status", PreferencesManager.KEY_LAST_SYNC_STATUS)
        assertEquals("last_sync_maintained_count", PreferencesManager.KEY_LAST_SYNC_MAINTAINED_COUNT)
        assertEquals("last_sync_logs_count", PreferencesManager.KEY_LAST_SYNC_LOGS_COUNT)
    }

    @Test
    fun testToolRegistrySyncMaintenanceRegistration() {
        val fakeMemoryDao = object : com.example.data.dao.MemoryDao {
            override fun getAllMemories() = kotlinx.coroutines.flow.flowOf(emptyList<MemoryEntity>())
            override fun getMemoriesByCategory(category: String) = kotlinx.coroutines.flow.flowOf(emptyList<MemoryEntity>())
            override suspend fun searchMemories(query: String) = emptyList<MemoryEntity>()
            override suspend fun getRecentMemories(limit: Int) = emptyList<MemoryEntity>()
            override suspend fun insertMemory(memory: MemoryEntity) = 1L
            override suspend fun updateMemory(memory: MemoryEntity) {}
            override suspend fun deleteMemory(memory: MemoryEntity) {}
            override suspend fun deleteById(id: Long) {}
            override suspend fun clearAll() {}
            override fun count() = kotlinx.coroutines.flow.flowOf(0)
        }
        val fakeReminderDao = object : com.example.data.dao.ReminderDao {
            override fun getActiveReminders() = kotlinx.coroutines.flow.flowOf(emptyList<ReminderEntity>())
            override suspend fun insertReminder(reminder: ReminderEntity) = 1L
            override suspend fun markCompleted(id: Long) {}
            override suspend fun deleteById(id: Long) {}
            override suspend fun clearAll() {}
        }
        val memoryRepo = com.example.data.repository.MemoryRepository(fakeMemoryDao)
        val reminderRepo = com.example.data.repository.ReminderRepository(fakeReminderDao)
        val webSearch = com.example.tools.WebSearchProvider()
        val deviceActionManager = com.example.tools.DeviceActionManager()

        val registry = com.example.tools.ToolRegistry(deviceActionManager, webSearch, memoryRepo, reminderRepo)
        val defs = registry.getAllDefinitions()
        val syncTool = defs.firstOrNull { it.name == "sync_maintenance" }
        assertNotNull("sync_maintenance tool must be registered in ToolRegistry", syncTool)
        assertEquals("sync_maintenance", syncTool?.name)
    }

    @Test
    fun testBatteryThrottlePreferencesKeys() {
        assertEquals("ai_throttling_enabled", PreferencesManager.KEY_AI_THROTTLING_ENABLED)
        assertEquals("battery_low_threshold", PreferencesManager.KEY_BATTERY_LOW_THRESHOLD)
        assertEquals("battery_critical_threshold", PreferencesManager.KEY_BATTERY_CRITICAL_THRESHOLD)
    }

    @Test
    fun testBatteryPowerStateAndThrottleEnums() {
        val state = com.example.data.battery.BatteryPowerState(
            level = 85,
            isCharging = true,
            isPlugged = true,
            pluggedSource = com.example.data.battery.PluggedSource.AC_MAINS,
            pluggedSourceLabel = "AC MAINS",
            statusDescription = "CHARGING",
            health = com.example.data.battery.BatteryHealth.GOOD,
            temperatureCelsius = 28.5f,
            voltageMv = 4150,
            isPowerSaveMode = false,
            isBatteryLow = false,
            isCriticalBattery = false,
            throttleLevel = com.example.data.battery.AiThrottleLevel.UNCONSTRAINED,
            throttleReason = "Connected to AC MAINS. Peak neural acceleration allotted."
        )

        assertEquals(85, state.level)
        assertTrue(state.isCharging)
        assertTrue(state.isPlugged)
        assertTrue(state.isOptimalForHeavyAi)
        assertTrue(state.canExecuteHeavyAi)
        assertEquals(com.example.data.battery.AiThrottleLevel.UNCONSTRAINED, state.throttleLevel)
        assertEquals("AI: PEAK", state.throttleLevel.badgeLabel)
    }

    @Test
    fun testToolRegistryBatteryPowerDiagnosticsRegistration() {
        val fakeMemoryDao = object : com.example.data.dao.MemoryDao {
            override fun getAllMemories() = kotlinx.coroutines.flow.flowOf(emptyList<MemoryEntity>())
            override fun getMemoriesByCategory(category: String) = kotlinx.coroutines.flow.flowOf(emptyList<MemoryEntity>())
            override suspend fun searchMemories(query: String) = emptyList<MemoryEntity>()
            override suspend fun getRecentMemories(limit: Int) = emptyList<MemoryEntity>()
            override suspend fun insertMemory(memory: MemoryEntity) = 1L
            override suspend fun updateMemory(memory: MemoryEntity) {}
            override suspend fun deleteMemory(memory: MemoryEntity) {}
            override suspend fun deleteById(id: Long) {}
            override suspend fun clearAll() {}
            override fun count() = kotlinx.coroutines.flow.flowOf(0)
        }
        val fakeReminderDao = object : com.example.data.dao.ReminderDao {
            override fun getActiveReminders() = kotlinx.coroutines.flow.flowOf(emptyList<ReminderEntity>())
            override suspend fun insertReminder(reminder: ReminderEntity) = 1L
            override suspend fun markCompleted(id: Long) {}
            override suspend fun deleteById(id: Long) {}
            override suspend fun clearAll() {}
        }
        val memoryRepo = com.example.data.repository.MemoryRepository(fakeMemoryDao)
        val reminderRepo = com.example.data.repository.ReminderRepository(fakeReminderDao)
        val webSearch = com.example.tools.WebSearchProvider()
        val deviceActionManager = com.example.tools.DeviceActionManager()

        val registry = com.example.tools.ToolRegistry(deviceActionManager, webSearch, memoryRepo, reminderRepo)
        val defs = registry.getAllDefinitions()
        val batteryTool = defs.firstOrNull { it.name == "battery_power_diagnostics" }
        assertNotNull("battery_power_diagnostics tool must be registered in ToolRegistry", batteryTool)
        assertEquals("battery_power_diagnostics", batteryTool?.name)
    }
}
