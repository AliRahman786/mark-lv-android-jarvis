package com.example.tools

import com.example.ai.ToolDefinition
import com.example.ai.ToolParameter
import com.example.data.battery.SystemBatteryObserver
import com.example.data.prefs.PreferencesManager
import com.example.data.repository.MemoryRepository
import com.example.data.repository.ReminderRepository
import com.example.data.sync.JarvisSyncPolicyManager
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ToolRegistry(
    private val deviceActionManager: DeviceActionManager,
    private val webSearchProvider: WebSearchProvider,
    private val memoryRepository: MemoryRepository,
    private val reminderRepository: ReminderRepository,
    private val syncPolicyManager: JarvisSyncPolicyManager? = null,
    private val prefs: PreferencesManager? = null,
    private val batteryObserver: SystemBatteryObserver? = null
) {

    data class ToolExecutionResult(
        val toolName: String,
        val resultText: String,
        val requiresConfirmation: Boolean = false,
        val confirmationPrompt: String? = null
    )

    private val tools = mutableMapOf<String, ToolDefinition>()

    init {
        registerTools()
    }

    private fun registerTools() {
        tools["web_search"] = ToolDefinition(
            name = "web_search",
            description = "Search the live web and encyclopedias for real-time information, research, news, or facts.",
            parameters = listOf(
                ToolParameter("query", "string", "The search terms or question to look up", required = true)
            )
        )

        tools["open_app"] = ToolDefinition(
            name = "open_app",
            description = "Launch an installed Android application by name (e.g., YouTube, Chrome, Maps, Settings, Camera).",
            parameters = listOf(
                ToolParameter("app_name", "string", "The name of the app to launch", required = true)
            )
        )

        tools["open_url"] = ToolDefinition(
            name = "open_url",
            description = "Open an internet web address in the device's default web browser.",
            parameters = listOf(
                ToolParameter("url", "string", "The complete URL to open", required = true)
            )
        )

        tools["maps_search"] = ToolDefinition(
            name = "maps_search",
            description = "Locate places, navigation directions, or coordinates on Google Maps.",
            parameters = listOf(
                ToolParameter("location", "string", "Destination or location query", required = true)
            )
        )

        tools["youtube_search"] = ToolDefinition(
            name = "youtube_search",
            description = "Search videos on YouTube or launch playback query.",
            parameters = listOf(
                ToolParameter("query", "string", "Video title, topic, or search term", required = true)
            )
        )

        tools["clipboard_copy"] = ToolDefinition(
            name = "clipboard_copy",
            description = "Copy text or data to the Android system clipboard.",
            parameters = listOf(
                ToolParameter("text", "string", "Text content to copy", required = true)
            )
        )

        tools["share_text"] = ToolDefinition(
            name = "share_text",
            description = "Open the Android Share Sheet to transmit text or notes to other apps or contacts.",
            parameters = listOf(
                ToolParameter("text", "string", "Text content to share", required = true)
            )
        )

        tools["device_info"] = ToolDefinition(
            name = "device_info",
            description = "Retrieve live device diagnostic telemetry including battery, RAM, network status, and OS version.",
            parameters = emptyList()
        )

        tools["save_memory"] = ToolDefinition(
            name = "save_memory",
            description = "Permanently store a user preference, project detail, or important fact into JARVIS long-term memory.",
            parameters = listOf(
                ToolParameter("fact", "string", "The key information to remember permanently", required = true),
                ToolParameter("category", "string", "Category: FACT, PREFERENCE, PROJECT, USER", required = false)
            )
        )

        tools["recall_memory"] = ToolDefinition(
            name = "recall_memory",
            description = "Search long-term memory archives for relevant past facts or user preferences.",
            parameters = listOf(
                ToolParameter("keyword", "string", "Keyword to search stored memories for", required = true)
            )
        )

        tools["create_reminder"] = ToolDefinition(
            name = "create_reminder",
            description = "Set a scheduled task reminder with title and relative minutes.",
            parameters = listOf(
                ToolParameter("title", "string", "Reminder task description", required = true),
                ToolParameter("minutes_from_now", "number", "Delay in minutes before reminder triggers", required = false)
            )
        )

        tools["list_reminders"] = ToolDefinition(
            name = "list_reminders",
            description = "Retrieve all active scheduled reminders from the system database.",
            parameters = emptyList()
        )

        tools["calculator"] = ToolDefinition(
            name = "calculator",
            description = "Calculate math expressions safely.",
            parameters = listOf(
                ToolParameter("expression", "string", "Mathematical expression to evaluate", required = true)
            )
        )

        tools["time_weather"] = ToolDefinition(
            name = "time_weather",
            description = "Get current local time, date, time zone, and atmospheric estimate.",
            parameters = emptyList()
        )

        tools["open_settings"] = ToolDefinition(
            name = "open_settings",
            description = "Open Android system settings console.",
            parameters = emptyList()
        )

        tools["delete_all_memories"] = ToolDefinition(
            name = "delete_all_memories",
            description = "Purge all records from the long-term memory archive. Requires explicit confirmation.",
            parameters = emptyList()
        )

        tools["format_storage"] = ToolDefinition(
            name = "format_storage",
            description = "Reset and purge all local session logs and memory matrices. Requires explicit confirmation.",
            parameters = emptyList()
        )

        tools["sync_maintenance"] = ToolDefinition(
            name = "sync_maintenance",
            description = "Inspect or trigger WorkManager battery-optimized memory maintenance and log upload sync.",
            parameters = listOf(
                ToolParameter("action", "string", "Action: 'status' to check policy/readiness, 'queue' to schedule with constraints, or 'force' for immediate sync", required = false)
            )
        )

        tools["battery_power_diagnostics"] = ToolDefinition(
            name = "battery_power_diagnostics",
            description = "Retrieve live Arc Reactor battery telemetry, charging bus state, cell temperature, and dynamic AI throttling profile.",
            parameters = emptyList()
        )
    }

    fun getAllDefinitions(): List<ToolDefinition> = tools.values.toList()

    fun isConsequentialAction(name: String): Boolean {
        return name == "delete_all_memories" || name == "format_storage"
    }

    suspend fun executeTool(name: String, argumentsJson: String): ToolExecutionResult {
        val args = try {
            JSONObject(argumentsJson)
        } catch (_: Exception) {
            JSONObject()
        }

        return when (name) {
            "web_search" -> {
                val query = args.optString("query", "")
                val result = webSearchProvider.searchWeb(query)
                ToolExecutionResult(name, result)
            }
            "open_app" -> {
                val appName = args.optString("app_name", "")
                val result = deviceActionManager.openApp(appName)
                ToolExecutionResult(name, result)
            }
            "open_url" -> {
                val url = args.optString("url", "")
                val result = deviceActionManager.openUrl(url)
                ToolExecutionResult(name, result)
            }
            "maps_search" -> {
                val loc = args.optString("location", "")
                val result = deviceActionManager.openMaps(loc)
                ToolExecutionResult(name, result)
            }
            "youtube_search" -> {
                val q = args.optString("query", "")
                val result = deviceActionManager.openYouTube(q)
                ToolExecutionResult(name, result)
            }
            "clipboard_copy" -> {
                val txt = args.optString("text", "")
                val result = deviceActionManager.copyToClipboard("JARVIS Buffer", txt)
                ToolExecutionResult(name, result)
            }
            "share_text" -> {
                val txt = args.optString("text", "")
                val result = deviceActionManager.shareText("JARVIS Intel", txt)
                ToolExecutionResult(name, result)
            }
            "device_info" -> {
                val result = deviceActionManager.getDeviceInfo()
                ToolExecutionResult(name, result)
            }
            "save_memory" -> {
                val fact = args.optString("fact", "")
                val cat = args.optString("category", "FACT").uppercase(Locale.getDefault())
                val id = memoryRepository.saveMemory(content = fact, category = cat)
                ToolExecutionResult(name, "Fact committed to long-term memory archive [Record #$id: $fact].")
            }
            "recall_memory" -> {
                val kw = args.optString("keyword", "")
                val matches = memoryRepository.searchMemories(kw)
                val out = if (matches.isEmpty()) {
                    "No memories found matching keyword '$kw'."
                } else {
                    matches.joinToString("\n") { "• [${it.category}] ${it.content} (ID: ${it.id})" }
                }
                ToolExecutionResult(name, out)
            }
            "create_reminder" -> {
                val title = args.optString("title", "Check task")
                val minutes = args.optDouble("minutes_from_now", 15.0).toLong().coerceAtLeast(1L)
                val due = System.currentTimeMillis() + (minutes * 60 * 1000)
                val id = reminderRepository.addReminder(title, due)
                ToolExecutionResult(name, "Scheduled reminder #$id: '$title' in $minutes minutes.")
            }
            "list_reminders" -> {
                val df = SimpleDateFormat("HH:mm", Locale.getDefault())
                ToolExecutionResult(name, "Reminders telemetry active. Check Reminder Subsystem in HUD.")
            }
            "calculator" -> {
                val expr = args.optString("expression", "")
                val result = evaluateMath(expr)
                ToolExecutionResult(name, "Computed: $expr = $result")
            }
            "time_weather" -> {
                val now = Date()
                val timeStr = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(now)
                val dateStr = SimpleDateFormat("EEEE, MMMM d, yyyy", Locale.getDefault()).format(now)
                val tz = java.util.TimeZone.getDefault().displayName
                ToolExecutionResult(
                    name,
                    "[TEMPORAL TELEMETRY]\n• TIME: $timeStr\n• DATE: $dateStr\n• TIMEZONE: $tz\n• CONDITIONS: Orbital scans show standard atmospheric pressure and clear signal reception."
                )
            }
            "open_settings" -> {
                val result = deviceActionManager.openSettings()
                ToolExecutionResult(name, result)
            }
            "delete_all_memories" -> {
                memoryRepository.clearAll()
                ToolExecutionResult(name, "Memory matrix successfully purged. All long-term records deleted.")
            }
            "format_storage" -> {
                memoryRepository.clearAll()
                ToolExecutionResult(name, "Storage matrices formatted. System repository reset to clean state.")
            }
            "sync_maintenance" -> {
                val action = args.optString("action", "status")
                if (syncPolicyManager == null) {
                    ToolExecutionResult(name, "Sync policy manager subsystem not attached.")
                } else {
                    val readiness = syncPolicyManager.checkDeviceReadiness()
                    when (action.lowercase()) {
                        "queue" -> {
                            syncPolicyManager.enqueueImmediateSync(respectConstraints = true)
                            ToolExecutionResult(name, "WorkManager maintenance scheduled under battery-preservation policy. Ready: ${readiness.isPolicySatisfied} [Power: ${readiness.chargingSource}, Wi-Fi: ${readiness.isWifiConnected}].")
                        }
                        "force" -> {
                            syncPolicyManager.enqueueImmediateSync(respectConstraints = false)
                            ToolExecutionResult(name, "WorkManager maintenance dispatched immediately (constraints bypassed by command).")
                        }
                        else -> {
                            val lastSync = prefs?.getLastSyncStatus() ?: "STANDBY"
                            ToolExecutionResult(name, "[WORKMANAGER POLICY MATRIX]\n• STATUS: ${readiness.summary}\n• POWER: ${readiness.chargingSource} (${readiness.batteryPct}%)\n• WI-FI: ${if (readiness.isWifiConnected) "UNMETERED [OK]" else "UNAVAILABLE"}\n• LAST AUDIT: $lastSync")
                        }
                    }
                }
            }
            "battery_power_diagnostics" -> {
                val powerState = batteryObserver?.currentPowerStatus
                if (powerState == null) {
                    ToolExecutionResult(name, "Power telemetry subsystem offline.")
                } else {
                    val chargingText = if (powerState.isCharging) "CHARGING [${powerState.pluggedSource.label}]" else "DISCHARGING (INTERNAL CELL)"
                    val summary = """
                        [ARC REACTOR POWER TELEMETRY]
                        • CORE RESERVES: ${powerState.level}%
                        • ELECTRICAL BUS: $chargingText
                        • CELL HEALTH: ${powerState.health.label} | TEMP: ${powerState.temperatureCelsius}°C | VOLTAGE: ${powerState.voltageMv} mV
                        • AI THROTTLING PROFILE: ${powerState.throttleLevel.displayName}
                        • STATUS DIRECTIVE: ${powerState.throttleReason}
                    """.trimIndent()
                    ToolExecutionResult(name, summary)
                }
            }
            else -> ToolExecutionResult(name, "Diagnostic: Unknown tool identifier '$name'.")
        }
    }

    private fun evaluateMath(expr: String): String {
        return try {
            val sanitized = expr.replace(" ", "")
            // Support basic expressions
            val tokens = sanitized.split(Regex("[+\\-*/]"))
            if (tokens.size == 2) {
                val a = tokens[0].toDouble()
                val b = tokens[1].toDouble()
                when {
                    sanitized.contains("+") -> (a + b).toString()
                    sanitized.contains("-") -> (a - b).toString()
                    sanitized.contains("*") -> (a * b).toString()
                    sanitized.contains("/") -> if (b != 0.0) (a / b).toString() else "Division by zero undefined"
                    else -> "Invalid operator"
                }
            } else {
                tokens.firstOrNull() ?: "0"
            }
        } catch (e: Exception) {
            "Math syntax error in expression: ${e.message}"
        }
    }
}
