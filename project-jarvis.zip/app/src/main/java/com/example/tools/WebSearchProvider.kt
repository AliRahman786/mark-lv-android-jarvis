package com.example.tools

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

class WebSearchProvider {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    suspend fun searchWeb(query: String): String = withContext(Dispatchers.IO) {
        if (query.isBlank()) return@withContext "Search query cannot be empty."

        try {
            // Use DuckDuckGo Instant Answer API for live verified search knowledge
            val encoded = URLEncoder.encode(query, "UTF-8")
            val url = "https://api.duckduckgo.com/?q=$encoded&format=json&no_html=1&skip_disambig=1"

            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "JARVIS-Mark-LIV/1.0 (Android 14; AI Engine)")
                .build()

            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                return@withContext "HTTP search error: ${response.code}"
            }

            val json = JSONObject(body)
            val abstractText = json.optString("AbstractText", "")
            val abstractSource = json.optString("AbstractSource", "")
            val heading = json.optString("Heading", "")

            if (abstractText.isNotBlank()) {
                return@withContext "[LIVE WEB RESULT] $heading: $abstractText (Source: $abstractSource)"
            }

            val related = json.optJSONArray("RelatedTopics")
            if (related != null && related.length() > 0) {
                val results = StringBuilder("[WEB TELEMETRY FINDINGS]\n")
                for (i in 0 until minOf(related.length(), 4)) {
                    val topic = related.optJSONObject(i)
                    val text = topic?.optString("Text", "") ?: ""
                    if (text.isNotBlank()) {
                        results.append("• ").append(text).append("\n")
                    }
                }
                return@withContext results.toString().trim()
            }

            // Fallback to Wikipedia summary API for deep knowledge retrieval
            searchWikipedia(query)
        } catch (e: Exception) {
            "Telemetry search failure: ${e.localizedMessage}"
        }
    }

    private suspend fun searchWikipedia(query: String): String = withContext(Dispatchers.IO) {
        try {
            val encoded = URLEncoder.encode(query, "UTF-8")
            val url = "https://en.wikipedia.org/api/rest_v1/page/summary/$encoded"
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "JARVIS-Mark-LIV/1.0 (Android 14; AI Engine)")
                .build()

            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: ""

            if (response.isSuccessful) {
                val json = JSONObject(body)
                val extract = json.optString("extract", "")
                val title = json.optString("title", query)
                if (extract.isNotBlank()) {
                    return@withContext "[WIKIPEDIA ARCHIVE] $title: $extract"
                }
            }
            "No public telemetry found for '$query'. Query may require broader search terms."
        } catch (e: Exception) {
            "Wikipedia lookup failed: ${e.localizedMessage}"
        }
    }
}
