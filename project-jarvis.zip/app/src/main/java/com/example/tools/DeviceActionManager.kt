package com.example.tools

import android.app.ActivityManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.provider.Settings
import java.util.Locale

class DeviceActionManager(private val context: Context? = null) {

    fun openApp(appName: String): String {
        val ctx = context ?: return "Context unavailable for launching application '$appName'."
        val target = appName.trim().lowercase(Locale.getDefault())

        val knownPackages = mapOf(
            "youtube" to "com.google.android.youtube",
            "chrome" to "com.android.chrome",
            "maps" to "com.google.android.apps.maps",
            "google maps" to "com.google.android.apps.maps",
            "settings" to "com.android.settings",
            "camera" to "com.android.camera"
        )

        // Try direct known package
        val directPkg = knownPackages[target]
        if (directPkg != null) {
            val launchIntent = ctx.packageManager.getLaunchIntentForPackage(directPkg)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(launchIntent)
                return "Launched $appName ($directPkg)."
            }
        }

        // Try generic launcher intent lookup
        try {
            val pm = ctx.packageManager
            val intent = Intent(Intent.ACTION_MAIN, null).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
            }
            val apps = pm.queryIntentActivities(intent, 0)
            for (app in apps) {
                val label = app.loadLabel(pm).toString().lowercase(Locale.getDefault())
                if (label.contains(target) || target.contains(label)) {
                    val pkgName = app.activityInfo.packageName
                    val startIntent = pm.getLaunchIntentForPackage(pkgName)
                    if (startIntent != null) {
                        startIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        ctx.startActivity(startIntent)
                        return "Launched app: ${app.loadLabel(pm)}."
                    }
                }
            }
        } catch (_: Exception) {}

        // Fallback for settings or camera
        if (target.contains("setting")) {
            return openSettings()
        }

        return "Could not locate installed application matching '$appName'. Please verify package name."
    }

    fun openUrl(url: String): String {
        val ctx = context ?: return "Context unavailable to open URL: $url"
        return try {
            val uri = if (url.startsWith("http://") || url.startsWith("https://")) {
                Uri.parse(url)
            } else {
                Uri.parse("https://$url")
            }
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            ctx.startActivity(intent)
            "Opening browser interface for: $url"
        } catch (e: Exception) {
            "Failed to open URL: ${e.localizedMessage}"
        }
    }

    fun openMaps(query: String): String {
        val ctx = context ?: return "Context unavailable to open maps for: $query"
        return try {
            val uri = Uri.parse("geo:0,0?q=" + Uri.encode(query))
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            ctx.startActivity(intent)
            "Targeting coordinates on Maps for: $query"
        } catch (e: Exception) {
            "Failed to launch maps: ${e.localizedMessage}"
        }
    }

    fun openYouTube(query: String): String {
        val ctx = context ?: return "Context unavailable to open YouTube for: $query"
        return try {
            val uri = Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(query))
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            ctx.startActivity(intent)
            "Engaging YouTube telemetry for: $query"
        } catch (e: Exception) {
            "YouTube launch error: ${e.localizedMessage}"
        }
    }

    fun copyToClipboard(label: String, text: String): String {
        val ctx = context ?: return "Context unavailable for clipboard operations."
        return try {
            val clipboard = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = ClipData.newPlainText(label, text)
            clipboard.setPrimaryClip(clip)
            "Transferred data buffer to system clipboard."
        } catch (e: Exception) {
            "Clipboard write error: ${e.localizedMessage}"
        }
    }

    fun shareText(title: String, text: String): String {
        val ctx = context ?: return "Context unavailable to share text."
        return try {
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, title)
                putExtra(Intent.EXTRA_TEXT, text)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            val chooser = Intent.createChooser(intent, "Transmit via").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            ctx.startActivity(chooser)
            "Displaying system transmit channels."
        } catch (e: Exception) {
            "Share intent failure: ${e.localizedMessage}"
        }
    }

    fun openSettings(): String {
        val ctx = context ?: return "Context unavailable to open system settings."
        return try {
            val intent = Intent(Settings.ACTION_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            ctx.startActivity(intent)
            "Accessing Android core system settings."
        } catch (e: Exception) {
            "Failed to open settings: ${e.localizedMessage}"
        }
    }

    fun getDeviceInfo(): String {
        val ctx = context
        if (ctx == null) {
            return """
                [DIAGNOSTIC SYSTEM TELEMETRY]
                • OS PLATFORM: Android (JVM Test Harness)
                • REACTOR ENERGY: 100% [ONLINE]
                • SECURITY LEVEL: SECURE // MIN_SDK 34 ENFORCED
            """.trimIndent()
        }

        // Battery status
        var batteryPct = 100
        var isCharging = false
        try {
            val bFilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            val bIntent = ctx.registerReceiver(null, bFilter)
            val level = bIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = bIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
            batteryPct = if (level >= 0 && scale > 0) (level * 100 / scale) else 100
            isCharging = (bIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) == BatteryManager.BATTERY_STATUS_CHARGING)
        } catch (_: Exception) {}

        // Memory status
        var availMb = 2048L
        var totalMb = 4096L
        try {
            val actManager = ctx.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            val memInfo = ActivityManager.MemoryInfo()
            actManager?.getMemoryInfo(memInfo)
            availMb = memInfo.availMem / (1024 * 1024)
            totalMb = memInfo.totalMem / (1024 * 1024)
        } catch (_: Exception) {}

        // Connectivity
        var netType = "OFFLINE / LOCAL STANDBY"
        try {
            val connManager = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            val activeNet = connManager?.activeNetwork
            val caps = connManager?.getNetworkCapabilities(activeNet)
            netType = when {
                caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true -> "HIGH-SPEED WI-FI"
                caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true -> "CELLULAR 5G/LTE"
                caps?.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) == true -> "DIRECT GIGABIT"
                else -> "LOCAL STANDBY"
            }
        } catch (_: Exception) {}

        return """
            [DIAGNOSTIC SYSTEM TELEMETRY]
            • OS PLATFORM: Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})
            • ARCHITECTURE: ${Build.MANUFACTURER.uppercase()} ${Build.MODEL.uppercase()}
            • REACTOR ENERGY: $batteryPct% ${if (isCharging) "[CHARGING]" else "[DRAIN STABLE]"}
            • RAM ALLOCATION: $availMb MB AVAILABLE / $totalMb MB TOTAL
            • COMM CHANNEL: $netType
            • SECURITY LEVEL: SECURE // MIN_SDK 34 ENFORCED
        """.trimIndent()
    }
}
