package com.example

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.MainHudScreen
import com.example.ui.screens.SetupWizardScreen
import com.example.ui.theme.DeepSpaceBlack
import com.example.ui.theme.JarvisTheme
import com.example.viewmodel.JarvisViewModel

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val viewModel: JarvisViewModel = viewModel()
            val isOnboardingCompleted by viewModel.prefs.onboardingCompletedFlow.collectAsState()
            val activePanel by viewModel.activePanel.collectAsState()
            val accentColor = viewModel.getAccentColor()

            // Request necessary runtime permissions
            val permissionsLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.RequestMultiplePermissions()
            ) { /* Permissions result handled gracefully */ }

            LaunchedEffect(Unit) {
                val permissions = mutableListOf(
                    Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.CAMERA
                )
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    permissions.add(Manifest.permission.POST_NOTIFICATIONS)
                }
                permissionsLauncher.launch(permissions.toTypedArray())
            }

            // BackHandler for secondary panels
            BackHandler(enabled = isOnboardingCompleted && activePanel != "CORE") {
                viewModel.setActivePanel("CORE")
            }

            JarvisTheme(accentColor = accentColor) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = DeepSpaceBlack
                ) {
                    if (!isOnboardingCompleted) {
                        SetupWizardScreen(viewModel = viewModel)
                    } else {
                        MainHudScreen(viewModel = viewModel)
                    }
                }
            }
        }
    }
}
