package com.example.viewmodel

import android.app.Application
import android.graphics.Bitmap
import android.util.Base64
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.work.WorkInfo
import com.example.ai.AiProvider
import com.example.ai.ChatMessage
import com.example.ai.GeminiMediaService
import com.example.ai.GeminiProvider
import com.example.ai.GroqProvider
import com.example.ai.OpenAiProvider
import com.example.data.battery.AiTaskType
import com.example.data.battery.AiThrottleLevel
import com.example.data.battery.BatteryPowerState
import com.example.data.battery.PluggedSource
import com.example.data.battery.SystemBatteryObserver
import com.example.data.battery.ThrottleDecision
import com.example.data.db.AppDatabase
import com.example.data.model.ConversationEntity
import com.example.data.model.MemoryEntity
import com.example.data.prefs.PreferencesManager
import com.example.data.repository.ConversationRepository
import com.example.data.repository.MemoryRepository
import com.example.data.repository.ReminderRepository
import com.example.data.repository.StorageManager
import com.example.data.sync.DeviceSyncReadiness
import com.example.data.sync.JarvisSyncPolicyManager
import com.example.gesture.GestureController
import com.example.gesture.GestureType
import com.example.tools.DeviceActionManager
import com.example.tools.ToolRegistry
import com.example.tools.WebSearchProvider
import com.example.ui.theme.AlertCrimson
import com.example.ui.theme.ArcAmberGlow
import com.example.ui.theme.ProcessingViolet
import com.example.ui.theme.ReactorCyanGlow
import com.example.voice.VoiceInputManager
import com.example.voice.VoiceOutputManager
import com.example.voice.VoiceState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream

data class PendingActionConfirmation(
    val title: String,
    val details: String,
    val onConfirm: suspend () -> Unit
)

sealed class ApiValidationState {
    object Idle : ApiValidationState()
    object Validating : ApiValidationState()
    data class Success(val message: String) : ApiValidationState()
    data class Error(val message: String) : ApiValidationState()
}

class JarvisViewModel(application: Application) : AndroidViewModel(application) {

    val prefs = PreferencesManager(application)
    private val db = AppDatabase.getInstance(application)
    val memoryRepo = MemoryRepository(db.memoryDao())
    val conversationRepo = ConversationRepository(db.conversationDao())
    val reminderRepo = ReminderRepository(db.reminderDao())
    val storageManager = StorageManager(memoryRepo, conversationRepo, prefs)
    val syncPolicyManager = JarvisSyncPolicyManager(application)

    val deviceActionManager = DeviceActionManager(application)
    val webSearchProvider = WebSearchProvider()
    val batteryObserver = SystemBatteryObserver(application, prefs)
    val batteryPowerState: StateFlow<BatteryPowerState> = batteryObserver.powerStateFlow
    val toolRegistry = ToolRegistry(deviceActionManager, webSearchProvider, memoryRepo, reminderRepo, syncPolicyManager, prefs, batteryObserver)

    val voiceInputManager = VoiceInputManager(application)
    val voiceOutputManager = VoiceOutputManager(application)
    val gestureController = GestureController()
    val geminiMediaService = GeminiMediaService()

    // AI Providers
    private val providers = mapOf<String, AiProvider>(
        PreferencesManager.PROVIDER_GEMINI to GeminiProvider(),
        PreferencesManager.PROVIDER_OPENAI to OpenAiProvider(),
        PreferencesManager.PROVIDER_GROQ to GroqProvider()
    )

    // UI States
    private val _activePanel = MutableStateFlow("CORE") // CORE, CHAT, STUDIO, MEMORY, TOOLS, GESTURES, SETTINGS
    val activePanel: StateFlow<String> = _activePanel.asStateFlow()

    private val _voiceState = MutableStateFlow(VoiceState.IDLE)
    val voiceState: StateFlow<VoiceState> = _voiceState.asStateFlow()

    private val _statusText = MutableStateFlow("MARK-LIV CORE // ALL SYSTEMS NOMINAL")
    val statusText: StateFlow<String> = _statusText.asStateFlow()

    private val _inputText = MutableStateFlow("")
    val inputText: StateFlow<String> = _inputText.asStateFlow()

    private val _pendingConfirmation = MutableStateFlow<PendingActionConfirmation?>(null)
    val pendingConfirmation: StateFlow<PendingActionConfirmation?> = _pendingConfirmation.asStateFlow()

    private val _apiValidationState = MutableStateFlow<ApiValidationState>(ApiValidationState.Idle)
    val apiValidationState: StateFlow<ApiValidationState> = _apiValidationState.asStateFlow()

    private val _setupStep = MutableStateFlow(1)
    val setupStep: StateFlow<Int> = _setupStep.asStateFlow()

    // Live audio decibels combining mic input and TTS output for core animation
    val combinedAudioAmplitude: StateFlow<Float> = combine(
        voiceInputManager.audioRmsDb,
        voiceOutputManager.speechAmplitude
    ) { micAmp, ttsAmp ->
        maxOf(micAmp, ttsAmp)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0f)

    // Database message stream
    val conversationMessages: StateFlow<List<ConversationEntity>> = conversationRepo.currentMessages
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val memoriesList: StateFlow<List<MemoryEntity>> = memoryRepo.allMemories
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // WorkManager background maintenance sync and hardware readiness telemetry
    val periodicWorkInfo: StateFlow<WorkInfo?> = syncPolicyManager.getPeriodicWorkInfoFlow()
        .map { list -> list.firstOrNull() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _deviceReadiness = MutableStateFlow(syncPolicyManager.checkDeviceReadiness())
    val deviceReadiness: StateFlow<DeviceSyncReadiness> = _deviceReadiness.asStateFlow()

    fun refreshDeviceReadiness() {
        _deviceReadiness.value = syncPolicyManager.checkDeviceReadiness()
    }

    init {
        // Wire gesture controller actions
        gestureController.onGestureAction = { gesture ->
            handleGestureAction(gesture)
        }

        // Initialize WorkManager background maintenance sync policy (Charging + Wi-Fi)
        syncPolicyManager.schedulePeriodicMaintenanceSync(repeatHours = 6)

        // Wire battery observer callbacks for live power status & throttling alerts
        batteryObserver.onChargingStateChanged = { isCharging, state ->
            if (isCharging) {
                _statusText.value = "[⚡ POWER BUS CONNECTED] ARC REACTOR RECHARGING // AI UNCONSTRAINED"
                speakVoice("Arc Reactor is now receiving power from ${state.pluggedSource.label}. Computational throttling disengaged.")
            } else {
                _statusText.value = "[POWER BUS DISCONNECTED] RUNNING ON BATTERY RESERVES (${state.level}%)"
            }
            refreshDeviceReadiness()
        }

        batteryObserver.onThrottleLevelChanged = { level, state ->
            when (level) {
                AiThrottleLevel.CRITICAL_THROTTLED -> {
                    _statusText.value = "[ALERT: POWER RESERVES CRITICAL (${state.level}%)] EMERGENCY AI THROTTLING ENGAGED"
                    speakVoice("Warning: Arc Reactor reserves are critical at ${state.level} percent. Computational throttling engaged.")
                }
                AiThrottleLevel.BALANCED -> {
                    _statusText.value = "[POWER CONSERVATION: BALANCED (${state.level}%)] AI COMPUTATION MODERATED"
                }
                AiThrottleLevel.UNCONSTRAINED -> {
                    _statusText.value = "[POWER NOMINAL (${state.level}%)] AI OPERATING UNCONSTRAINED"
                }
            }
        }
    }

    fun setActivePanel(panel: String) {
        _activePanel.value = panel
    }

    fun setInputText(text: String) {
        _inputText.value = text
    }

    fun getAccentColor(): Color {
        return when (prefs.getAccentColor()) {
            "REACTOR_CYAN" -> ReactorCyanGlow
            "STEALTH_VIOLET" -> ProcessingViolet
            "ALERT_CRIMSON" -> AlertCrimson
            else -> ArcAmberGlow
        }
    }

    fun getActiveAiProvider(): AiProvider {
        return providers[prefs.getAiProvider()] ?: providers[PreferencesManager.PROVIDER_GEMINI]!!
    }

    fun setGeminiModel(model: String) {
        prefs.setModel(PreferencesManager.PROVIDER_GEMINI, model)
        _statusText.value = "AI CORE MODEL SHIFTED // $model"
    }

    fun toggleSearchGrounding() {
        val current = prefs.isSearchGroundingEnabled()
        prefs.setSearchGroundingEnabled(!current)
        _statusText.value = "GOOGLE SEARCH GROUNDING // ${if (!current) "ENGAGED" else "DISENGAGED"}"
    }

    fun toggleMapsGrounding() {
        val current = prefs.isMapsGroundingEnabled()
        prefs.setMapsGroundingEnabled(!current)
        _statusText.value = "GOOGLE MAPS GROUNDING // ${if (!current) "ENGAGED" else "DISENGAGED"}"
    }

    // --- Onboarding Setup Wizard Navigation ---
    fun setSetupStep(step: Int) {
        _setupStep.value = step.coerceIn(1, 13)
        _apiValidationState.value = ApiValidationState.Idle
    }

    fun testActiveApiKey(providerId: String, key: String, model: String) {
        viewModelScope.launch {
            _apiValidationState.value = ApiValidationState.Validating
            val provider = providers[providerId] ?: providers[PreferencesManager.PROVIDER_GEMINI]!!
            val result = provider.testConnection(key, model)
            if (result.isSuccess) {
                _apiValidationState.value = ApiValidationState.Success(result.getOrNull() ?: "Authentication verified.")
            } else {
                _apiValidationState.value = ApiValidationState.Error(result.exceptionOrNull()?.message ?: "Validation failed.")
            }
        }
    }

    fun completeOnboarding() {
        prefs.setOnboardingCompleted(true)
        _statusText.value = "MARK-LIV INITIALIZATION COMPLETE // WELCOME ${prefs.getUserName().uppercase()}"
        speakVoice("Systems initialized. Good to see you, ${prefs.getUserName()}. JARVIS Mark-LIV is online and listening.")
    }

    // --- Hand Gesture Action Handling ---
    private fun handleGestureAction(gesture: GestureType) {
        when (gesture) {
            GestureType.OPEN_PALM -> {
                _statusText.value = "[GESTURE RECOGNITION] OPEN PALM DETECTED // ACTIVATING VOICE RECEPTOR"
                startVoiceInput()
            }
            GestureType.FIST -> {
                _statusText.value = "[GESTURE RECOGNITION] FIST DETECTED // ABORTING TASK"
                cancelAction()
            }
            GestureType.PINCH_INDEX -> {
                _statusText.value = "[GESTURE RECOGNITION] PINCH DETECTED // CONFIRMING PENDING ACTION"
                confirmPendingAction()
            }
            GestureType.SWIPE_LEFT -> {
                val panels = listOf("CORE", "CHAT", "STUDIO", "MEMORY", "TOOLS", "GESTURES", "SETTINGS")
                val curIdx = panels.indexOf(_activePanel.value)
                val nextIdx = (curIdx + 1) % panels.size
                _activePanel.value = panels[nextIdx]
                _statusText.value = "HUD PANELS SHIFTED // ${panels[nextIdx]}"
            }
            GestureType.SWIPE_RIGHT -> {
                val panels = listOf("CORE", "CHAT", "STUDIO", "MEMORY", "TOOLS", "GESTURES", "SETTINGS")
                val curIdx = panels.indexOf(_activePanel.value)
                val prevIdx = if (curIdx <= 0) panels.size - 1 else curIdx - 1
                _activePanel.value = panels[prevIdx]
                _statusText.value = "HUD PANELS SHIFTED // ${panels[prevIdx]}"
            }
            GestureType.TWO_FINGERS -> {
                if (voiceOutputManager.isSpeaking.value) {
                    voiceOutputManager.stop()
                    _statusText.value = "SPEECH OUTPUT PAUSED VIA GESTURE"
                } else {
                    _statusText.value = "SYSTEM STATUS NOMINAL"
                }
            }
            else -> {}
        }
    }

    // --- Voice System ---
    fun toggleVoiceInput() {
        if (voiceInputManager.isListening.value) {
            voiceInputManager.stopListening()
            _voiceState.value = VoiceState.IDLE
        } else {
            startVoiceInput()
        }
    }

    fun startVoiceInput() {
        voiceOutputManager.stop()
        _voiceState.value = VoiceState.LISTENING
        _statusText.value = "AUDIO RECEPTORS ACTIVE // LISTENING..."

        voiceInputManager.startListening(
            onResult = { spokenText ->
                _voiceState.value = VoiceState.PROCESSING
                _statusText.value = "VOICE INPUT CAPTURED: \"$spokenText\""
                sendUserMessage(spokenText)
            },
            onError = { error ->
                _voiceState.value = VoiceState.ERROR
                _statusText.value = "VOICE RECEPTOR ALERT: $error"
                viewModelScope.launch {
                    delay(2000)
                    if (_voiceState.value == VoiceState.ERROR) {
                        _voiceState.value = VoiceState.IDLE
                    }
                }
            }
        )
    }

    fun speakVoice(text: String) {
        _voiceState.value = VoiceState.SPEAKING
        voiceOutputManager.speak(text) {
            if (_voiceState.value == VoiceState.SPEAKING) {
                _voiceState.value = VoiceState.IDLE
            }
        }
    }

    fun cancelAction() {
        voiceInputManager.stopListening()
        voiceOutputManager.stop()
        _voiceState.value = VoiceState.IDLE
        _pendingConfirmation.value = null
        _statusText.value = "ACTIVE TASK TERMINATED // STANDBY"
    }

    // --- AI Conversation & Reasoning Loop ---
    fun sendUserMessage(text: String, imageBitmap: Bitmap? = null) {
        if (text.isBlank() && imageBitmap == null) return

        viewModelScope.launch {
            _inputText.value = ""
            var base64Img: String? = null
            if (imageBitmap != null) {
                val stream = ByteArrayOutputStream()
                imageBitmap.compress(Bitmap.CompressFormat.JPEG, 80, stream)
                base64Img = Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP)
            }

            // Save user message to database
            conversationRepo.addMessage(
                sender = "USER",
                content = text,
                imageUrl = if (base64Img != null) "IMAGE_DATA" else null
            )

            // Dynamic Battery Throttling Evaluation
            val throttleDecision = batteryObserver.evaluateAiThrottle(AiTaskType.LLM_INFERENCE)
            _voiceState.value = VoiceState.THINKING
            if (throttleDecision.isThrottled) {
                _statusText.value = "[AI THROTTLED: ${throttleDecision.throttleLevel.displayName.uppercase()}] COMPUTING..."
            } else {
                _statusText.value = "QUANTUM CORE HEURISTICS COMPUTING..."
            }

            // Build Short-term history context
            val history = conversationRepo.getRecentHistory(10)
            val chatMessages = history.map { entity ->
                ChatMessage(
                    role = if (entity.sender == "USER") "user" else "assistant",
                    content = entity.content
                )
            }.toMutableList()

            // Retrieve relevant Long-term memories to build contextual intelligence
            val keywords = text.split(" ").filter { it.length > 3 }
            val retrievedMemories = mutableListOf<MemoryEntity>()
            for (kw in keywords.take(3)) {
                retrievedMemories.addAll(memoryRepo.searchMemories(kw))
            }
            val memoryContext = if (retrievedMemories.isNotEmpty()) {
                val facts = retrievedMemories.distinctBy { it.id }.take(5).joinToString("; ") { it.content }
                "\n[RECALLED LONG-TERM MEMORY ARCHIVE: $facts]"
            } else ""

            val tacticalDirective = if (throttleDecision.isThrottled && !throttleDecision.tacticalDirective.isNullOrBlank()) {
                "\n${throttleDecision.tacticalDirective}"
            } else ""

            val assistantName = prefs.getAssistantName()
            val userName = prefs.getUserName()
            val systemInstruction = """
                You are $assistantName (Just A Rather Very Intelligent System), Mark-LIV, Tony Stark's personal tactical AI assistant running natively on Android 14+.
                The user's name is $userName.
                Respond with high intelligence, conciseness, sophisticated wit, and unwavering technical authority.
                You have access to native Android subsystem tools (web search, launch applications, maps, camera, reminders, device info, saving memories).
                Use tools whenever the user's request involves actions, real-time facts, device operations, or storing facts.
                Never hallucinate device actions. Always return safe, verified information.
                $memoryContext$tacticalDirective
            """.trimIndent()

            val provider = getActiveAiProvider()
            val apiKey = prefs.getApiKey(provider.id)
            val baseModel = prefs.getModel(provider.id)
            // If critical throttle suggests a lightweight model, prefer it if on Gemini
            val model = if (throttleDecision.throttleLevel == AiThrottleLevel.CRITICAL_THROTTLED &&
                provider.id == PreferencesManager.PROVIDER_GEMINI &&
                throttleDecision.suggestedModel != null
            ) {
                throttleDecision.suggestedModel
            } else {
                baseModel
            }
            val tools = toolRegistry.getAllDefinitions()

            val responseResult = withContext(Dispatchers.IO) {
                provider.generateResponse(
                    apiKey = apiKey,
                    model = model,
                    messages = chatMessages,
                    systemInstruction = systemInstruction,
                    tools = tools
                )
            }

            if (responseResult.isSuccess) {
                val aiResponse = responseResult.getOrNull()!!
                if (aiResponse.toolCalls.isNotEmpty()) {
                    // Execute tools requested by AI
                    handleToolCalls(aiResponse)
                } else {
                    val reply = aiResponse.text.ifBlank { "Diagnostic complete. Ready for next command." }
                    conversationRepo.addMessage(sender = "JARVIS", content = reply)
                    _statusText.value = "COMMAND EXECUTED // MARK-LIV STANDBY"
                    speakVoice(reply)
                }
            } else {
                val errorMsg = responseResult.exceptionOrNull()?.message ?: "Subsystem offline"
                _voiceState.value = VoiceState.ERROR
                _statusText.value = "CORE ERROR: $errorMsg"
                conversationRepo.addMessage(sender = "JARVIS", content = "Core Diagnostic Alert: $errorMsg")
                speakVoice("Notice: Encountered an error with the ${provider.displayName} provider: $errorMsg")
            }
        }
    }

    private suspend fun handleToolCalls(aiResponse: com.example.ai.AiResponse) {
        for (call in aiResponse.toolCalls) {
            _statusText.value = "ENGAGING SUBSYSTEM TOOL: ${call.name.uppercase()}"

            // Check if tool requires explicit human confirmation
            if (toolRegistry.isConsequentialAction(call.name)) {
                _pendingConfirmation.value = PendingActionConfirmation(
                    title = "CONFIRM CONSEQUENT ACTION",
                    details = "Tool '${call.name}' requires manual authorization. Proceed with execution?",
                    onConfirm = {
                        executeAndRecordTool(call.name, call.argumentsJson)
                    }
                )
                speakVoice("Manual authorization required to execute ${call.name}.")
                return
            }

            executeAndRecordTool(call.name, call.argumentsJson)
        }
    }

    private suspend fun executeAndRecordTool(toolName: String, argsJson: String) {
        val execResult = toolRegistry.executeTool(toolName, argsJson)
        conversationRepo.addMessage(
            sender = "JARVIS",
            content = execResult.resultText,
            toolName = toolName,
            toolArgs = argsJson,
            toolResult = execResult.resultText
        )
        _statusText.value = "SUBSYSTEM ${toolName.uppercase()} COMPLETED"
        speakVoice(execResult.resultText)
    }

    fun confirmPendingAction() {
        val pending = _pendingConfirmation.value
        _pendingConfirmation.value = null
        if (pending != null) {
            viewModelScope.launch {
                pending.onConfirm()
            }
        }
    }

    fun dismissPendingAction() {
        _pendingConfirmation.value = null
        _statusText.value = "ACTION ABORTED BY USER"
    }

    // --- Memory Management Actions ---
    fun deleteMemory(id: Long) {
        viewModelScope.launch {
            memoryRepo.deleteMemory(id)
            _statusText.value = "RECORD #$id PURGED FROM LONG-TERM ARCHIVE"
        }
    }

    fun clearAllMemories() {
        _pendingConfirmation.value = PendingActionConfirmation(
            title = "PURGE MEMORY CORE",
            details = "Are you certain you wish to purge ALL long-term memory archives? This cannot be undone.",
            onConfirm = {
                memoryRepo.clearAll()
                _statusText.value = "LONG-TERM MEMORY CORE PURGED"
                speakVoice("All long-term memory records have been erased from local storage.")
            }
        )
    }

    fun clearConversationHistory() {
        viewModelScope.launch {
            conversationRepo.clearHistory()
            _statusText.value = "SESSION CONVERSATION LOG CLEARED"
        }
    }

    fun triggerCloudSync() {
        viewModelScope.launch {
            _statusText.value = "INITIATING CLOUD STORAGE SYNCHRONIZATION..."
            // Enqueue through WorkManager for execution
            syncPolicyManager.enqueueImmediateSync(respectConstraints = false)
            delay(800)
            val result = storageManager.syncNow()
            _statusText.value = result
            speakVoice("Cloud synchronization completed. Archive verified.")
        }
    }

    fun triggerWorkManagerSync(respectConstraints: Boolean = true) {
        viewModelScope.launch {
            syncPolicyManager.enqueueImmediateSync(respectConstraints)
            refreshDeviceReadiness()
            if (respectConstraints) {
                val readiness = syncPolicyManager.checkDeviceReadiness()
                if (readiness.isPolicySatisfied) {
                    _statusText.value = "WORKMANAGER SYNC DISPATCHED // CHARGER + WI-FI DETECTED"
                    speakVoice("Maintenance task dispatched. Device is charging and connected to Wi-Fi.")
                } else {
                    _statusText.value = "WORKMANAGER SYNC QUEUED // WAITING FOR CHARGING + WI-FI"
                    speakVoice("Maintenance task queued. Execution will proceed once charging on Wi-Fi.")
                }
            } else {
                _statusText.value = "WORKMANAGER MAINTENANCE DISPATCHED IMMEDIATELY"
                speakVoice("Manual maintenance dispatch executed.")
            }
        }
    }

    fun updateSyncPolicy(requiresCharging: Boolean, requiresWifi: Boolean, intervalHours: Long) {
        prefs.setSyncChargingRequired(requiresCharging)
        prefs.setSyncWifiRequired(requiresWifi)
        prefs.setSyncIntervalHours(intervalHours)
        syncPolicyManager.schedulePeriodicMaintenanceSync(intervalHours)
        refreshDeviceReadiness()
        _statusText.value = "SYNC POLICY UPDATED // CHARGE=$requiresCharging // WIFI=$requiresWifi // CYCLE=${intervalHours}H"
    }

    // Dynamic AI Battery Throttling Controls
    fun setAiThrottlingEnabled(enabled: Boolean) {
        prefs.setAiThrottlingEnabled(enabled)
        batteryObserver.refreshPowerStatus()
        refreshDeviceReadiness()
        _statusText.value = "AI THROTTLING POLICY // ${if (enabled) "AUTONOMOUS CONSERVATION ENGAGED" else "MANUAL BYPASS"}"
    }

    fun setBatteryLowThreshold(threshold: Int) {
        prefs.setBatteryLowThreshold(threshold)
        batteryObserver.refreshPowerStatus()
    }

    fun setBatteryCriticalThreshold(threshold: Int) {
        prefs.setBatteryCriticalThreshold(threshold)
        batteryObserver.refreshPowerStatus()
    }

    fun simulateBatteryPower(level: Int, isCharging: Boolean, plugged: PluggedSource) {
        batteryObserver.simulatePowerState(level = level, isCharging = isCharging, pluggedSource = plugged)
        refreshDeviceReadiness()
        _statusText.value = "POWER TELEMETRY SIMULATION // LEVEL=$level% // BUS=${plugged.label} // CHARGING=$isCharging"
    }

    fun resetBatterySimulation() {
        batteryObserver.resetSimulation()
        refreshDeviceReadiness()
        _statusText.value = "HARDWARE POWER SENSORS RESTORED"
    }

    override fun onCleared() {
        super.onCleared()
        batteryObserver.stop()
    }
}
