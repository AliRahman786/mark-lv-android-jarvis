package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ai.ToolDefinition
import com.example.ui.hud.HudBadge
import com.example.ui.hud.HudButton
import com.example.ui.hud.HudCard
import com.example.ui.hud.HudPanel
import com.example.ui.theme.HologramTextBright
import com.example.ui.theme.HologramTextDim
import com.example.ui.theme.HologramTextMuted
import com.example.ui.theme.ReactorCyanGlow
import com.example.ui.theme.SuccessEmerald
import com.example.viewmodel.JarvisViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Composable
fun ToolRegistryPanel(
    viewModel: JarvisViewModel,
    modifier: Modifier = Modifier
) {
    val tools = viewModel.toolRegistry.getAllDefinitions()
    val accentColor = viewModel.getAccentColor()
    var lastExecutedTool by remember { mutableStateOf<String?>(null) }
    var lastExecutionResult by remember { mutableStateOf<String?>(null) }

    HudPanel(
        title = "ANDROID SUBSYSTEM TOOL REGISTRY",
        accentColor = accentColor,
        trailingBadge = {
            HudBadge(label = "${tools.size} TOOLS ONLINE", accentColor = accentColor)
        },
        modifier = modifier.fillMaxSize()
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            Text(
                text = "Autonomous capability modules bound to Android 14+ APIs. The AI agent invokes these functions dynamically during reasoning.",
                color = HologramTextMuted,
                fontSize = 11.sp,
                lineHeight = 16.sp
            )

            if (lastExecutionResult != null) {
                Spacer(modifier = Modifier.height(10.dp))
                HudCard(borderColor = SuccessEmerald) {
                    Column {
                        Text(
                            text = "DIAGNOSTIC TEST RUN: ${lastExecutedTool?.uppercase()}",
                            color = SuccessEmerald,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = lastExecutionResult ?: "",
                            color = HologramTextBright,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(tools, key = { it.name }) { tool ->
                    ToolCardItem(
                        tool = tool,
                        accentColor = accentColor,
                        onTestRun = {
                            CoroutineScope(Dispatchers.Main).launch {
                                lastExecutedTool = tool.name
                                val sampleArgs = when (tool.name) {
                                    "web_search" -> "{\"query\":\"James Webb Space Telescope discoveries\"}"
                                    "open_app" -> "{\"app_name\":\"youtube\"}"
                                    "maps_search" -> "{\"location\":\"Stark Tower New York\"}"
                                    "save_memory" -> "{\"fact\":\"Stark Industries Mark-LIV systems calibrated.\"}"
                                    "calculator" -> "{\"expression\":\"42 * 1337\"}"
                                    else -> "{}"
                                }
                                val res = viewModel.toolRegistry.executeTool(tool.name, sampleArgs)
                                lastExecutionResult = res.resultText
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun ToolCardItem(
    tool: ToolDefinition,
    accentColor: Color,
    onTestRun: () -> Unit
) {
    HudCard(borderColor = accentColor.copy(alpha = 0.3f)) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Build,
                        contentDescription = tool.name,
                        tint = accentColor,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = tool.name.uppercase(),
                        color = accentColor,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                }

                HudButton(
                    text = "TEST",
                    onClick = onTestRun,
                    icon = Icons.Default.PlayArrow,
                    accentColor = accentColor,
                    testTag = "test_tool_${tool.name}"
                )
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = tool.description,
                color = HologramTextBright,
                fontSize = 11.sp,
                lineHeight = 15.sp
            )

            if (tool.parameters.isNotEmpty()) {
                Spacer(modifier = Modifier.height(6.dp))
                Row {
                    Text(
                        text = "PARAMS: ",
                        color = HologramTextDim,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = tool.parameters.joinToString(", ") { "${it.name}: ${it.type}" },
                        color = ReactorCyanGlow,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}
