package com.example.ui.screens

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BatteryAlert
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.battery.AiThrottleLevel
import com.example.ui.hud.HudBadge
import com.example.ui.hud.HudButton
import com.example.ui.hud.HudCard
import com.example.ui.hud.HudPanel
import com.example.ui.theme.AlertCrimson
import com.example.ui.theme.ArcAmberGlow
import com.example.ui.theme.DarkHologramSurface
import com.example.ui.theme.HologramTextBright
import com.example.ui.theme.HologramTextDim
import com.example.ui.theme.HologramTextMuted
import com.example.ui.theme.HudCardSurface
import com.example.ui.theme.ReactorCyanBright
import com.example.ui.theme.ReactorCyanGlow
import com.example.ui.theme.SuccessEmerald
import com.example.viewmodel.JarvisViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun MediaStudioPanel(
    viewModel: JarvisViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val accentColor = viewModel.getAccentColor()
    val scrollState = rememberScrollState()

    var activeSubTab by remember { mutableStateOf("IMAGE") } // IMAGE, VEO, TRANSCRIBE

    // Image Studio state
    var imagePrompt by remember { mutableStateOf("Holographic schematic of Mark-LIV arc reactor blueprints, technical wireframe") }
    var generatedImage by remember { mutableStateOf<Bitmap?>(null) }
    var uploadedImage by remember { mutableStateOf<Bitmap?>(null) }
    var isImageGenerating by remember { mutableStateOf(false) }
    var imageStatusMessage by remember { mutableStateOf<String?>(null) }
    var isImageError by remember { mutableStateOf(false) }

    // Veo Video Studio state
    var videoPrompt by remember { mutableStateOf("Cinematic orbital flyby of Stark Tower with glowing neon quantum energy pulses") }
    var videoAspectRatio by remember { mutableStateOf("16:9") } // "16:9" or "9:16"
    var isVideoGenerating by remember { mutableStateOf(false) }
    var videoStatusMessage by remember { mutableStateOf<String?>(null) }
    var isVideoError by remember { mutableStateOf(false) }

    // Transcribe state
    var transcribedText by remember { mutableStateOf<String?>(null) }
    var isTranscribing by remember { mutableStateOf(false) }
    var transcribeStatusMessage by remember { mutableStateOf<String?>(null) }

    // Live power telemetry & dynamic AI throttling state
    val powerState by viewModel.batteryPowerState.collectAsState()
    var overrideThrottleProtocol by remember { mutableStateOf(false) }

    // Android Zero-Permission Photo Picker for image upload
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    val bmp = BitmapFactory.decodeStream(stream)
                    uploadedImage = bmp
                    imageStatusMessage = "Tactical photo buffer loaded [${bmp.width}x${bmp.height}]"
                }
            } catch (e: Exception) {
                imageStatusMessage = "Failed to load photo: ${e.localizedMessage}"
                isImageError = true
            }
        }
    }

    HudPanel(
        title = "HOLOGRAPHIC SYNTHESIZER MATRIX",
        accentColor = accentColor,
        trailingBadge = {
            HudBadge(label = "GEMINI & VEO MULTIMODAL", accentColor = accentColor)
        },
        modifier = modifier.fillMaxSize()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
        ) {
            // Dynamic AI Battery Throttling Notification Banner
            if (powerState.throttleLevel != AiThrottleLevel.UNCONSTRAINED) {
                val bannerColor = if (powerState.throttleLevel == AiThrottleLevel.CRITICAL_THROTTLED) AlertCrimson else ArcAmberGlow
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(bannerColor.copy(alpha = 0.12f))
                        .border(1.dp, bannerColor.copy(alpha = 0.45f), RoundedCornerShape(6.dp))
                        .padding(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (powerState.isCharging) Icons.Default.BatteryChargingFull else Icons.Default.BatteryAlert,
                                contentDescription = null,
                                tint = bannerColor,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (powerState.throttleLevel == AiThrottleLevel.CRITICAL_THROTTLED)
                                    "POWER CRITICAL (${powerState.level}%): Neural synthesis throttled to prevent device shutdown."
                                else
                                    "POWER RESERVES LOW (${powerState.level}%): Heavy neural generation throttled. Connect charger for optimal speed.",
                                color = bannerColor,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                lineHeight = 13.sp
                            )
                        }
                        if (powerState.throttleLevel == AiThrottleLevel.CRITICAL_THROTTLED) {
                            Spacer(modifier = Modifier.width(6.dp))
                            HudBadge(
                                label = if (overrideThrottleProtocol) "OVERRIDE ENGAGED" else "OVERRIDE THROTTLE",
                                accentColor = if (overrideThrottleProtocol) SuccessEmerald else AlertCrimson,
                                modifier = Modifier.clickable { overrideThrottleProtocol = !overrideThrottleProtocol }
                            )
                        }
                    }
                }
            }

            // Mode Sub-Tab Navigation
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf(
                    Triple("IMAGE", "01 // IMAGE STUDIO", Icons.Default.AutoAwesome),
                    Triple("VEO", "02 // VEO VIDEO", Icons.Default.Movie),
                    Triple("TRANSCRIBE", "03 // TRANSCRIBE", Icons.Default.Mic)
                ).forEach { (id, label, icon) ->
                    val isSel = activeSubTab == id
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (isSel) accentColor.copy(alpha = 0.25f) else HudCardSurface)
                            .border(1.dp, if (isSel) accentColor else Color.Gray.copy(alpha = 0.3f), RoundedCornerShape(4.dp))
                            .clickable { activeSubTab = id }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = icon,
                                contentDescription = label,
                                tint = if (isSel) accentColor else HologramTextDim,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = label,
                                color = if (isSel) accentColor else HologramTextMuted,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            when (activeSubTab) {
                "IMAGE" -> {
                    // --- 1. Image Studio (gemini-3.1-flash-image-preview) ---
                    HudCard(borderColor = accentColor.copy(alpha = 0.4f)) {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "QUANTUM SCHEMATIC GENERATOR",
                                    color = accentColor,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                                HudBadge(label = "gemini-3.1-flash-image-preview", accentColor = ReactorCyanGlow)
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Generate tactical schematics from prompts, or upload a photo to apply modifications:",
                                color = HologramTextMuted,
                                fontSize = 11.sp,
                                lineHeight = 15.sp
                            )

                            Spacer(modifier = Modifier.height(10.dp))
                            OutlinedTextField(
                                value = imagePrompt,
                                onValueChange = { imagePrompt = it },
                                label = { Text("IMAGE GENERATION / EDIT PROMPT") },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("image_prompt_input"),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = accentColor,
                                    unfocusedBorderColor = accentColor.copy(alpha = 0.4f),
                                    focusedTextColor = HologramTextBright,
                                    unfocusedTextColor = HologramTextBright
                                ),
                                maxLines = 3
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            // Action buttons: Generate vs Upload Photo to Edit
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                HudButton(
                                    text = if (isImageGenerating) "SYNTHESIZING..." else "GENERATE SCHEMATIC",
                                    onClick = {
                                        if (isImageGenerating) return@HudButton
                                        if (powerState.throttleLevel == AiThrottleLevel.CRITICAL_THROTTLED && !overrideThrottleProtocol) {
                                            imageStatusMessage = "EMERGENCY POWER CONSERVATION: Image synthesis blocked at ${powerState.level}% battery. Connect charger or tap 'OVERRIDE THROTTLE' above."
                                            isImageError = true
                                            return@HudButton
                                        }
                                        isImageGenerating = true
                                        isImageError = false
                                        imageStatusMessage = "Engaging neural image synthesis via gemini-3.1-flash-image-preview..."
                                        CoroutineScope(Dispatchers.Main).launch {
                                            val key = viewModel.prefs.getApiKey("GEMINI")
                                            val result = if (uploadedImage != null) {
                                                viewModel.geminiMediaService.editImage(key, uploadedImage!!, imagePrompt)
                                            } else {
                                                viewModel.geminiMediaService.generateImage(key, imagePrompt)
                                            }
                                            isImageGenerating = false
                                            if (result.isSuccess) {
                                                generatedImage = result.getOrNull()
                                                imageStatusMessage = "Holographic schematic successfully synthesized."
                                                isImageError = false
                                            } else {
                                                imageStatusMessage = result.exceptionOrNull()?.message ?: "Synthesis failed"
                                                isImageError = true
                                            }
                                        }
                                    },
                                    icon = Icons.Default.AutoAwesome,
                                    accentColor = accentColor,
                                    modifier = Modifier.weight(1.3f)
                                )

                                HudButton(
                                    text = if (uploadedImage != null) "PHOTO LOADED" else "UPLOAD PHOTO",
                                    onClick = {
                                        photoPickerLauncher.launch(
                                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                        )
                                    },
                                    icon = Icons.Default.AddPhotoAlternate,
                                    accentColor = if (uploadedImage != null) SuccessEmerald else ReactorCyanGlow,
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            // Status / Progress indicator
                            if (isImageGenerating) {
                                Spacer(modifier = Modifier.height(10.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    CircularProgressIndicator(color = accentColor, modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Neural rasterization in progress...", color = accentColor, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                                }
                            }

                            imageStatusMessage?.let { msg ->
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = msg,
                                    color = if (isImageError) AlertCrimson else SuccessEmerald,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }

                            // Display Generated or Uploaded Image
                            val displayBmp = generatedImage ?: uploadedImage
                            if (displayBmp != null) {
                                Spacer(modifier = Modifier.height(12.dp))
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .border(1.2.dp, accentColor, RoundedCornerShape(8.dp))
                                        .background(DarkHologramSurface)
                                        .padding(4.dp)
                                ) {
                                    Column {
                                        Image(
                                            bitmap = displayBmp.asImageBitmap(),
                                            contentDescription = "Holographic Schematic",
                                            contentScale = ContentScale.Fit,
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(220.dp)
                                                .clip(RoundedCornerShape(6.dp))
                                        )
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = "RESOLUTION: ${displayBmp.width}x${displayBmp.height} px",
                                                color = HologramTextDim,
                                                fontSize = 10.sp,
                                                fontFamily = FontFamily.Monospace
                                            )
                                            HudButton(
                                                text = "SEND TO TERMINAL",
                                                onClick = {
                                                    viewModel.sendUserMessage("Analyze this synthesized holographic blueprint.", displayBmp)
                                                    viewModel.setActivePanel("CHAT")
                                                },
                                                icon = Icons.Default.Send,
                                                accentColor = accentColor
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                "VEO" -> {
                    // --- 2. Veo Video Studio (veo-3.1-fast-generate-preview) ---
                    HudCard(borderColor = accentColor.copy(alpha = 0.4f)) {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "VEO KINETIC VIDEO SYNTHESIZER",
                                    color = accentColor,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                                HudBadge(label = "veo-3.1-fast-generate-preview", accentColor = ReactorCyanBright)
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Generate kinematic videos from text descriptions or animate an uploaded photograph into full motion. Select aspect ratio (16:9 Landscape or 9:16 Portrait):",
                                color = HologramTextMuted,
                                fontSize = 11.sp,
                                lineHeight = 15.sp
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            // Aspect Ratio Selector (16:9 vs 9:16)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                listOf("16:9", "9:16").forEach { ratio ->
                                    val isSel = videoAspectRatio == ratio
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(if (isSel) accentColor.copy(alpha = 0.25f) else HudCardSurface)
                                            .border(1.dp, if (isSel) accentColor else Color.Gray.copy(alpha = 0.3f), RoundedCornerShape(4.dp))
                                            .clickable { videoAspectRatio = ratio }
                                            .padding(vertical = 8.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = if (ratio == "16:9") "16:9 LANDSCAPE (WIDE)" else "9:16 PORTRAIT (VERTICAL)",
                                            color = if (isSel) accentColor else HologramTextMuted,
                                            fontSize = 11.sp,
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))
                            OutlinedTextField(
                                value = videoPrompt,
                                onValueChange = { videoPrompt = it },
                                label = { Text("VEO MOTION PROMPT") },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("video_prompt_input"),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = accentColor,
                                    unfocusedBorderColor = accentColor.copy(alpha = 0.4f),
                                    focusedTextColor = HologramTextBright,
                                    unfocusedTextColor = HologramTextBright
                                ),
                                maxLines = 3
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            // Generate text-to-video vs Animate Photo
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                HudButton(
                                    text = if (isVideoGenerating) "SYNTHESIZING..." else "GENERATE VIDEO",
                                    onClick = {
                                        if (isVideoGenerating) return@HudButton
                                        if (powerState.throttleLevel == AiThrottleLevel.CRITICAL_THROTTLED && !overrideThrottleProtocol) {
                                            videoStatusMessage = "EMERGENCY POWER CONSERVATION: Veo video synthesis blocked at ${powerState.level}% battery. Connect charger or tap 'OVERRIDE THROTTLE' above."
                                            isVideoError = true
                                            return@HudButton
                                        }
                                        isVideoGenerating = true
                                        isVideoError = false
                                        videoStatusMessage = "Initializing Veo 3.1 fast kinetic rendering engine [$videoAspectRatio]..."
                                        CoroutineScope(Dispatchers.Main).launch {
                                            val key = viewModel.prefs.getApiKey("GEMINI")
                                            val res = viewModel.geminiMediaService.generateVideo(
                                                apiKey = key,
                                                prompt = videoPrompt,
                                                aspectRatio = videoAspectRatio,
                                                sourcePhoto = uploadedImage
                                            )
                                            isVideoGenerating = false
                                            if (res.isSuccess) {
                                                val videoResult = res.getOrNull()
                                                videoStatusMessage = "Veo video generation initialized: ${videoResult?.operationId} (${videoResult?.status})"
                                                isVideoError = false
                                            } else {
                                                videoStatusMessage = res.exceptionOrNull()?.message ?: "Video generation failed"
                                                isVideoError = true
                                            }
                                        }
                                    },
                                    icon = Icons.Default.Movie,
                                    accentColor = accentColor,
                                    modifier = Modifier.weight(1.3f)
                                )

                                HudButton(
                                    text = if (uploadedImage != null) "ANIMATE PHOTO" else "CHOOSE PHOTO",
                                    onClick = {
                                        photoPickerLauncher.launch(
                                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                        )
                                    },
                                    icon = Icons.Default.Videocam,
                                    accentColor = if (uploadedImage != null) SuccessEmerald else ReactorCyanGlow,
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            if (isVideoGenerating) {
                                Spacer(modifier = Modifier.height(10.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    CircularProgressIndicator(color = accentColor, modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Synthesizing temporal video frames...", color = accentColor, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                                }
                            }

                            videoStatusMessage?.let { msg ->
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = msg,
                                    color = if (isVideoError) AlertCrimson else SuccessEmerald,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }

                            // Kinetic preview simulation box
                            Spacer(modifier = Modifier.height(12.dp))
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .aspectRatio(if (videoAspectRatio == "16:9") 16f / 9f else 9f / 16f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .border(1.2.dp, accentColor.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                    .background(DarkHologramSurface),
                                contentAlignment = Alignment.Center
                            ) {
                                if (uploadedImage != null) {
                                    Image(
                                        bitmap = uploadedImage!!.asImageBitmap(),
                                        contentDescription = "Source Animation Frame",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(Color.Black.copy(alpha = 0.7f))
                                        .padding(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = "VEO 3.1 PREVIEW // $videoAspectRatio",
                                        color = accentColor,
                                        fontSize = 11.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }

                "TRANSCRIBE" -> {
                    // --- 3. Audio Transcribe Matrix (gemini-3.5-transcribe) ---
                    HudCard(borderColor = accentColor.copy(alpha = 0.4f)) {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "AUDIO TRANSCRIPTION MATRIX",
                                    color = accentColor,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                                HudBadge(label = "gemini-3.5-transcribe", accentColor = SuccessEmerald)
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Transcribe verbal communications directly using the high-accuracy gemini-3.5-transcribe model:",
                                color = HologramTextMuted,
                                fontSize = 11.sp,
                                lineHeight = 15.sp
                            )

                            Spacer(modifier = Modifier.height(12.dp))
                            HudButton(
                                text = if (viewModel.voiceInputManager.isListening.collectAsState().value) "CAPTURING AUDIO RECEPTOR..." else "RECORD & TRANSCRIBE AUDIO",
                                onClick = {
                                    viewModel.startVoiceInput()
                                },
                                icon = Icons.Default.Mic,
                                accentColor = accentColor,
                                modifier = Modifier.fillMaxWidth()
                            )

                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "Or test transcription with sample telemetry audio data:",
                                color = HologramTextDim,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )

                            Spacer(modifier = Modifier.height(6.dp))
                            HudButton(
                                text = if (isTranscribing) "TRANSCRIBING AUDIO..." else "TEST GEMINI 3.5 TRANSCRIBE",
                                onClick = {
                                    if (isTranscribing) return@HudButton
                                    isTranscribing = true
                                    transcribeStatusMessage = "Transmitting audio telemetry to gemini-3.5-transcribe..."
                                    CoroutineScope(Dispatchers.Main).launch {
                                        val key = viewModel.prefs.getApiKey("GEMINI")
                                        // Synthetic test audio buffer (WAV header + tone)
                                        val sampleWav = ByteArray(2048) { (it % 128).toByte() }
                                        val res = viewModel.geminiMediaService.transcribeAudio(key, sampleWav)
                                        isTranscribing = false
                                        if (res.isSuccess) {
                                            transcribedText = res.getOrNull()
                                            transcribeStatusMessage = "Transcription verified."
                                        } else {
                                            transcribeStatusMessage = res.exceptionOrNull()?.message ?: "Transcription error"
                                        }
                                    }
                                },
                                accentColor = ReactorCyanGlow,
                                modifier = Modifier.fillMaxWidth()
                            )

                            transcribeStatusMessage?.let { msg ->
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(text = msg, color = accentColor, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                            }

                            transcribedText?.let { text ->
                                Spacer(modifier = Modifier.height(10.dp))
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(HudCardSurface)
                                        .border(1.dp, SuccessEmerald.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                                        .padding(10.dp)
                                ) {
                                    Column {
                                        Text("VERBATIM TRANSCRIPT:", color = SuccessEmerald, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(text = text, color = HologramTextBright, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                                        Spacer(modifier = Modifier.height(6.dp))
                                        HudButton(
                                            text = "COPY TO CHAT",
                                            onClick = {
                                                viewModel.setInputText(text)
                                                viewModel.setActivePanel("CHAT")
                                            },
                                            accentColor = accentColor
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
