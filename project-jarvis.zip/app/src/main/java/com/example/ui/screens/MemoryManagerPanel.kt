package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.BatteryAlert
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MemoryEntity
import com.example.ui.hud.HudBadge
import com.example.ui.hud.HudButton
import com.example.ui.hud.HudCard
import com.example.ui.hud.HudPanel
import com.example.ui.hud.SyncPolicyHudCard
import com.example.ui.theme.AlertCrimson
import com.example.ui.theme.ArcAmberGlow
import com.example.ui.theme.HologramTextBright
import com.example.ui.theme.HologramTextDim
import com.example.ui.theme.HologramTextMuted
import com.example.ui.theme.HudCardSurface
import com.example.ui.theme.ReactorCyanGlow
import com.example.ui.theme.SuccessEmerald
import com.example.viewmodel.JarvisViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun MemoryManagerPanel(
    viewModel: JarvisViewModel,
    modifier: Modifier = Modifier
) {
    val memories by viewModel.memoriesList.collectAsState()
    val readiness by viewModel.deviceReadiness.collectAsState()
    val accentColor = viewModel.getAccentColor()

    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("ALL") }
    var isAddingMemory by remember { mutableStateOf(false) }
    var newMemoryText by remember { mutableStateOf("") }
    var newMemoryCategory by remember { mutableStateOf(MemoryEntity.CATEGORY_FACT) }
    var showSyncHud by remember { mutableStateOf(false) }

    val categories = listOf("ALL", MemoryEntity.CATEGORY_FACT, MemoryEntity.CATEGORY_PREFERENCE, MemoryEntity.CATEGORY_PROJECT, MemoryEntity.CATEGORY_USER)

    val filteredMemories = memories.filter { m ->
        val matchesCategory = (selectedCategory == "ALL" || m.category == selectedCategory)
        val matchesSearch = searchQuery.isBlank() || m.content.contains(searchQuery, ignoreCase = true)
        matchesCategory && matchesSearch
    }

    HudPanel(
        title = "QUANTUM MEMORY REPOSITORY",
        accentColor = accentColor,
        trailingBadge = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                HudBadge(label = "${filteredMemories.size} ARCHIVED", accentColor = accentColor)
                Spacer(modifier = Modifier.width(6.dp))
                IconButton(
                    onClick = { viewModel.clearAllMemories() },
                    modifier = Modifier.size(28.dp).testTag("purge_all_memories_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteForever,
                        contentDescription = "Purge All Memories",
                        tint = AlertCrimson.copy(alpha = 0.8f),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        },
        modifier = modifier.fillMaxSize()
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // WorkManager Autonomous Background Sync Policy Banner
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(
                        if (readiness.isPolicySatisfied)
                            SuccessEmerald.copy(alpha = 0.12f)
                        else
                            ArcAmberGlow.copy(alpha = 0.12f)
                    )
                    .border(
                        1.dp,
                        if (readiness.isPolicySatisfied)
                            SuccessEmerald.copy(alpha = 0.35f)
                        else
                            ArcAmberGlow.copy(alpha = 0.4f),
                        RoundedCornerShape(6.dp)
                    )
                    .clickable { showSyncHud = !showSyncHud }
                    .padding(horizontal = 10.dp, vertical = 7.dp)
                    .testTag("memory_sync_policy_banner")
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = if (readiness.isCharging) Icons.Default.Bolt else Icons.Default.BatteryAlert,
                            contentDescription = "Sync Policy",
                            tint = if (readiness.isPolicySatisfied) SuccessEmerald else ArcAmberGlow,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (readiness.isPolicySatisfied)
                                "AUTONOMOUS SYNC: READY // CHARGING & WI-FI DETECTED"
                            else
                                "SYNC POLICY ACTIVE // AWAITING CHARGER + WI-FI",
                            color = HologramTextBright,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1
                        )
                    }
                    Text(
                        text = if (showSyncHud) "[-] HIDE HUD" else "[+] SYNC HUD",
                        color = accentColor,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            if (showSyncHud) {
                Spacer(modifier = Modifier.height(8.dp))
                SyncPolicyHudCard(
                    viewModel = viewModel,
                    compact = false
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Search Bar & Add Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = {
                        Text("Search memory archives...", color = HologramTextDim, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                    },
                    leadingIcon = {
                        Icon(imageVector = Icons.Default.Search, contentDescription = "Search", tint = accentColor)
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("memory_search_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = accentColor,
                        unfocusedBorderColor = accentColor.copy(alpha = 0.4f),
                        focusedTextColor = HologramTextBright,
                        unfocusedTextColor = HologramTextBright
                    ),
                    singleLine = true
                )
                Spacer(modifier = Modifier.width(8.dp))
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(accentColor.copy(alpha = 0.2f))
                        .border(1.dp, accentColor, RoundedCornerShape(6.dp))
                        .clickable { isAddingMemory = !isAddingMemory }
                        .testTag("add_memory_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "New Memory",
                        tint = accentColor,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }

            // Quick Add Form
            if (isAddingMemory) {
                Spacer(modifier = Modifier.height(10.dp))
                HudCard(borderColor = accentColor) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Text("ENCODE NEW LONG-TERM MEMORY:", color = accentColor, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(
                            value = newMemoryText,
                            onValueChange = { newMemoryText = it },
                            placeholder = { Text("Enter fact or preference...", color = HologramTextDim, fontSize = 12.sp) },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = accentColor,
                                unfocusedBorderColor = accentColor.copy(alpha = 0.4f),
                                focusedTextColor = HologramTextBright,
                                unfocusedTextColor = HologramTextBright
                            )
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("CATEGORY: $newMemoryCategory", color = HologramTextMuted, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                            HudButton(
                                text = "SAVE MEMORY",
                                onClick = {
                                    if (newMemoryText.isNotBlank()) {
                                        CoroutineScope(Dispatchers.Main).launch {
                                            viewModel.memoryRepo.saveMemory(newMemoryText, newMemoryCategory)
                                            newMemoryText = ""
                                            isAddingMemory = false
                                        }
                                    }
                                },
                                accentColor = accentColor
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Category Filter Row
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(categories) { cat ->
                    val isSelected = selectedCategory == cat
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (isSelected) accentColor.copy(alpha = 0.25f) else HudCardSurface)
                            .border(1.dp, if (isSelected) accentColor else Color.Gray.copy(alpha = 0.3f), RoundedCornerShape(4.dp))
                            .clickable { selectedCategory = cat }
                            .padding(horizontal = 10.dp, vertical = 5.dp)
                    ) {
                        Text(
                            text = cat,
                            color = if (isSelected) accentColor else HologramTextMuted,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Memories List
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (filteredMemories.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 32.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "NO MATCHING MEMORY RECORDS FOUND",
                                color = HologramTextDim,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }

                items(filteredMemories, key = { it.id }) { memory ->
                    MemoryItemCard(
                        memory = memory,
                        accentColor = accentColor,
                        onDelete = { viewModel.deleteMemory(memory.id) }
                    )
                }
            }
        }
    }
}

@Composable
fun MemoryItemCard(
    memory: MemoryEntity,
    accentColor: Color,
    onDelete: () -> Unit
) {
    val dateStr = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(memory.updatedAt))

    HudCard(borderColor = accentColor.copy(alpha = 0.3f)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(3.dp))
                            .background(accentColor.copy(alpha = 0.2f))
                            .padding(horizontal = 5.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = memory.category,
                            color = accentColor,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "ID: #${memory.id} // $dateStr",
                        color = HologramTextDim,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = memory.content,
                    color = HologramTextBright,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    lineHeight = 16.sp
                )
            }

            IconButton(
                onClick = onDelete,
                modifier = Modifier.size(32.dp).testTag("delete_memory_${memory.id}")
            ) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Delete Memory",
                    tint = AlertCrimson.copy(alpha = 0.7f),
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}
