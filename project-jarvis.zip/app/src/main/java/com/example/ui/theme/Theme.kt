package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val JarvisColorScheme = darkColorScheme(
    primary = ArcAmberGlow,
    onPrimary = DeepSpaceBlack,
    primaryContainer = ArcAmberDeep,
    onPrimaryContainer = HologramTextBright,
    secondary = ReactorCyanGlow,
    onSecondary = DeepSpaceBlack,
    secondaryContainer = ReactorCyanDeep,
    onSecondaryContainer = HologramTextBright,
    tertiary = ArcFlameOrange,
    onTertiary = DeepSpaceBlack,
    background = DeepSpaceBlack,
    onBackground = HologramTextBright,
    surface = DarkHologramSurface,
    onSurface = HologramTextBright,
    surfaceVariant = HudCardSurface,
    onSurfaceVariant = HologramTextMuted,
    error = AlertCrimson,
    onError = Color.White
)

@Composable
fun JarvisTheme(
    accentColor: Color = ArcAmberGlow,
    content: @Composable () -> Unit
) {
    val dynamicScheme = JarvisColorScheme.copy(
        primary = accentColor,
        primaryContainer = accentColor.copy(alpha = 0.3f)
    )

    MaterialTheme(
        colorScheme = dynamicScheme,
        typography = Typography,
        content = content
    )
}

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    JarvisTheme(content = content)
}
