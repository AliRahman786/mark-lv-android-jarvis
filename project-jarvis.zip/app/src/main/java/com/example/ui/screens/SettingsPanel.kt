package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.prefs.PreferencesManager
import com.example.ui.hud.BatteryThrottleHudCard
import com.example.ui.hud.HudBadge
import com.example.ui.hud.HudButton
import com.example.ui.hud.HudCard
import com.example.ui.hud.HudPanel
import com.example.ui.hud.SyncPolicyHudCard
import com.example.ui.theme.AlertCrimson
import com.example.ui.theme.ArcAmberGlow
import com.example.ui.theme.HologramTextBright
import com.example.ui.theme.HologramTextDim
import com.example.ui.theme.HologramTextMuted
import com.example.ui.theme.HudCardSurface
import com.example.ui.theme.ProcessingViolet
import com.example.ui.theme.ReactorCyanGlow
import com.example.ui.theme.SuccessEmerald
import com.example.viewmodel.ApiValidationState
import com.example.viewmodel.JarvisViewModel

@Composable
fun SettingsPanel(
    viewModel: JarvisViewModel,
    modifier: Modifier = Modifier
) {
    val accentColor = viewModel.getAccentColor()
    val scrollState = rememberScrollState()
    val validationState by viewModel.apiValidationState.collectAsState()

    var aiProvider by remember { mutableStateOf(viewModel.prefs.getAiProvider()) }
    var apiKey by remember { mutableStateOf(viewModel.prefs.getApiKey(aiProvider)) }
    var selectedModel by remember { mutableStateOf(viewModel.prefs.getModel(aiProvider)) }
    var voiceIn by remember { mutableStateOf(viewModel.prefs.getVoiceInputProvider()) }
    var voiceOut by remember { mutableStateOf(viewModel.prefs.getVoiceOutputProvider()) }
    var assistantName by remember { mutableStateOf(viewModel.prefs.getAssistantName()) }
    var userName by remember { mutableStateOf(viewModel.prefs.getUserName()) }
    var storageMode by remember { mutableStateOf(viewModel.prefs.getStorageMode()) }
    var cloudSyncEnabled by remember { mutableStateOf(viewModel.prefs.isCloudSyncEnabled()) }
    var accentTheme by remember { mutableStateOf(viewModel.prefs.getAccentColor()) }
    var showKey by remember { mutableStateOf(false) }

    HudPanel(
        title = "SYSTEM PREFERENCES & SECURITY MATRIX",
        accentColor = accentColor,
        trailingBadge = {
            HudBadge(label = "MIN_SDK 34 SECURED", accentColor = SuccessEmerald)
        },
        modifier = modifier.fillMaxSize()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
        ) {
            // 1. AI Provider Section
            HudCard(borderColor = accentColor.copy(alpha = 0.35f)) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "1. COGNITIVE AI PROVIDER",
                        color = accentColor,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(
                            PreferencesManager.PROVIDER_GEMINI to "Gemini",
                            PreferencesManager.PROVIDER_OPENAI to "OpenAI",
                            PreferencesManager.PROVIDER_GROQ to "Groq"
                        ).forEach { (id, label) ->
                            val isSel = aiProvider == id
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(if (isSel) accentColor.copy(alpha = 0.25f) else HudCardSurface)
                                    .border(1.dp, if (isSel) accentColor else Color.Gray.copy(alpha = 0.3f), RoundedCornerShape(4.dp))
                                    .clickable {
                                        aiProvider = id
                                        viewModel.prefs.setAiProvider(id)
                                        apiKey = viewModel.prefs.getApiKey(id)
                                        selectedModel = viewModel.prefs.getModel(id)
                                    }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = label,
                                    color = if (isSel) accentColor else HologramTextMuted,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // API Key Field
                    OutlinedTextField(
                        value = apiKey,
                        onValueChange = {
                            apiKey = it
                            viewModel.prefs.setApiKey(aiProvider, it)
                        },
                        label = { Text("$aiProvider API KEY") },
                        visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = accentColor,
                            unfocusedBorderColor = accentColor.copy(alpha = 0.4f),
                            focusedTextColor = HologramTextBright,
                            unfocusedTextColor = HologramTextBright
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(HudCardSurface)
                                .clickable { showKey = !showKey }
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(if (showKey) "MASK" else "REVEAL", color = accentColor, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        }

                        HudButton(
                            text = "TEST CONNECTION",
                            onClick = {
                                viewModel.testActiveApiKey(aiProvider, apiKey, selectedModel)
                            },
                            accentColor = accentColor,
                            testTag = "settings_test_key"
                        )
                    }

                    when (val st = validationState) {
                        is ApiValidationState.Validating -> {
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                CircularProgressIndicator(color = accentColor, modifier = Modifier.size(16.dp), strokeWidth = 1.5.dp)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Verifying API token...", color = accentColor, fontSize = 11.sp)
                            }
                        }
                        is ApiValidationState.Success -> {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(st.message, color = SuccessEmerald, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        }
                        is ApiValidationState.Error -> {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(st.message, color = AlertCrimson, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        }
                        ApiValidationState.Idle -> {}
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // 2. Voice Subsystems
            HudCard(borderColor = accentColor.copy(alpha = 0.35f)) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "2. VOICE & SPEECH CONFIGURATION",
                        color = accentColor,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("VOICE INPUT: $voiceIn", color = HologramTextBright, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    Text("VOICE SYNTHESIZER: $voiceOut", color = HologramTextBright, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.height(6.dp))
                    HudButton(
                        text = "TEST VOCAL AUDIO SYNTHESIS",
                        onClick = {
                            viewModel.speakVoice("Vocal synthesis audio channel operational. Ready for orders.")
                        },
                        accentColor = accentColor
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // 3. Storage & Cloud Sync
            HudCard(borderColor = accentColor.copy(alpha = 0.35f)) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "3. STORAGE ARCHITECTURE & WORKMANAGER SYNC",
                        color = accentColor,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("CURRENT MODE: $storageMode", color = HologramTextBright, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    Text("LAST SYNC: ${viewModel.storageManager.getLastSyncString()}", color = HologramTextDim, fontSize = 10.sp, fontFamily = FontFamily.Monospace)

                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("CLOUD STORAGE SYNC", color = HologramTextBright, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        Switch(
                            checked = cloudSyncEnabled,
                            onCheckedChange = {
                                cloudSyncEnabled = it
                                viewModel.prefs.setCloudSyncEnabled(it)
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = accentColor,
                                checkedTrackColor = accentColor.copy(alpha = 0.4f)
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    // Dedicated WorkManager Battery-Optimized Policy HUD
                    SyncPolicyHudCard(
                        viewModel = viewModel,
                        modifier = Modifier.fillMaxWidth(),
                        compact = false
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // 4. Dedicated Arc Reactor Power Management & Dynamic AI Throttling
            BatteryThrottleHudCard(
                viewModel = viewModel,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(10.dp))

            // 5. Accent Theme Picker
            HudCard(borderColor = accentColor.copy(alpha = 0.35f)) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "5. HOLOGRAPHIC ACCENT SPECTRUM",
                        color = accentColor,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(
                            "ARC_AMBER" to ArcAmberGlow,
                            "REACTOR_CYAN" to ReactorCyanGlow,
                            "STEALTH_VIOLET" to ProcessingViolet,
                            "ALERT_CRIMSON" to AlertCrimson
                        ).forEach { (name, col) ->
                            val isSel = accentTheme == name
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(36.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(col.copy(alpha = 0.3f))
                                    .border(if (isSel) 2.dp else 1.dp, if (isSel) col else col.copy(alpha = 0.4f), RoundedCornerShape(4.dp))
                                    .clickable {
                                        accentTheme = name
                                        viewModel.prefs.setAccentColor(name)
                                    }
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // 5. Data Privacy & Wipe
            HudCard(borderColor = AlertCrimson.copy(alpha = 0.4f)) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "5. DATA PRIVACY & PURGE CONTROLS",
                        color = AlertCrimson,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Irreversibly delete stored conversation logs or purge long-term memory archives.",
                        color = HologramTextMuted,
                        fontSize = 11.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        HudButton(
                            text = "CLEAR CHAT",
                            onClick = { viewModel.clearConversationHistory() },
                            accentColor = HologramTextMuted,
                            modifier = Modifier.weight(1f)
                        )
                        HudButton(
                            text = "PURGE ALL",
                            onClick = { viewModel.clearAllMemories() },
                            icon = Icons.Default.DeleteForever,
                            accentColor = AlertCrimson,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }
}
