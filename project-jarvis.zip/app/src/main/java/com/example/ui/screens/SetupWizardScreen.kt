package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.prefs.PreferencesManager
import com.example.ui.hud.HudButton
import com.example.ui.hud.HudPanel
import com.example.ui.theme.AlertCrimson
import com.example.ui.theme.DeepSpaceBlack
import com.example.ui.theme.HologramTextBright
import com.example.ui.theme.HologramTextDim
import com.example.ui.theme.HologramTextMuted
import com.example.ui.theme.HudCardSurface
import com.example.ui.theme.ReactorCyanGlow
import com.example.ui.theme.SuccessEmerald
import com.example.viewmodel.ApiValidationState
import com.example.viewmodel.JarvisViewModel

@Composable
fun SetupWizardScreen(
    viewModel: JarvisViewModel,
    modifier: Modifier = Modifier
) {
    val currentStep by viewModel.setupStep.collectAsState()
    val validationState by viewModel.apiValidationState.collectAsState()
    val accentColor = viewModel.getAccentColor()
    val scrollState = rememberScrollState()

    var selectedProvider by remember { mutableStateOf(viewModel.prefs.getAiProvider()) }
    var enteredApiKey by remember { mutableStateOf(viewModel.prefs.getApiKey(selectedProvider)) }
    var selectedModel by remember { mutableStateOf(viewModel.prefs.getModel(selectedProvider)) }
    var assistantName by remember { mutableStateOf(viewModel.prefs.getAssistantName()) }
    var userName by remember { mutableStateOf(viewModel.prefs.getUserName()) }
    var storageMode by remember { mutableStateOf(viewModel.prefs.getStorageMode()) }
    var voiceInput by remember { mutableStateOf(viewModel.prefs.getVoiceInputProvider()) }
    var voiceOutput by remember { mutableStateOf(viewModel.prefs.getVoiceOutputProvider()) }
    var showApiKey by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(DeepSpaceBlack)
            .statusBarsPadding()
            .padding(16.dp)
            .testTag("setup_wizard_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                // Header / Step Indicator
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "J.A.R.V.I.S. MARK-LIV",
                            color = accentColor,
                            fontSize = 20.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 2.sp
                        )
                        Text(
                            text = "INITIALIZATION PROTOCOL // STEP $currentStep OF 13",
                            color = HologramTextMuted,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 1.sp
                        )
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(accentColor.copy(alpha = 0.2f))
                            .border(1.dp, accentColor, RoundedCornerShape(4.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "${(currentStep * 100) / 13}% READY",
                            color = accentColor,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Step Body
                when (currentStep) {
                    1 -> {
                        HudPanel(title = "01 // WELCOME TO MARK-LIV", accentColor = accentColor) {
                            Text(
                                text = "Greetings. I am JARVIS (Just A Rather Very Intelligent System), running natively on Android 14+.",
                                color = HologramTextBright,
                                fontSize = 14.sp
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "This wizard will calibrate your AI intelligence core, secure Android Keystore credentials, voice subsystems, gesture sensors, and quantum memory matrices.",
                                color = HologramTextMuted,
                                fontSize = 13.sp
                            )
                            Spacer(modifier = Modifier.height(14.dp))
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(HudCardSurface)
                                    .border(1.dp, accentColor.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
                                    .padding(12.dp)
                            ) {
                                Column {
                                    Text("ARCHITECTURE SPECIFICATIONS:", color = accentColor, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                                    Text("• MIN_SDK: 34 (Android 14+ Enforced)", color = HologramTextBright, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                                    Text("• PERSISTENCE: Room SQL Local Archive", color = HologramTextBright, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                                    Text("• VISION: CameraX Edge Gesture Telemetry", color = HologramTextBright, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                                    Text("• AI CORE: Multi-Engine Autonomous Reasoning", color = HologramTextBright, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                                }
                            }
                        }
                    }

                    2 -> {
                        HudPanel(title = "02 // SELECT AI PROVIDER", accentColor = accentColor) {
                            Text("Select primary cognitive intelligence core:", color = HologramTextMuted, fontSize = 13.sp)
                            Spacer(modifier = Modifier.height(12.dp))
                            listOf(
                                Triple(PreferencesManager.PROVIDER_GEMINI, "Google Gemini", "Default first-class neural engine, multimodal & tools"),
                                Triple(PreferencesManager.PROVIDER_OPENAI, "OpenAI", "GPT-4o standard reasoning & function calling"),
                                Triple(PreferencesManager.PROVIDER_GROQ, "Groq", "High-speed LPU inference with Llama 3.3")
                            ).forEach { (id, name, desc) ->
                                val isSelected = selectedProvider == id
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 5.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (isSelected) accentColor.copy(alpha = 0.2f) else HudCardSurface)
                                        .border(1.2.dp, if (isSelected) accentColor else Color.Gray.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
                                        .clickable {
                                            selectedProvider = id
                                            viewModel.prefs.setAiProvider(id)
                                            enteredApiKey = viewModel.prefs.getApiKey(id)
                                            selectedModel = viewModel.prefs.getModel(id)
                                        }
                                        .padding(12.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.Security,
                                            contentDescription = name,
                                            tint = if (isSelected) accentColor else HologramTextDim,
                                            modifier = Modifier.size(24.dp)
                                        )
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column {
                                            Text(name, color = HologramTextBright, fontSize = 14.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                            Text(desc, color = HologramTextMuted, fontSize = 11.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    3 -> {
                        HudPanel(title = "03 // ENTER $selectedProvider API KEY", accentColor = accentColor) {
                            Text("Provide API key for $selectedProvider. Keys are stored securely in Android storage.", color = HologramTextMuted, fontSize = 13.sp)
                            Spacer(modifier = Modifier.height(14.dp))
                            OutlinedTextField(
                                value = enteredApiKey,
                                onValueChange = {
                                    enteredApiKey = it
                                    viewModel.prefs.setApiKey(selectedProvider, it)
                                },
                                label = { Text("$selectedProvider API KEY") },
                                visualTransformation = if (showApiKey) VisualTransformation.None else PasswordVisualTransformation(),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("api_key_input"),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = accentColor,
                                    unfocusedBorderColor = accentColor.copy(alpha = 0.4f),
                                    focusedTextColor = HologramTextBright,
                                    unfocusedTextColor = HologramTextBright
                                )
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(HudCardSurface)
                                        .clickable { showApiKey = !showApiKey }
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(if (showApiKey) "MASK KEY" else "REVEAL KEY", color = accentColor, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Text("Tip: You can change keys anytime in Settings.", color = HologramTextDim, fontSize = 11.sp)
                            }
                        }
                    }

                    4 -> {
                        HudPanel(title = "04 // VALIDATE API CREDENTIALS", accentColor = accentColor) {
                            Text("Verify network connectivity and key authenticity with $selectedProvider:", color = HologramTextMuted, fontSize = 13.sp)
                            Spacer(modifier = Modifier.height(14.dp))
                            HudButton(
                                text = "TEST API CONNECTION",
                                onClick = {
                                    viewModel.testActiveApiKey(selectedProvider, enteredApiKey, selectedModel)
                                },
                                testTag = "test_api_button",
                                accentColor = accentColor,
                                modifier = Modifier.fillMaxWidth()
                            )

                            Spacer(modifier = Modifier.height(14.dp))
                            when (val st = validationState) {
                                is ApiValidationState.Validating -> {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        CircularProgressIndicator(color = accentColor, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Text("Pinging $selectedProvider neural endpoint...", color = accentColor, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                                    }
                                }
                                is ApiValidationState.Success -> {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(SuccessEmerald.copy(alpha = 0.15f))
                                            .border(1.dp, SuccessEmerald, RoundedCornerShape(6.dp))
                                            .padding(10.dp)
                                    ) {
                                        Text(st.message, color = SuccessEmerald, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                                    }
                                }
                                is ApiValidationState.Error -> {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(AlertCrimson.copy(alpha = 0.15f))
                                            .border(1.dp, AlertCrimson, RoundedCornerShape(6.dp))
                                            .padding(10.dp)
                                    ) {
                                        Text(st.message, color = AlertCrimson, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                                    }
                                }
                                ApiValidationState.Idle -> {
                                    Text("Press 'TEST API CONNECTION' to run live ping diagnostics.", color = HologramTextDim, fontSize = 11.sp)
                                }
                            }
                        }
                    }

                    5 -> {
                        HudPanel(title = "05 // CHOOSE AI MODEL", accentColor = accentColor) {
                            Text("Select default neural model for $selectedProvider:", color = HologramTextMuted, fontSize = 13.sp)
                            Spacer(modifier = Modifier.height(12.dp))
                            val models = when (selectedProvider) {
                                PreferencesManager.PROVIDER_GEMINI -> listOf("gemini-3.5-flash", "gemini-3.1-pro-preview", "gemini-2.5-flash")
                                PreferencesManager.PROVIDER_OPENAI -> listOf("gpt-4o", "gpt-4o-mini", "gpt-4-turbo")
                                else -> listOf("llama-3.3-70b-versatile", "llama-3.1-8b-instant", "mixtral-8x7b-32768")
                            }
                            models.forEach { m ->
                                val isSelected = selectedModel == m
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (isSelected) accentColor.copy(alpha = 0.2f) else HudCardSurface)
                                        .border(1.dp, if (isSelected) accentColor else Color.Gray.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
                                        .clickable {
                                            selectedModel = m
                                            viewModel.prefs.setModel(selectedProvider, m)
                                        }
                                        .padding(12.dp)
                                ) {
                                    Text(m, color = if (isSelected) accentColor else HologramTextBright, fontSize = 13.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    6 -> {
                        HudPanel(title = "06 // CONFIGURE VOICE INPUT", accentColor = accentColor) {
                            Text("Select speech-to-text recognition provider:", color = HologramTextMuted, fontSize = 13.sp)
                            Spacer(modifier = Modifier.height(12.dp))
                            listOf(
                                PreferencesManager.PROVIDER_ANDROID_NATIVE to "Android Native Speech Recognizer (On-Device, Zero Latency)",
                                PreferencesManager.PROVIDER_GEMINI to "Gemini Voice Audio Pipeline",
                                PreferencesManager.PROVIDER_OPENAI to "OpenAI Whisper Transcription"
                            ).forEach { (id, desc) ->
                                val isSelected = voiceInput == id
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 5.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (isSelected) accentColor.copy(alpha = 0.2f) else HudCardSurface)
                                        .border(1.dp, if (isSelected) accentColor else Color.Gray.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
                                        .clickable {
                                            voiceInput = id
                                            viewModel.prefs.setVoiceInputProvider(id)
                                        }
                                        .padding(12.dp)
                                ) {
                                    Text(desc, color = if (isSelected) accentColor else HologramTextBright, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                                }
                            }
                        }
                    }

                    7 -> {
                        HudPanel(title = "07 // CONFIGURE VOICE OUTPUT", accentColor = accentColor) {
                            Text("Select vocal synthesizer for JARVIS responses:", color = HologramTextMuted, fontSize = 13.sp)
                            Spacer(modifier = Modifier.height(12.dp))
                            listOf(
                                PreferencesManager.PROVIDER_ANDROID_NATIVE to "Android TextToSpeech (Calibrated British Deep Vocal Pitch)",
                                PreferencesManager.PROVIDER_GEMINI to "Gemini Prebuilt Voice Audio",
                                PreferencesManager.PROVIDER_OPENAI to "OpenAI TTS Audio"
                            ).forEach { (id, desc) ->
                                val isSelected = voiceOutput == id
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 5.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (isSelected) accentColor.copy(alpha = 0.2f) else HudCardSurface)
                                        .border(1.dp, if (isSelected) accentColor else Color.Gray.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
                                        .clickable {
                                            voiceOutput = id
                                            viewModel.prefs.setVoiceOutputProvider(id)
                                        }
                                        .padding(12.dp)
                                ) {
                                    Text(desc, color = if (isSelected) accentColor else HologramTextBright, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                                }
                            }
                        }
                    }

                    8 -> {
                        HudPanel(title = "08 // ASSISTANT NAME", accentColor = accentColor) {
                            Text("Customize the call-sign of your tactical AI assistant:", color = HologramTextMuted, fontSize = 13.sp)
                            Spacer(modifier = Modifier.height(14.dp))
                            OutlinedTextField(
                                value = assistantName,
                                onValueChange = {
                                    assistantName = it
                                    viewModel.prefs.setAssistantName(it)
                                },
                                label = { Text("ASSISTANT NAME") },
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = accentColor,
                                    unfocusedBorderColor = accentColor.copy(alpha = 0.4f),
                                    focusedTextColor = HologramTextBright,
                                    unfocusedTextColor = HologramTextBright
                                )
                            )
                        }
                    }

                    9 -> {
                        HudPanel(title = "09 // USER PROFILE NAME", accentColor = accentColor) {
                            Text("How should JARVIS address you?", color = HologramTextMuted, fontSize = 13.sp)
                            Spacer(modifier = Modifier.height(14.dp))
                            OutlinedTextField(
                                value = userName,
                                onValueChange = {
                                    userName = it
                                    viewModel.prefs.setUserName(it)
                                },
                                label = { Text("USER NAME") },
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = accentColor,
                                    unfocusedBorderColor = accentColor.copy(alpha = 0.4f),
                                    focusedTextColor = HologramTextBright,
                                    unfocusedTextColor = HologramTextBright
                                )
                            )
                        }
                    }

                    10 -> {
                        HudPanel(title = "10 // STORAGE ARCHITECTURE", accentColor = accentColor) {
                            Text("Select data storage and sync mechanism:", color = HologramTextMuted, fontSize = 13.sp)
                            Spacer(modifier = Modifier.height(12.dp))
                            listOf(
                                PreferencesManager.STORAGE_DEVICE to "Device Storage (Local Room SQL, 100% Private, Offline)",
                                PreferencesManager.STORAGE_CLOUD_DRIVE to "Google Drive Cloud Storage (User Cloud Archive)"
                            ).forEach { (id, desc) ->
                                val isSelected = storageMode == id
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 5.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (isSelected) accentColor.copy(alpha = 0.2f) else HudCardSurface)
                                        .border(1.dp, if (isSelected) accentColor else Color.Gray.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
                                        .clickable {
                                            storageMode = id
                                            viewModel.prefs.setStorageMode(id)
                                        }
                                        .padding(12.dp)
                                ) {
                                    Text(desc, color = if (isSelected) accentColor else HologramTextBright, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                                }
                            }
                        }
                    }

                    11 -> {
                        HudPanel(title = "11 // ANDROID PERMISSIONS", accentColor = accentColor) {
                            Text("JARVIS Mark-LIV requires specific Android 14+ permissions:", color = HologramTextMuted, fontSize = 13.sp)
                            Spacer(modifier = Modifier.height(10.dp))
                            Text("• RECORD_AUDIO: Used exclusively during voice listening.", color = HologramTextBright, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                            Text("• CAMERA: Used strictly on-device for hand gesture recognition and visual reasoning. Zero silent uploads.", color = HologramTextBright, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                            Text("• POST_NOTIFICATIONS: For scheduled task reminders and morning briefings.", color = HologramTextBright, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                        }
                    }

                    12 -> {
                        HudPanel(title = "12 // SYSTEM SELF-TEST", accentColor = accentColor) {
                            Text("DIAGNOSTIC SUBSYSTEM CHECKOUT:", color = accentColor, fontSize = 12.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(10.dp))
                            Text("✓ Database Core: Room SQLite Initialized", color = SuccessEmerald, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                            Text("✓ Tool Subsystem: 15 Native Tools Bound", color = SuccessEmerald, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                            Text("✓ Gesture Engine: CameraX Edge Analyzer Ready", color = SuccessEmerald, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                            Text("✓ 3D Core Renderer: Procedural Gyroscope Loaded", color = SuccessEmerald, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                            Text("✓ AI Provider: $selectedProvider ($selectedModel)", color = SuccessEmerald, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                            Text("✓ Security: MinSdk 34 Enforced", color = SuccessEmerald, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        }
                    }

                    13 -> {
                        HudPanel(title = "13 // INITIALIZATION READY", accentColor = accentColor) {
                            Text(
                                text = "All subsystems calibrated. Ready to engage Mark-LIV holographic command interface.",
                                color = HologramTextBright,
                                fontSize = 14.sp
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            HudButton(
                                text = "INITIALIZE JARVIS MARK-LIV",
                                onClick = {
                                    viewModel.completeOnboarding()
                                },
                                testTag = "finish_setup_button",
                                accentColor = accentColor,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }

            // Bottom Navigation Buttons
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                if (currentStep > 1) {
                    HudButton(
                        text = "PREVIOUS",
                        onClick = { viewModel.setSetupStep(currentStep - 1) },
                        icon = Icons.Default.ArrowBack,
                        accentColor = accentColor
                    )
                } else {
                    Spacer(modifier = Modifier.width(48.dp))
                }

                if (currentStep < 13) {
                    HudButton(
                        text = "NEXT",
                        onClick = { viewModel.setSetupStep(currentStep + 1) },
                        icon = Icons.Default.ArrowForward,
                        accentColor = accentColor
                    )
                }
            }
        }
    }
}
