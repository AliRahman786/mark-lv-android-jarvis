package com.example.ui.hud

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.ui.theme.AlertCrimson
import com.example.ui.theme.ArcAmberBright
import com.example.ui.theme.ArcAmberGlow
import com.example.ui.theme.ArcFlameOrange
import com.example.ui.theme.ReactorCyanBright
import com.example.ui.theme.ReactorCyanGlow
import com.example.voice.VoiceState
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun JarvisCoreView(
    voiceState: VoiceState,
    audioAmplitude: Float,
    accentColor: Color,
    modifier: Modifier = Modifier,
    onCoreTap: () -> Unit = {}
) {
    // 3D Euler Angles for User Touch Interaction
    var rotationYaw by remember { mutableFloatStateOf(0f) }
    var rotationPitch by remember { mutableFloatStateOf(0f) }
    var coreScale by remember { mutableFloatStateOf(1f) }

    // Infinite transitions for smooth procedural rotation
    val infiniteTransition = rememberInfiniteTransition(label = "core_anim")

    // Rotation speeds based on AI thinking/listening state
    val animDuration = when (voiceState) {
        VoiceState.THINKING -> 3000
        VoiceState.LISTENING -> 5000
        VoiceState.SPEAKING -> 4000
        else -> 10000
    }

    val baseRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = animDuration, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "base_spin"
    )

    val counterRotation by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = (animDuration * 1.4f).toInt(), easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "counter_spin"
    )

    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1800, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    // Dynamic color tuning based on state
    val primaryGlowColor = when (voiceState) {
        VoiceState.ERROR -> AlertCrimson
        VoiceState.LISTENING -> ReactorCyanGlow
        VoiceState.THINKING -> ReactorCyanBright
        VoiceState.SPEAKING -> ArcAmberBright
        else -> accentColor
    }

    val secondaryGlowColor = when (voiceState) {
        VoiceState.ERROR -> AlertCrimson.copy(alpha = 0.6f)
        VoiceState.LISTENING -> ReactorCyanBright.copy(alpha = 0.8f)
        VoiceState.THINKING -> ArcAmberGlow
        VoiceState.SPEAKING -> ArcFlameOrange
        else -> ArcFlameOrange
    }

    Box(
        modifier = modifier
            .size(340.dp)
            .testTag("jarvis_3d_core")
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                    rotationYaw = (rotationYaw + pan.x * 0.4f) % 360f
                    rotationPitch = (rotationPitch - pan.y * 0.4f).coerceIn(-45f, 45f)
                    coreScale = (coreScale * zoom).coerceIn(0.75f, 1.45f)
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val maxRadius = (size.minDimension / 2f) * 0.95f * coreScale
            val effectiveAmplitude = audioAmplitude.coerceIn(0f, 1f)

            // 1. Layer 1: Ambient Quantum Singularity Glow (Background Radial Gradient)
            val corePulse = (pulseScale + effectiveAmplitude * 0.35f)
            val coreGlowRadius = maxRadius * 0.38f * corePulse
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        primaryGlowColor.copy(alpha = 0.55f),
                        secondaryGlowColor.copy(alpha = 0.25f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = coreGlowRadius * 1.6f
                ),
                radius = coreGlowRadius * 1.6f,
                center = center
            )

            // 2. Layer 2: Outer Holographic Telemetry Ring with Degree Ticks
            val outerRadius = maxRadius * 0.92f
            rotate(degrees = baseRotation * 0.25f + rotationYaw, pivot = center) {
                drawCircle(
                    color = primaryGlowColor.copy(alpha = 0.35f),
                    radius = outerRadius,
                    center = center,
                    style = Stroke(
                        width = 1.5.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(18f, 12f, 6f, 12f), 0f)
                    )
                )

                // 24 Angular Telemetry Hash Marks
                for (i in 0 until 24) {
                    val angle = (i * 15f) * (PI / 180f)
                    val tickLen = if (i % 6 == 0) 12.dp.toPx() else 6.dp.toPx()
                    val p1 = Offset(
                        center.x + (outerRadius - tickLen) * cos(angle).toFloat(),
                        center.y + (outerRadius - tickLen) * sin(angle).toFloat()
                    )
                    val p2 = Offset(
                        center.x + outerRadius * cos(angle).toFloat(),
                        center.y + outerRadius * sin(angle).toFloat()
                    )
                    drawLine(
                        color = if (i % 6 == 0) primaryGlowColor else primaryGlowColor.copy(alpha = 0.4f),
                        start = p1,
                        end = p2,
                        strokeWidth = if (i % 6 == 0) 2.dp.toPx() else 1.dp.toPx()
                    )
                }
            }

            // 3. Layer 3: 3D Orbital Gyroscopic Ring (Simulates 3D Perspective Tilted Ellipse)
            val gyroRadius = maxRadius * 0.76f
            val pitchFactor = cos(rotationPitch * (PI / 180f)).toFloat().coerceIn(0.25f, 1f)
            rotate(degrees = counterRotation + rotationYaw * 0.7f, pivot = center) {
                // Elliptical gyroscopic ring with pitch perspective
                drawOval(
                    color = secondaryGlowColor.copy(alpha = 0.75f),
                    topLeft = Offset(center.x - gyroRadius, center.y - (gyroRadius * pitchFactor)),
                    size = Size(gyroRadius * 2f, (gyroRadius * 2f) * pitchFactor),
                    style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
                )

                // Four gyroscopic orbital nodes
                val nodeAngles = listOf(0.0, PI / 2.0, PI, 3.0 * PI / 2.0)
                for (a in nodeAngles) {
                    val nx = center.x + gyroRadius * cos(a).toFloat()
                    val ny = center.y + (gyroRadius * pitchFactor) * sin(a).toFloat()
                    drawCircle(
                        color = primaryGlowColor,
                        radius = 4.dp.toPx(),
                        center = Offset(nx, ny)
                    )
                    drawCircle(
                        color = Color.White,
                        radius = 1.5.dp.toPx(),
                        center = Offset(nx, ny)
                    )
                }
            }

            // 4. Layer 4: Segmented Arc Reactor Core (Iconic Mark-LIV Tri-Sector Rings)
            val reactorRadius = maxRadius * 0.58f
            rotate(degrees = baseRotation * 1.2f + rotationYaw * 0.5f, pivot = center) {
                for (sec in 0 until 3) {
                    val startAngle = sec * 120f + 10f
                    val sweepAngle = 100f
                    drawArc(
                        color = primaryGlowColor,
                        startAngle = startAngle,
                        sweepAngle = sweepAngle,
                        useCenter = false,
                        topLeft = Offset(center.x - reactorRadius, center.y - reactorRadius),
                        size = Size(reactorRadius * 2f, reactorRadius * 2f),
                        style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
                    )
                }
            }

            // 5. Layer 5: Reactive Audio Amplitude Soundwave Ribbons
            if (effectiveAmplitude > 0.05f || voiceState == VoiceState.SPEAKING || voiceState == VoiceState.LISTENING) {
                val waveCount = 3
                for (w in 1..waveCount) {
                    val waveRadius = reactorRadius + (w * 18.dp.toPx() * (effectiveAmplitude + 0.15f))
                    val waveAlpha = (0.7f / w) * (effectiveAmplitude + 0.2f).coerceIn(0.1f, 1f)
                    drawCircle(
                        color = primaryGlowColor.copy(alpha = waveAlpha),
                        radius = waveRadius,
                        center = center,
                        style = Stroke(width = 1.2.dp.toPx())
                    )
                }
            }

            // 6. Layer 6: Inner Glowing Arc Singularity with Quantum Core Iris
            val irisRadius = maxRadius * 0.32f * corePulse
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        Color.White,
                        primaryGlowColor,
                        primaryGlowColor.copy(alpha = 0.4f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = irisRadius
                ),
                radius = irisRadius,
                center = center
            )

            // Inner triangular energy prism
            val triRadius = irisRadius * 0.55f
            val triPath = Path().apply {
                val a0 = -PI / 2.0 + (baseRotation * (PI / 180.0) * 0.5)
                val a1 = a0 + 2.0 * PI / 3.0
                val a2 = a0 + 4.0 * PI / 3.0
                moveTo(center.x + triRadius * cos(a0).toFloat(), center.y + triRadius * sin(a0).toFloat())
                lineTo(center.x + triRadius * cos(a1).toFloat(), center.y + triRadius * sin(a1).toFloat())
                lineTo(center.x + triRadius * cos(a2).toFloat(), center.y + triRadius * sin(a2).toFloat())
                close()
            }
            drawPath(
                path = triPath,
                color = Color.White.copy(alpha = 0.9f),
                style = Stroke(width = 2.dp.toPx())
            )

            // Floating procedural particle cloud
            val particleCount = 12
            for (p in 0 until particleCount) {
                val pAngle = (p * (2 * PI / particleCount) + (baseRotation * 0.02f * (p % 3 + 1)))
                val pDist = outerRadius * (0.4f + (0.5f * ((p * 7 % 10) / 10f)))
                val px = center.x + pDist * cos(pAngle).toFloat()
                val py = center.y + pDist * sin(pAngle).toFloat() * pitchFactor
                drawCircle(
                    color = if (p % 2 == 0) primaryGlowColor else secondaryGlowColor,
                    radius = 2.dp.toPx(),
                    center = Offset(px, py)
                )
            }
        }
    }
}
