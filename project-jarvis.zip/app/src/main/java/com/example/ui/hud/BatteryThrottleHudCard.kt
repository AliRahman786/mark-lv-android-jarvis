package com.example.ui.hud

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryAlert
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.Power
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.battery.AiThrottleLevel
import com.example.data.battery.PluggedSource
import com.example.ui.theme.AlertCrimson
import com.example.ui.theme.ArcAmberGlow
import com.example.ui.theme.DarkHologramSurface
import com.example.ui.theme.HologramTextBright
import com.example.ui.theme.HologramTextDim
import com.example.ui.theme.HologramTextMuted
import com.example.ui.theme.HudCardSurface
import com.example.ui.theme.ReactorCyanBright
import com.example.ui.theme.ReactorCyanGlow
import com.example.ui.theme.SuccessEmerald
import com.example.viewmodel.JarvisViewModel

/**
 * Tactical Iron Man / JARVIS HUD component that visualizes live power telemetry,
 * dynamic AI throttling profiles, and provides manual simulation/testing controls.
 */
@Composable
fun BatteryThrottleHudCard(
    viewModel: JarvisViewModel,
    modifier: Modifier = Modifier
) {
    val powerState by viewModel.batteryPowerState.collectAsState()
    val accentColor = viewModel.getAccentColor()

    var showControls by remember { mutableStateOf(false) }

    val throttleColor by animateColorAsState(
        targetValue = when (powerState.throttleLevel) {
            AiThrottleLevel.UNCONSTRAINED -> if (powerState.isCharging) SuccessEmerald else ReactorCyanGlow
            AiThrottleLevel.BALANCED -> ArcAmberGlow
            AiThrottleLevel.CRITICAL_THROTTLED -> AlertCrimson
        },
        animationSpec = tween(400),
        label = "throttleColor"
    )

    val animatedLevel by animateFloatAsState(
        targetValue = powerState.level / 100f,
        animationSpec = tween(durationMillis = 600, easing = FastOutSlowInEasing),
        label = "batteryLevel"
    )

    HudCard(
        title = "ARC POWER MATRIX // DYNAMIC AI THROTTLING",
        accentColor = throttleColor,
        modifier = modifier.testTag("battery_throttle_hud_card")
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {

            // Header Status Strip
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(throttleColor.copy(alpha = 0.15f))
                            .border(1.dp, throttleColor.copy(alpha = 0.5f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = when {
                                powerState.isCharging -> Icons.Default.BatteryChargingFull
                                powerState.isCriticalBattery -> Icons.Default.BatteryAlert
                                else -> Icons.Default.Bolt
                            },
                            contentDescription = "Battery Status",
                            tint = throttleColor,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "CORE RESERVES: ${powerState.level}%",
                                color = HologramTextBright,
                                fontSize = 14.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                            if (powerState.isSimulated) {
                                Spacer(modifier = Modifier.width(6.dp))
                                HudBadge(label = "SIMULATED", accentColor = ArcAmberGlow)
                            }
                        }
                        Text(
                            text = "[${powerState.pluggedSource.label}] • ${powerState.statusDescription}",
                            color = HologramTextDim,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                HudBadge(
                    label = powerState.throttleLevel.badgeLabel,
                    accentColor = throttleColor
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Animated Energy Bar
            Column(modifier = Modifier.fillMaxWidth()) {
                LinearProgressIndicator(
                    progress = { animatedLevel },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .testTag("battery_gauge_bar"),
                    color = throttleColor,
                    trackColor = DarkHologramSurface
                )

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "0% (DEPLETED)",
                        color = HologramTextDim,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "LOW THRESHOLD (${viewModel.prefs.getBatteryLowThreshold()}%)",
                        color = if (powerState.isBatteryLow) ArcAmberGlow else HologramTextDim,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "100% (PEAK)",
                        color = HologramTextDim,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Tactical Throttle Directives Banner
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(throttleColor.copy(alpha = 0.12f))
                    .border(1.dp, throttleColor.copy(alpha = 0.35f), RoundedCornerShape(6.dp))
                    .padding(8.dp)
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Speed,
                            contentDescription = null,
                            tint = throttleColor,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = powerState.throttleLevel.displayName.uppercase(),
                            color = throttleColor,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = powerState.throttleReason,
                        color = HologramTextMuted,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        lineHeight = 14.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Subsystem Telemetry Grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                TelemetryPill(
                    label = "TEMP",
                    value = "${powerState.temperatureCelsius}°C",
                    accentColor = if (powerState.temperatureCelsius > 42f) AlertCrimson else accentColor
                )
                TelemetryPill(
                    label = "BUS VOLTAGE",
                    value = "${powerState.voltageMv} mV",
                    accentColor = accentColor
                )
                TelemetryPill(
                    label = "CELL HEALTH",
                    value = powerState.health.label,
                    accentColor = if (powerState.health.label == "OPTIMAL") SuccessEmerald else ArcAmberGlow
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Policy Toggle & Calibration Controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "DYNAMIC AI THROTTLING",
                        color = HologramTextBright,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = if (viewModel.prefs.isAiThrottlingEnabled()) "AUTONOMOUS ENERGY CONSERVATION ACTIVE" else "MANUAL BYPASS (COMPUTE UNCONSTRAINED)",
                        color = HologramTextDim,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Switch(
                    checked = viewModel.prefs.isAiThrottlingEnabled(),
                    onCheckedChange = { enabled ->
                        viewModel.setAiThrottlingEnabled(enabled)
                    },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = SuccessEmerald,
                        checkedTrackColor = SuccessEmerald.copy(alpha = 0.3f),
                        uncheckedThumbColor = HologramTextDim,
                        uncheckedTrackColor = DarkHologramSurface
                    ),
                    modifier = Modifier.testTag("dynamic_throttle_switch")
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Toggleable Simulation / Diagnostics Console
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showControls = !showControls }
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (showControls) "▼ HIDE TACTICAL POWER SIMULATOR" else "▶ ENGAGE TACTICAL POWER SIMULATOR",
                    color = accentColor,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                if (powerState.isSimulated) {
                    Text(
                        text = "[OVERRIDE ENGAGED]",
                        color = ArcAmberGlow,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            if (showControls) {
                Spacer(modifier = Modifier.height(8.dp))
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(DarkHologramSurface.copy(alpha = 0.85f))
                        .border(1.dp, accentColor.copy(alpha = 0.25f), RoundedCornerShape(6.dp))
                        .padding(8.dp)
                ) {
                    Text(
                        text = "TACTICAL STARK POWER SIMULATOR // TEST THROTTLE PROFILES",
                        color = HologramTextBright,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Simulate hardware power transitions to verify AI throttling behavior in real-time:",
                        color = HologramTextDim,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        HudButton(
                            text = "LOW BATT (14%)",
                            onClick = {
                                viewModel.simulateBatteryPower(level = 14, isCharging = false, plugged = PluggedSource.UNPLUGGED)
                            },
                            accentColor = ArcAmberGlow,
                            modifier = Modifier.weight(1f),
                            testTag = "simulate_low_battery_button"
                        )
                        HudButton(
                            text = "CRITICAL (6%)",
                            onClick = {
                                viewModel.simulateBatteryPower(level = 6, isCharging = false, plugged = PluggedSource.UNPLUGGED)
                            },
                            accentColor = AlertCrimson,
                            modifier = Modifier.weight(1f),
                            testTag = "simulate_critical_battery_button"
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        HudButton(
                            text = "PLUG IN (AC 95%)",
                            onClick = {
                                viewModel.simulateBatteryPower(level = 95, isCharging = true, plugged = PluggedSource.AC_MAINS)
                            },
                            accentColor = SuccessEmerald,
                            modifier = Modifier.weight(1f),
                            testTag = "simulate_charging_button"
                        )
                        HudButton(
                            text = "RESTORE SENSOR",
                            onClick = {
                                viewModel.resetBatterySimulation()
                            },
                            accentColor = accentColor,
                            modifier = Modifier.weight(1f),
                            testTag = "reset_battery_simulation_button"
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TelemetryPill(
    label: String,
    value: String,
    accentColor: Color
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(DarkHologramSurface)
            .border(1.dp, accentColor.copy(alpha = 0.3f), RoundedCornerShape(4.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = label,
                color = HologramTextDim,
                fontSize = 8.sp,
                fontFamily = FontFamily.Monospace
            )
            Text(
                text = value,
                color = accentColor,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
