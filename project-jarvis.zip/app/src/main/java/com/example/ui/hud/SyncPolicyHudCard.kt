package com.example.ui.hud

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryAlert
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.SignalCellularAlt
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.work.WorkInfo
import com.example.ui.theme.AlertCrimson
import com.example.ui.theme.ArcAmberGlow
import com.example.ui.theme.DarkHologramSurface
import com.example.ui.theme.HologramTextBright
import com.example.ui.theme.HologramTextDim
import com.example.ui.theme.HologramTextMuted
import com.example.ui.theme.HudCardSurface
import com.example.ui.theme.ProcessingViolet
import com.example.ui.theme.ReactorCyanGlow
import com.example.ui.theme.SuccessEmerald
import com.example.viewmodel.JarvisViewModel

/**
 * Tactical HUD card visualizing the WorkManager autonomous background sync policy.
 * Provides hardware sensor telemetry (charging state + Wi-Fi status), live WorkManager
 * state, and constraints management matching the JARVIS holographic theme.
 */
@Composable
fun SyncPolicyHudCard(
    viewModel: JarvisViewModel,
    modifier: Modifier = Modifier,
    compact: Boolean = false
) {
    val accentColor = viewModel.getAccentColor()
    val readiness by viewModel.deviceReadiness.collectAsState()
    val periodicWorkInfo by viewModel.periodicWorkInfo.collectAsState()

    var showConfig by remember { mutableStateOf(false) }
    var chargingRequired by remember { mutableStateOf(viewModel.prefs.isSyncChargingRequired()) }
    var wifiRequired by remember { mutableStateOf(viewModel.prefs.isSyncWifiRequired()) }
    var intervalHours by remember { mutableStateOf(viewModel.prefs.getSyncIntervalHours()) }

    // Periodic refresh of hardware sensors when HUD card is in composition
    LaunchedEffect(Unit) {
        viewModel.refreshDeviceReadiness()
    }

    val workerStateLabel = when (periodicWorkInfo?.state) {
        WorkInfo.State.RUNNING -> "EXECUTING MAINTENANCE"
        WorkInfo.State.ENQUEUED -> if (readiness.isPolicySatisfied) "STANDBY // READY" else "AWAITING CHARGER+WIFI"
        WorkInfo.State.SUCCEEDED -> "CYCLE COMPLETE"
        WorkInfo.State.BLOCKED -> "CONSTRAINTS BLOCKED"
        WorkInfo.State.FAILED -> "FAILED // RETRYING"
        WorkInfo.State.CANCELLED -> "DISENGAGED"
        else -> "POLICY ACTIVE (WORKMANAGER)"
    }

    val workerBadgeColor = when (periodicWorkInfo?.state) {
        WorkInfo.State.RUNNING -> ProcessingViolet
        WorkInfo.State.ENQUEUED -> if (readiness.isPolicySatisfied) SuccessEmerald else ArcAmberGlow
        WorkInfo.State.FAILED -> AlertCrimson
        else -> ReactorCyanGlow
    }

    HudCard(
        borderColor = accentColor.copy(alpha = 0.45f),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Header Row: Title & Worker Status Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .background(if (readiness.isPolicySatisfied) SuccessEmerald else ArcAmberGlow)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "WORKMANAGER BACKGROUND SYNC MATRIX",
                        color = accentColor,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "BATTERY LIFE & BANDWIDTH PRESERVATION POLICY",
                        color = HologramTextDim,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                HudBadge(
                    label = workerStateLabel,
                    accentColor = workerBadgeColor
                )

                Spacer(modifier = Modifier.width(4.dp))
                IconButton(
                    onClick = { viewModel.refreshDeviceReadiness() },
                    modifier = Modifier.size(28.dp).testTag("refresh_sync_readiness_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Refresh Hardware Status",
                        tint = accentColor,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Hardware Telemetry Readout Grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Power / Charging Tile
                val isPowerOk = !chargingRequired || readiness.isCharging
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (isPowerOk) SuccessEmerald.copy(alpha = 0.1f) else AlertCrimson.copy(alpha = 0.12f))
                        .border(
                            1.dp,
                            if (isPowerOk) SuccessEmerald.copy(alpha = 0.4f) else AlertCrimson.copy(alpha = 0.5f),
                            RoundedCornerShape(6.dp)
                        )
                        .padding(8.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (readiness.isCharging) Icons.Default.BatteryChargingFull else Icons.Default.BatteryAlert,
                                contentDescription = "Battery Status",
                                tint = if (isPowerOk) SuccessEmerald else AlertCrimson,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "POWER SOURCE",
                                color = HologramTextDim,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (readiness.isCharging) "${readiness.chargingSource} [OK]" else "DISCHARGING (${readiness.batteryPct}%)",
                            color = if (isPowerOk) SuccessEmerald else AlertCrimson,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (chargingRequired) "POLICY: CHARGING REQUIRED" else "POLICY: CHARGING OPTIONAL",
                            color = HologramTextMuted,
                            fontSize = 8.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                // Wi-Fi / Network Tile
                val isWifiOk = !wifiRequired || (readiness.isWifiConnected && readiness.isUnmetered)
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (isWifiOk) ReactorCyanGlow.copy(alpha = 0.1f) else AlertCrimson.copy(alpha = 0.12f))
                        .border(
                            1.dp,
                            if (isWifiOk) ReactorCyanGlow.copy(alpha = 0.4f) else AlertCrimson.copy(alpha = 0.5f),
                            RoundedCornerShape(6.dp)
                        )
                        .padding(8.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (readiness.isWifiConnected) Icons.Default.Wifi else Icons.Default.WifiOff,
                                contentDescription = "Wi-Fi Status",
                                tint = if (isWifiOk) ReactorCyanGlow else AlertCrimson,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "DATA CONNECTION",
                                color = HologramTextDim,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (readiness.isWifiConnected) "UNMETERED WI-FI [OK]" else "CELLULAR / OFFLINE",
                            color = if (isWifiOk) ReactorCyanGlow else AlertCrimson,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (wifiRequired) "POLICY: WI-FI REQUIRED" else "POLICY: ANY NETWORK",
                            color = HologramTextMuted,
                            fontSize = 8.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Diagnostic Policy Status Banner
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(4.dp))
                    .background(
                        if (readiness.isPolicySatisfied)
                            SuccessEmerald.copy(alpha = 0.12f)
                        else
                            ArcAmberGlow.copy(alpha = 0.12f)
                    )
                    .border(
                        1.dp,
                        if (readiness.isPolicySatisfied)
                            SuccessEmerald.copy(alpha = 0.35f)
                        else
                            ArcAmberGlow.copy(alpha = 0.4f),
                        RoundedCornerShape(4.dp)
                    )
                    .padding(horizontal = 8.dp, vertical = 6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (readiness.isPolicySatisfied) Icons.Default.Bolt else Icons.Default.Schedule,
                        contentDescription = "Policy Status",
                        tint = if (readiness.isPolicySatisfied) SuccessEmerald else ArcAmberGlow,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = readiness.summary,
                        color = HologramTextBright,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        lineHeight = 13.sp
                    )
                }
            }

            if (!compact) {
                Spacer(modifier = Modifier.height(8.dp))

                // Telemetry Audit Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "LAST SYNC: ${viewModel.storageManager.getLastSyncString()}",
                        color = HologramTextDim,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "INTERVAL: EVERY ${intervalHours}H",
                        color = accentColor,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }

                val lastStatus = viewModel.prefs.getLastSyncStatus()
                if (lastStatus.isNotBlank()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "AUDIT LOG: $lastStatus",
                        color = HologramTextMuted,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        maxLines = 1
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Action Controls
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    HudButton(
                        text = "QUEUE STRICT SYNC",
                        onClick = { viewModel.triggerWorkManagerSync(respectConstraints = true) },
                        icon = Icons.Default.Bolt,
                        accentColor = if (readiness.isPolicySatisfied) SuccessEmerald else ArcAmberGlow,
                        modifier = Modifier.weight(1.2f),
                        testTag = "queue_strict_sync_button"
                    )

                    HudButton(
                        text = "FORCE RUN",
                        onClick = { viewModel.triggerWorkManagerSync(respectConstraints = false) },
                        icon = Icons.Default.CloudSync,
                        accentColor = ReactorCyanGlow,
                        modifier = Modifier.weight(0.9f),
                        testTag = "force_sync_button"
                    )

                    IconButton(
                        onClick = { showConfig = !showConfig },
                        modifier = Modifier
                            .size(42.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(HudCardSurface)
                            .border(1.dp, accentColor.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                            .testTag("toggle_sync_config_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = "Policy Settings",
                            tint = if (showConfig) accentColor else HologramTextDim,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                // Expandable Policy Configuration Sub-Panel
                AnimatedVisibility(
                    visible = showConfig,
                    enter = fadeIn() + expandVertically(),
                    exit = fadeOut() + shrinkVertically()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 10.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(DarkHologramSurface.copy(alpha = 0.9f))
                            .border(1.dp, accentColor.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
                            .padding(10.dp)
                    ) {
                        Text(
                            text = "CONSTRAINTS & REPEAT SCHEDULE",
                            color = accentColor,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        // Charging Requirement Switch
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "REQUIRE CHARGER CONNECTED",
                                color = HologramTextBright,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Switch(
                                checked = chargingRequired,
                                onCheckedChange = {
                                    chargingRequired = it
                                    viewModel.updateSyncPolicy(it, wifiRequired, intervalHours)
                                },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = accentColor,
                                    checkedTrackColor = accentColor.copy(alpha = 0.4f)
                                )
                            )
                        }

                        // Wi-Fi Requirement Switch
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "REQUIRE UNMETERED WI-FI",
                                color = HologramTextBright,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                            Switch(
                                checked = wifiRequired,
                                onCheckedChange = {
                                    wifiRequired = it
                                    viewModel.updateSyncPolicy(chargingRequired, it, intervalHours)
                                },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = accentColor,
                                    checkedTrackColor = accentColor.copy(alpha = 0.4f)
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Repeat Interval Selector
                        Text(
                            text = "RECURRENCE CYCLE:",
                            color = HologramTextDim,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf(3L to "3H", 6L to "6H", 12L to "12H", 24L to "24H").forEach { (h, label) ->
                                val isSelected = intervalHours == h
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(if (isSelected) accentColor.copy(alpha = 0.25f) else HudCardSurface)
                                        .border(
                                            1.dp,
                                            if (isSelected) accentColor else Color.Gray.copy(alpha = 0.3f),
                                            RoundedCornerShape(4.dp)
                                        )
                                        .clickable {
                                            intervalHours = h
                                            viewModel.updateSyncPolicy(chargingRequired, wifiRequired, h)
                                        }
                                        .padding(vertical = 6.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = label,
                                        color = if (isSelected) accentColor else HologramTextMuted,
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
