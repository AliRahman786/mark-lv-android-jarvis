package com.example.ui.screens

import android.view.ViewGroup
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FlipCameraAndroid
import androidx.compose.material.icons.filled.PanTool
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VideocamOff
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.example.gesture.GestureAnalyzer
import com.example.gesture.GestureType
import com.example.ui.hud.HudBadge
import com.example.ui.hud.HudButton
import com.example.ui.hud.HudCard
import com.example.ui.hud.HudPanel
import com.example.ui.theme.AlertCrimson
import com.example.ui.theme.ArcAmberGlow
import com.example.ui.theme.DarkHologramSurface
import com.example.ui.theme.HologramTextBright
import com.example.ui.theme.HologramTextDim
import com.example.ui.theme.HologramTextMuted
import com.example.ui.theme.HudCardSurface
import com.example.ui.theme.ReactorCyanGlow
import com.example.ui.theme.SuccessEmerald
import com.example.viewmodel.JarvisViewModel
import java.util.concurrent.Executors

@Composable
fun GesturePanel(
    viewModel: JarvisViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val accentColor = viewModel.getAccentColor()
    val scrollState = rememberScrollState()

    var isGestureEnabled by remember { mutableStateOf(viewModel.prefs.isGestureEnabled()) }
    var useFrontCamera by remember { mutableStateOf(true) }
    var sensitivity by remember { mutableStateOf(viewModel.prefs.getGestureSensitivity()) }

    val recentGesture by viewModel.gestureController.currentGesture.collectAsState()
    val feedbackMsg by viewModel.gestureController.recentFeedbackMessage.collectAsState()
    val isCameraActive by viewModel.gestureController.isCameraActive.collectAsState()

    HudPanel(
        title = "OPTICAL GESTURE TELEMETRY",
        accentColor = accentColor,
        trailingBadge = {
            if (isCameraActive) {
                HudBadge(label = "CAM ACTIVE // ON-DEVICE", accentColor = AlertCrimson)
            } else {
                HudBadge(label = "CAM STANDBY", accentColor = HologramTextDim)
            }
        },
        modifier = modifier.fillMaxSize()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
        ) {
            // Privacy / Safety notice
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(ReactorCyanGlow.copy(alpha = 0.12f))
                    .border(1.dp, ReactorCyanGlow.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                    .padding(8.dp)
            ) {
                Text(
                    text = "PRIVACY GUARANTEE: Optical frames are computed 100% locally on device via CameraX edge heuristics. Zero images are transmitted over network.",
                    color = ReactorCyanGlow,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    lineHeight = 14.sp
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Camera Preview View
            if (isGestureEnabled) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(16f / 10f)
                        .clip(RoundedCornerShape(8.dp))
                        .border(1.2.dp, if (recentGesture != null) accentColor else accentColor.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                        .background(DarkHologramSurface)
                ) {
                    AndroidView(
                        factory = { ctx ->
                            val previewView = PreviewView(ctx).apply {
                                layoutParams = ViewGroup.LayoutParams(
                                    ViewGroup.LayoutParams.MATCH_PARENT,
                                    ViewGroup.LayoutParams.MATCH_PARENT
                                )
                                scaleType = PreviewView.ScaleType.FILL_CENTER
                            }

                            val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                            cameraProviderFuture.addListener({
                                val cameraProvider = cameraProviderFuture.get()

                                val preview = Preview.Builder().build().also {
                                    it.setSurfaceProvider(previewView.surfaceProvider)
                                }

                                val cameraExecutor = Executors.newSingleThreadExecutor()
                                val imageAnalyzer = ImageAnalysis.Builder()
                                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                                    .build()
                                    .also {
                                        it.setAnalyzer(
                                            cameraExecutor,
                                            GestureAnalyzer(
                                                onGestureDetected = { type, conf ->
                                                    viewModel.gestureController.onRawGestureDetected(type, conf)
                                                },
                                                sensitivity = { sensitivity }
                                            )
                                        )
                                    }

                                val cameraSelector = if (useFrontCamera) {
                                    CameraSelector.DEFAULT_FRONT_CAMERA
                                } else {
                                    CameraSelector.DEFAULT_BACK_CAMERA
                                }

                                try {
                                    cameraProvider.unbindAll()
                                    cameraProvider.bindToLifecycle(
                                        lifecycleOwner,
                                        cameraSelector,
                                        preview,
                                        imageAnalyzer
                                    )
                                    viewModel.gestureController.setCameraActive(true)
                                } catch (e: Exception) {
                                    viewModel.gestureController.setCameraActive(false)
                                }
                            }, ContextCompat.getMainExecutor(ctx))

                            previewView
                        },
                        modifier = Modifier.fillMaxSize()
                    )

                    // Target HUD Crosshair overlay
                    Box(
                        modifier = Modifier
                            .size(90.dp)
                            .align(Alignment.Center)
                            .border(1.dp, accentColor.copy(alpha = 0.5f), RoundedCornerShape(45.dp))
                    )

                    // Overlay HUD Badge with recognized gesture
                    recentGesture?.let { g ->
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .padding(8.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(DarkHologramSurface.copy(alpha = 0.9f))
                                .border(1.dp, accentColor, RoundedCornerShape(4.dp))
                                .padding(horizontal = 10.dp, vertical = 5.dp)
                        ) {
                            Text(
                                text = "TARGET: ${g.type.displayName.uppercase()} (${(g.confidence * 100).toInt()}%)",
                                color = accentColor,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Toggle Camera Flip
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (useFrontCamera) "FRONT SENSOR" else "REAR SENSOR",
                        color = HologramTextBright,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    HudButton(
                        text = "FLIP CAMERA",
                        onClick = { useFrontCamera = !useFrontCamera },
                        icon = Icons.Default.FlipCameraAndroid,
                        accentColor = accentColor
                    )
                }
            } else {
                HudCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(imageVector = Icons.Default.VideocamOff, contentDescription = "Camera disabled", tint = HologramTextDim)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Gesture recognition camera disabled. Toggle switch below to engage optical tracking.",
                            color = HologramTextMuted,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Gesture Toggle & Sensitivity
            HudCard(borderColor = accentColor.copy(alpha = 0.3f)) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "OPTICAL GESTURE CONTROL",
                            color = HologramTextBright,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                        Switch(
                            checked = isGestureEnabled,
                            onCheckedChange = {
                                isGestureEnabled = it
                                viewModel.prefs.setGestureEnabled(it)
                                if (!it) viewModel.gestureController.setCameraActive(false)
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = accentColor,
                                checkedTrackColor = accentColor.copy(alpha = 0.4f)
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "SENSITIVITY: ${(sensitivity * 100).toInt()}%",
                        color = accentColor,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Slider(
                        value = sensitivity,
                        onValueChange = {
                            sensitivity = it
                            viewModel.prefs.setGestureSensitivity(it)
                            viewModel.gestureController.sensitivity = it
                        },
                        valueRange = 0.1f..1.0f,
                        colors = SliderDefaults.colors(
                            thumbColor = accentColor,
                            activeTrackColor = accentColor
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Gesture Mappings Guide
            Text(
                text = "CALIBRATED GESTURE COMMANDS:",
                color = accentColor,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))

            listOf(
                GestureType.OPEN_PALM,
                GestureType.FIST,
                GestureType.PINCH_INDEX,
                GestureType.SWIPE_LEFT,
                GestureType.SWIPE_RIGHT,
                GestureType.TWO_FINGERS
            ).forEach { g ->
                HudCard(modifier = Modifier.padding(vertical = 3.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.PanTool,
                            contentDescription = g.displayName,
                            tint = accentColor,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(g.displayName.uppercase(), color = HologramTextBright, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                            Text(g.actionDescription, color = HologramTextMuted, fontSize = 10.sp)
                        }
                    }
                }
            }
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            viewModel.gestureController.setCameraActive(false)
        }
    }
}
