package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PanTool
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.hud.AudioWaveformView
import com.example.ui.hud.HudBadge
import com.example.ui.hud.HudButton
import com.example.ui.hud.HudCard
import com.example.ui.hud.JarvisCoreView
import com.example.ui.theme.AlertCrimson
import com.example.ui.theme.DarkHologramSurface
import com.example.ui.theme.DeepSpaceBlack
import com.example.ui.theme.HologramTextBright
import com.example.ui.theme.HologramTextDim
import com.example.ui.theme.HologramTextMuted
import com.example.ui.theme.HudCardSurface
import com.example.ui.theme.ReactorCyanGlow
import com.example.ui.theme.SuccessEmerald
import com.example.viewmodel.JarvisViewModel
import com.example.voice.VoiceState

@Composable
fun MainHudScreen(
    viewModel: JarvisViewModel,
    modifier: Modifier = Modifier
) {
    val activePanel by viewModel.activePanel.collectAsState()
    val voiceState by viewModel.voiceState.collectAsState()
    val statusText by viewModel.statusText.collectAsState()
    val audioAmplitude by viewModel.combinedAudioAmplitude.collectAsState()
    val pendingConfirmation by viewModel.pendingConfirmation.collectAsState()
    val isCameraActive by viewModel.gestureController.isCameraActive.collectAsState()
    val readiness by viewModel.deviceReadiness.collectAsState()
    val powerState by viewModel.batteryPowerState.collectAsState()
    val accentColor = viewModel.getAccentColor()

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(DeepSpaceBlack)
            .statusBarsPadding()
            .navigationBarsPadding()
            .testTag("main_hud_screen")
    ) {
        val isTablet = maxWidth >= 720.dp

        Column(modifier = Modifier.fillMaxSize()) {
            // 1. Top Tactical HUD Status Banner
            TopHudStatusBar(
                statusText = statusText,
                voiceState = voiceState,
                isCameraActive = isCameraActive,
                readiness = readiness,
                powerState = powerState,
                accentColor = accentColor,
                onSettingsClick = { viewModel.setActivePanel("SETTINGS") }
            )

            // 2. Main Content Area: Phone vs Tablet Layout
            if (isTablet) {
                // Tablet Canonical 3-Pane HUD Command Center
                Row(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    // Left Pane: Terminal Communication & Memory
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                    ) {
                        ConversationPanel(viewModel = viewModel)
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    // Center Pane: 3D Holographic Core & Audio Waveforms
                    Column(
                        modifier = Modifier
                            .weight(1.2f)
                            .fillMaxHeight(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        JarvisCoreView(
                            voiceState = voiceState,
                            audioAmplitude = audioAmplitude,
                            accentColor = accentColor,
                            onCoreTap = { viewModel.toggleVoiceInput() }
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        AudioWaveformView(
                            amplitude = audioAmplitude,
                            accentColor = accentColor,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 24.dp)
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        HudButton(
                            text = if (voiceState == VoiceState.LISTENING) "HALT AUDIO RECEPTORS" else "ENGAGE VOICE RECEPTOR",
                            onClick = { viewModel.toggleVoiceInput() },
                            accentColor = if (voiceState == VoiceState.LISTENING) AlertCrimson else accentColor,
                            testTag = "tablet_voice_toggle"
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    // Right Pane: Switchable Subsystem (Memory / Tools / Gestures / Settings)
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                    ) {
                        when (activePanel) {
                            "STUDIO" -> MediaStudioPanel(viewModel = viewModel)
                            "MEMORY" -> MemoryManagerPanel(viewModel = viewModel)
                            "TOOLS" -> ToolRegistryPanel(viewModel = viewModel)
                            "GESTURES" -> GesturePanel(viewModel = viewModel)
                            "SETTINGS" -> SettingsPanel(viewModel = viewModel)
                            else -> MediaStudioPanel(viewModel = viewModel)
                        }
                    }
                }
            } else {
                // Phone Layout: Central core or Active Subsystem Panel
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    when (activePanel) {
                        "CORE" -> {
                            Column(
                                modifier = Modifier.fillMaxSize(),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Text(
                                    text = "ARC REACTOR // MARK-LIV",
                                    color = accentColor,
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 2.sp
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "3D GYROSCOPE • DRAG TO ROTATE • PINCH TO ZOOM",
                                    color = HologramTextDim,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace
                                )

                                Spacer(modifier = Modifier.height(12.dp))

                                JarvisCoreView(
                                    voiceState = voiceState,
                                    audioAmplitude = audioAmplitude,
                                    accentColor = accentColor,
                                    onCoreTap = { viewModel.toggleVoiceInput() }
                                )

                                Spacer(modifier = Modifier.height(16.dp))

                                AudioWaveformView(
                                    amplitude = audioAmplitude,
                                    accentColor = accentColor,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp)
                                )

                                Spacer(modifier = Modifier.height(16.dp))

                                HudButton(
                                    text = if (voiceState == VoiceState.LISTENING) "HALT VOICE RECEPTOR" else "TAP TO SPEAK // PUSH TO TALK",
                                    onClick = { viewModel.toggleVoiceInput() },
                                    accentColor = if (voiceState == VoiceState.LISTENING) AlertCrimson else accentColor,
                                    testTag = "phone_voice_toggle"
                                )

                                Spacer(modifier = Modifier.height(14.dp))

                                // Autonomous Background Sync Telemetry Pill
                                Row(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(HudCardSurface.copy(alpha = 0.7f))
                                        .border(1.dp, accentColor.copy(alpha = 0.25f), RoundedCornerShape(6.dp))
                                        .clickable { viewModel.setActivePanel("MEMORY") }
                                        .padding(horizontal = 12.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(6.dp)
                                            .background(if (readiness.isPolicySatisfied) SuccessEmerald else ArcAmberGlow)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "BACKGROUND SYNC: ${if (readiness.isPolicySatisfied) "READY [CHARGING+WIFI]" else "PRESERVING BATTERY [AWAITING CHARGER]"}",
                                        color = HologramTextDim,
                                        fontSize = 9.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                        }
                        "CHAT" -> ConversationPanel(viewModel = viewModel)
                        "STUDIO" -> MediaStudioPanel(viewModel = viewModel)
                        "MEMORY" -> MemoryManagerPanel(viewModel = viewModel)
                        "TOOLS" -> ToolRegistryPanel(viewModel = viewModel)
                        "GESTURES" -> GesturePanel(viewModel = viewModel)
                        "SETTINGS" -> SettingsPanel(viewModel = viewModel)
                    }
                }
            }

            // 3. Bottom HUD Subsystem Navigation Bar
            BottomHudNavigationBar(
                activePanel = activePanel,
                onSelectPanel = { viewModel.setActivePanel(it) },
                accentColor = accentColor
            )
        }

        // Consequential Action Confirmation Modal
        pendingConfirmation?.let { conf ->
            AlertDialog(
                onDismissRequest = { viewModel.dismissPendingAction() },
                containerColor = DarkHologramSurface,
                titleContentColor = AlertCrimson,
                textContentColor = HologramTextBright,
                icon = {
                    Icon(imageVector = Icons.Default.Warning, contentDescription = "Security Alert", tint = AlertCrimson)
                },
                title = {
                    Text(
                        text = conf.title,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                },
                text = {
                    Text(
                        text = conf.details,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    )
                },
                confirmButton = {
                    TextButton(
                        onClick = { viewModel.confirmPendingAction() },
                        modifier = Modifier.testTag("confirm_action_button")
                    ) {
                        Text("AUTHORIZE", color = AlertCrimson, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                    }
                },
                dismissButton = {
                    TextButton(
                        onClick = { viewModel.dismissPendingAction() },
                        modifier = Modifier.testTag("abort_action_button")
                    ) {
                        Text("ABORT", color = HologramTextMuted, fontFamily = FontFamily.Monospace)
                    }
                },
                modifier = Modifier
                    .border(1.2.dp, AlertCrimson, RoundedCornerShape(12.dp))
                    .testTag("consequential_action_dialog")
            )
        }
    }
}

@Composable
fun TopHudStatusBar(
    statusText: String,
    voiceState: VoiceState,
    isCameraActive: Boolean,
    readiness: com.example.data.sync.DeviceSyncReadiness,
    powerState: com.example.data.battery.BatteryPowerState,
    accentColor: Color,
    onSettingsClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "J.A.R.V.I.S.",
                    color = accentColor,
                    fontSize = 14.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.5.sp
                )
                Spacer(modifier = Modifier.width(8.dp))
                HudBadge(
                    label = voiceState.name,
                    accentColor = when (voiceState) {
                        VoiceState.ERROR -> AlertCrimson
                        VoiceState.LISTENING -> ReactorCyanGlow
                        VoiceState.SPEAKING -> ArcAmberGlow
                        VoiceState.THINKING -> ReactorCyanGlow
                        else -> SuccessEmerald
                    }
                )
                if (isCameraActive) {
                    Spacer(modifier = Modifier.width(6.dp))
                    HudBadge(label = "CAM", accentColor = AlertCrimson)
                }
                Spacer(modifier = Modifier.width(6.dp))
                val pwrLabel = "PWR: ${powerState.level}%${if (powerState.isCharging) "⚡" else ""}"
                val pwrColor = when {
                    powerState.isCharging -> SuccessEmerald
                    powerState.throttleLevel == com.example.data.battery.AiThrottleLevel.CRITICAL_THROTTLED -> AlertCrimson
                    powerState.throttleLevel == com.example.data.battery.AiThrottleLevel.BALANCED -> ArcAmberGlow
                    else -> ReactorCyanGlow
                }
                HudBadge(label = pwrLabel, accentColor = pwrColor)
                if (powerState.throttleLevel != com.example.data.battery.AiThrottleLevel.UNCONSTRAINED) {
                    Spacer(modifier = Modifier.width(4.dp))
                    HudBadge(label = powerState.throttleLevel.badgeLabel, accentColor = pwrColor)
                }
            }
            Text(
                text = statusText,
                color = HologramTextDim,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                maxLines = 1
            )
        }

        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(HudCardSurface)
                .border(1.dp, accentColor.copy(alpha = 0.4f), RoundedCornerShape(4.dp))
                .clickable { onSettingsClick() }
                .testTag("top_settings_button"),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Settings,
                contentDescription = "Settings",
                tint = accentColor,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

@Composable
fun BottomHudNavigationBar(
    activePanel: String,
    onSelectPanel: (String) -> Unit,
    accentColor: Color
) {
    val items = listOf(
        Triple("CORE", "Core", Icons.Default.Security),
        Triple("CHAT", "Terminal", Icons.Default.Chat),
        Triple("STUDIO", "Studio", Icons.Default.Movie),
        Triple("MEMORY", "Memory", Icons.Default.Memory),
        Triple("TOOLS", "Tools", Icons.Default.Build),
        Triple("GESTURES", "Gestures", Icons.Default.PanTool),
        Triple("SETTINGS", "Settings", Icons.Default.Settings)
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(DarkHologramSurface.copy(alpha = 0.95f))
            .border(1.dp, accentColor.copy(alpha = 0.35f), RoundedCornerShape(8.dp))
            .padding(4.dp),
        horizontalArrangement = Arrangement.SpaceAround,
        verticalAlignment = Alignment.CenterVertically
    ) {
        items.forEach { (id, label, icon) ->
            val isSelected = activePanel == id
            Column(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(if (isSelected) accentColor.copy(alpha = 0.2f) else Color.Transparent)
                    .clickable { onSelectPanel(id) }
                    .padding(horizontal = 8.dp, vertical = 6.dp)
                    .testTag("nav_item_$id"),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = if (isSelected) accentColor else HologramTextDim,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = label.uppercase(),
                    color = if (isSelected) accentColor else HologramTextDim,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                )
            }
        }
    }
}
