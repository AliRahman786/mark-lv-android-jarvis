package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Futuristic Holographic Environment Colors
val DeepSpaceBlack = Color(0xFF020612)
val DarkHologramSurface = Color(0xFF050B18)
val HudCardSurface = Color(0xCC091326)
val GlassmorphismBorder = Color(0x3300E5FF)

// Amber / Gold Energy (Stark Core)
val ArcAmberGlow = Color(0xFFFF9E00)
val ArcAmberBright = Color(0xFFFFB800)
val ArcAmberDeep = Color(0xFFCC6600)
val ArcFlameOrange = Color(0xFFFF5500)

// Quantum / Reactor Cyan Energy
val ReactorCyanGlow = Color(0xFF00E5FF)
val ReactorCyanBright = Color(0xFF80F0FF)
val ReactorCyanDeep = Color(0xFF0088AA)

// Status & Alert Colors
val AlertCrimson = Color(0xFFFF2A55)
val SuccessEmerald = Color(0xFF00F59B)
val ProcessingViolet = Color(0xFFA855F7)
val StandbySilver = Color(0xFF7E8B9B)

// Typography & Text Gradients
val HologramTextBright = Color(0xFFF1F5F9)
val HologramTextMuted = Color(0xFF94A3B8)
val HologramTextDim = Color(0xFF475569)
