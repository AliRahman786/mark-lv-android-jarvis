package com.example.gesture

import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import java.nio.ByteBuffer

class GestureAnalyzer(
    private val onGestureDetected: (GestureType, Float) -> Unit,
    private val sensitivity: () -> Float = { 0.5f }
) : ImageAnalysis.Analyzer {

    private var previousCentroidX = -1f
    private var previousCentroidY = -1f
    private var previousActivePixelCount = 0
    private var lastAnalysisTimestamp = 0L

    override fun analyze(image: ImageProxy) {
        val currentTimestamp = System.currentTimeMillis()
        // Process at maximum 15 FPS to ensure battery efficiency
        if (currentTimestamp - lastAnalysisTimestamp < 65) {
            image.close()
            return
        }
        lastAnalysisTimestamp = currentTimestamp

        val buffer: ByteBuffer = image.planes[0].buffer
        val width = image.width
        val height = image.height
        val rowStride = image.planes[0].rowStride

        // Downsample for high-speed local processing (step by 8 pixels)
        val step = 8
        var sumX = 0L
        var sumY = 0L
        var activePixels = 0
        var totalSampled = 0

        val data = ByteArray(buffer.remaining())
        buffer.get(data)

        // Identify contrast/skin luminosity zone in the center 70% of frame
        val startX = (width * 0.15).toInt()
        val endX = (width * 0.85).toInt()
        val startY = (height * 0.15).toInt()
        val endY = (height * 0.85).toInt()

        for (y in startY until endY step step) {
            val rowOffset = y * rowStride
            for (x in startX until endX step step) {
                totalSampled++
                val index = rowOffset + x
                if (index < data.size) {
                    val luminance = data[index].toInt() and 0xFF
                    // Hand/foreground presence threshold (typically between 85 and 235)
                    if (luminance in 80..230) {
                        sumX += x
                        sumY += y
                        activePixels++
                    }
                }
            }
        }

        val coverageRatio = if (totalSampled > 0) activePixels.toFloat() / totalSampled else 0f
        val sens = sensitivity().coerceIn(0.1f, 1.0f)
        val minCoverage = 0.15f * (1.2f - sens * 0.4f)
        val maxCoverage = 0.75f

        if (coverageRatio in minCoverage..maxCoverage) {
            val currentCentroidX = (sumX.toFloat() / activePixels) / width
            val currentCentroidY = (sumY.toFloat() / activePixels) / height

            if (previousCentroidX >= 0f && previousCentroidY >= 0f) {
                val deltaX = currentCentroidX - previousCentroidX
                val deltaY = currentCentroidY - previousCentroidY
                val deltaCoverage = coverageRatio - (previousActivePixelCount.toFloat() / totalSampled)

                // Swipe detection threshold
                val swipeThreshold = 0.12f * (1.1f - sens * 0.3f)

                when {
                    deltaX > swipeThreshold -> {
                        onGestureDetected(GestureType.SWIPE_RIGHT, 0.88f)
                    }
                    deltaX < -swipeThreshold -> {
                        onGestureDetected(GestureType.SWIPE_LEFT, 0.88f)
                    }
                    deltaY < -swipeThreshold -> {
                        onGestureDetected(GestureType.SWIPE_UP, 0.85f)
                    }
                    deltaY > swipeThreshold -> {
                        onGestureDetected(GestureType.SWIPE_DOWN, 0.85f)
                    }
                    coverageRatio > 0.45f -> {
                        // Large spread surface -> Open Palm
                        onGestureDetected(GestureType.OPEN_PALM, 0.90f)
                    }
                    coverageRatio < 0.22f && deltaCoverage < -0.05f -> {
                        // Rapid compaction of hand -> Closed Fist
                        onGestureDetected(GestureType.FIST, 0.87f)
                    }
                    coverageRatio in 0.22f..0.35f -> {
                        // Moderate focused area -> Pinch or target
                        onGestureDetected(GestureType.PINCH_INDEX, 0.82f)
                    }
                }
            }

            previousCentroidX = currentCentroidX
            previousCentroidY = currentCentroidY
            previousActivePixelCount = activePixels
        } else {
            previousCentroidX = -1f
            previousCentroidY = -1f
        }

        image.close()
    }
}
