package com.example.gesture

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class GestureController {

    private val _isCameraActive = MutableStateFlow(false)
    val isCameraActive: StateFlow<Boolean> = _isCameraActive.asStateFlow()

    private val _currentGesture = MutableStateFlow<GestureEvent?>(null)
    val currentGesture: StateFlow<GestureEvent?> = _currentGesture.asStateFlow()

    private val _recentFeedbackMessage = MutableStateFlow<String?>(null)
    val recentFeedbackMessage: StateFlow<String?> = _recentFeedbackMessage.asStateFlow()

    var sensitivity: Float = 0.6f
    var cooldownMs: Long = 1400L // 1.4 seconds debouncing

    private var lastTriggerTimestamp = 0L

    var onGestureAction: ((GestureType) -> Unit)? = null

    fun setCameraActive(active: Boolean) {
        _isCameraActive.value = active
        if (!active) {
            _currentGesture.value = null
        }
    }

    fun onRawGestureDetected(type: GestureType, confidence: Float) {
        if (!_isCameraActive.value) return

        val now = System.currentTimeMillis()
        if (now - lastTriggerTimestamp < cooldownMs) {
            return
        }

        lastTriggerTimestamp = now
        val event = GestureEvent(type = type, timestamp = now, confidence = confidence)
        _currentGesture.value = event
        _recentFeedbackMessage.value = "GESTURE RECOGNIZED // ${type.displayName.uppercase()} (${(confidence * 100).toInt()}%)"

        onGestureAction?.invoke(type)
    }

    fun clearFeedback() {
        _recentFeedbackMessage.value = null
    }
}
