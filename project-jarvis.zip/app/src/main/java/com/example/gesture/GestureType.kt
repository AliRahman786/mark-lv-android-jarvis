package com.example.gesture

enum class GestureType(val displayName: String, val actionDescription: String) {
    NONE("Scanning", "No gesture detected"),
    OPEN_PALM("Open Palm", "Wake / Voice receptor engaged"),
    FIST("Closed Fist", "Halt / Cancel current operation"),
    PINCH_INDEX("Pinch / Target", "Select / Confirm pending action"),
    SWIPE_LEFT("Swipe Left", "Shift HUD telemetry left"),
    SWIPE_RIGHT("Swipe Right", "Shift HUD telemetry right"),
    SWIPE_UP("Swipe Up", "Scroll up viewport"),
    SWIPE_DOWN("Swipe Down", "Scroll down viewport"),
    TWO_FINGERS("Two Fingers Up", "Toggle Pause / Resume playback")
}

data class GestureEvent(
    val type: GestureType,
    val timestamp: Long = System.currentTimeMillis(),
    val confidence: Float = 0.85f
)
