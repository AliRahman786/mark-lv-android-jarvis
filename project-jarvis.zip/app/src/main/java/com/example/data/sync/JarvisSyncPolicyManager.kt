package com.example.data.sync

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.PowerManager
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkInfo
import androidx.work.WorkManager
import com.example.data.prefs.PreferencesManager
import kotlinx.coroutines.flow.Flow
import java.util.concurrent.TimeUnit

data class DeviceSyncReadiness(
    val isCharging: Boolean,
    val chargingSource: String,
    val isWifiConnected: Boolean,
    val isUnmetered: Boolean,
    val batteryPct: Int,
    val isPowerSaveMode: Boolean,
    val isPolicySatisfied: Boolean,
    val summary: String
)

class JarvisSyncPolicyManager(private val context: Context) {

    private val workManager: WorkManager = WorkManager.getInstance(context)
    private val prefs: PreferencesManager = PreferencesManager(context)

    companion object {
        const val PERIODIC_WORK_NAME = "jarvis_periodic_memory_maintenance_sync"
        const val IMMEDIATE_WORK_NAME = "jarvis_immediate_maintenance_sync"
        const val WORK_TAG_SYNC = "jarvis_sync"
        const val WORK_TAG_BATTERY_OPTIMIZED = "battery_optimized"

        /**
         * Builds battery and network optimized constraints.
         * Default enforces charging + unmetered Wi-Fi + battery not low.
         */
        fun createBatteryOptimizedConstraints(
            requiresCharging: Boolean = true,
            requiresWifi: Boolean = true
        ): Constraints {
            val builder = Constraints.Builder()
                .setRequiresBatteryNotLow(true)

            if (requiresCharging) {
                builder.setRequiresCharging(true)
            }

            if (requiresWifi) {
                builder.setRequiredNetworkType(NetworkType.UNMETERED)
            } else {
                builder.setRequiredNetworkType(NetworkType.CONNECTED)
            }

            return builder.build()
        }
    }

    /**
     * Inspects real-time battery charging and Wi-Fi state against current policy.
     */
    fun checkDeviceReadiness(): DeviceSyncReadiness {
        // Battery status inspection
        var isCharging = false
        var chargingSource = "DISCHARGING"
        var batteryPct = 100

        try {
            val batteryIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            if (batteryIntent != null) {
                val status = batteryIntent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                        status == BatteryManager.BATTERY_STATUS_FULL

                val plugged = batteryIntent.getIntExtra(BatteryManager.EXTRA_PLUGGED, -1)
                chargingSource = when (plugged) {
                    BatteryManager.BATTERY_PLUGGED_AC -> "AC_MAINS"
                    BatteryManager.BATTERY_PLUGGED_USB -> "USB_BUS"
                    BatteryManager.BATTERY_PLUGGED_WIRELESS -> "QI_WIRELESS"
                    else -> if (isCharging) "CHARGING" else "DISCHARGING"
                }

                val level = batteryIntent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val scale = batteryIntent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
                if (level >= 0 && scale > 0) {
                    batteryPct = (level * 100) / scale
                }
            }
        } catch (_: Exception) {}

        // Network status inspection
        var isWifi = false
        var isUnmetered = false

        try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            val activeNetwork = cm?.activeNetwork
            val caps = cm?.getNetworkCapabilities(activeNetwork)
            if (caps != null) {
                isWifi = caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
                isUnmetered = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED) || isWifi
            }
        } catch (_: Exception) {}

        val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        val isPowerSave = powerManager?.isPowerSaveMode == true

        val requiresCharging = prefs.isSyncChargingRequired()
        val requiresWifi = prefs.isSyncWifiRequired()

        val chargingOk = !requiresCharging || isCharging
        val wifiOk = !requiresWifi || (isWifi && isUnmetered)
        val isPolicySatisfied = chargingOk && wifiOk

        val summary = when {
            isPolicySatisfied -> "CONDITIONS OPTIMAL // READY FOR AUTONOMOUS SYNC"
            !chargingOk && !wifiOk -> "AWAITING CHARGER & WI-FI (BATTERY CONSERVATION ACTIVE)"
            !chargingOk -> "AWAITING CHARGER (BATTERY PRESERVATION ACTIVE)"
            else -> "AWAITING UNMETERED WI-FI (CELLULAR CONSERVATION ACTIVE)"
        }

        return DeviceSyncReadiness(
            isCharging = isCharging,
            chargingSource = chargingSource,
            isWifiConnected = isWifi,
            isUnmetered = isUnmetered,
            batteryPct = batteryPct,
            isPowerSaveMode = isPowerSave,
            isPolicySatisfied = isPolicySatisfied,
            summary = summary
        )
    }

    /**
     * Schedules recurring background maintenance and log upload sync.
     * Enforces that maintenance only occurs when charging and on Wi-Fi.
     */
    fun schedulePeriodicMaintenanceSync(repeatHours: Long? = null) {
        val hours = repeatHours ?: prefs.getSyncIntervalHours()
        val reqCharging = prefs.isSyncChargingRequired()
        val reqWifi = prefs.isSyncWifiRequired()

        val constraints = createBatteryOptimizedConstraints(
            requiresCharging = reqCharging,
            requiresWifi = reqWifi
        )

        val periodicRequest = PeriodicWorkRequestBuilder<MemoryMaintenanceSyncWorker>(
            repeatInterval = hours.coerceAtLeast(1L),
            repeatIntervalTimeUnit = TimeUnit.HOURS,
            flexTimeInterval = 30,
            flexTimeIntervalUnit = TimeUnit.MINUTES
        )
            .setConstraints(constraints)
            .addTag(WORK_TAG_SYNC)
            .addTag(WORK_TAG_BATTERY_OPTIMIZED)
            .build()

        workManager.enqueueUniquePeriodicWork(
            PERIODIC_WORK_NAME,
            ExistingPeriodicWorkPolicy.UPDATE,
            periodicRequest
        )
    }

    /**
     * Dispatches an immediate maintenance sync.
     * If [respectConstraints] is true, waits for charging + Wi-Fi.
     * If false, executes immediately for manual user action.
     */
    fun enqueueImmediateSync(respectConstraints: Boolean = true) {
        val reqCharging = if (respectConstraints) prefs.isSyncChargingRequired() else false
        val reqWifi = if (respectConstraints) prefs.isSyncWifiRequired() else false

        val builder = OneTimeWorkRequestBuilder<MemoryMaintenanceSyncWorker>()
            .addTag("jarvis_sync_immediate")

        if (respectConstraints) {
            builder.setConstraints(
                createBatteryOptimizedConstraints(
                    requiresCharging = reqCharging,
                    requiresWifi = reqWifi
                )
            )
        }

        workManager.enqueueUniqueWork(
            IMMEDIATE_WORK_NAME,
            ExistingWorkPolicy.REPLACE,
            builder.build()
        )
    }

    fun cancelAllSyncWork() {
        workManager.cancelUniqueWork(PERIODIC_WORK_NAME)
        workManager.cancelUniqueWork(IMMEDIATE_WORK_NAME)
    }

    fun getPeriodicWorkInfoFlow(): Flow<List<WorkInfo>> {
        return workManager.getWorkInfosForUniqueWorkFlow(PERIODIC_WORK_NAME)
    }

    fun getImmediateWorkInfoFlow(): Flow<List<WorkInfo>> {
        return workManager.getWorkInfosForUniqueWorkFlow(IMMEDIATE_WORK_NAME)
    }
}
