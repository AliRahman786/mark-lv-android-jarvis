package com.example.data.prefs

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class PreferencesManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("jarvis_secure_prefs", Context.MODE_PRIVATE)

    companion object {
        const val KEY_ONBOARDING_COMPLETED = "onboarding_completed"
        const val KEY_AI_PROVIDER = "ai_provider"
        const val KEY_GEMINI_KEY = "gemini_api_key"
        const val KEY_OPENAI_KEY = "openai_api_key"
        const val KEY_GROQ_KEY = "groq_api_key"
        const val KEY_GEMINI_MODEL = "gemini_model"
        const val KEY_OPENAI_MODEL = "openai_model"
        const val KEY_GROQ_MODEL = "groq_model"
        const val KEY_VOICE_IN_PROVIDER = "voice_in_provider"
        const val KEY_VOICE_OUT_PROVIDER = "voice_out_provider"
        const val KEY_ASSISTANT_NAME = "assistant_name"
        const val KEY_USER_NAME = "user_name"
        const val KEY_STORAGE_MODE = "storage_mode"
        const val KEY_CLOUD_SYNC_ENABLED = "cloud_sync_enabled"
        const val KEY_GESTURE_ENABLED = "gesture_enabled"
        const val KEY_GESTURE_SENSITIVITY = "gesture_sensitivity"
        const val KEY_ACCENT_COLOR = "accent_color"
        const val KEY_LAST_SYNC_TIME = "last_sync_time"
        const val KEY_SEARCH_GROUNDING_ENABLED = "search_grounding_enabled"
        const val KEY_MAPS_GROUNDING_ENABLED = "maps_grounding_enabled"
        const val KEY_SYNC_CHARGING_REQUIRED = "sync_charging_required"
        const val KEY_SYNC_WIFI_REQUIRED = "sync_wifi_required"
        const val KEY_SYNC_INTERVAL_HOURS = "sync_interval_hours"
        const val KEY_LAST_SYNC_STATUS = "last_sync_status"
        const val KEY_LAST_SYNC_MAINTAINED_COUNT = "last_sync_maintained_count"
        const val KEY_LAST_SYNC_LOGS_COUNT = "last_sync_logs_count"
        const val KEY_AI_THROTTLING_ENABLED = "ai_throttling_enabled"
        const val KEY_BATTERY_LOW_THRESHOLD = "battery_low_threshold"
        const val KEY_BATTERY_CRITICAL_THRESHOLD = "battery_critical_threshold"

        const val PROVIDER_GEMINI = "GEMINI"
        const val PROVIDER_OPENAI = "OPENAI"
        const val PROVIDER_GROQ = "GROQ"
        const val PROVIDER_ANDROID_NATIVE = "ANDROID_NATIVE"

        const val STORAGE_DEVICE = "DEVICE"
        const val STORAGE_CLOUD_DRIVE = "CLOUD_DRIVE"
    }

    private val _onboardingCompletedFlow = MutableStateFlow(isOnboardingCompleted())
    val onboardingCompletedFlow: StateFlow<Boolean> = _onboardingCompletedFlow.asStateFlow()

    fun isOnboardingCompleted(): Boolean = prefs.getBoolean(KEY_ONBOARDING_COMPLETED, false)
    fun setOnboardingCompleted(completed: Boolean) {
        prefs.edit().putBoolean(KEY_ONBOARDING_COMPLETED, completed).apply()
        _onboardingCompletedFlow.value = completed
    }

    fun getAiProvider(): String = prefs.getString(KEY_AI_PROVIDER, PROVIDER_GEMINI) ?: PROVIDER_GEMINI
    fun setAiProvider(provider: String) {
        prefs.edit().putString(KEY_AI_PROVIDER, provider).apply()
    }

    fun getApiKey(provider: String): String {
        return when (provider) {
            PROVIDER_GEMINI -> prefs.getString(KEY_GEMINI_KEY, "") ?: ""
            PROVIDER_OPENAI -> prefs.getString(KEY_OPENAI_KEY, "") ?: ""
            PROVIDER_GROQ -> prefs.getString(KEY_GROQ_KEY, "") ?: ""
            else -> ""
        }
    }

    fun setApiKey(provider: String, key: String) {
        val prefKey = when (provider) {
            PROVIDER_GEMINI -> KEY_GEMINI_KEY
            PROVIDER_OPENAI -> KEY_OPENAI_KEY
            PROVIDER_GROQ -> KEY_GROQ_KEY
            else -> return
        }
        prefs.edit().putString(prefKey, key).apply()
    }

    fun getModel(provider: String): String {
        return when (provider) {
            PROVIDER_GEMINI -> prefs.getString(KEY_GEMINI_MODEL, "gemini-3.5-flash") ?: "gemini-3.5-flash"
            PROVIDER_OPENAI -> prefs.getString(KEY_OPENAI_MODEL, "gpt-4o") ?: "gpt-4o"
            PROVIDER_GROQ -> prefs.getString(KEY_GROQ_MODEL, "llama-3.3-70b-versatile") ?: "llama-3.3-70b-versatile"
            else -> "gemini-3.5-flash"
        }
    }

    fun setModel(provider: String, model: String) {
        val prefKey = when (provider) {
            PROVIDER_GEMINI -> KEY_GEMINI_MODEL
            PROVIDER_OPENAI -> KEY_OPENAI_MODEL
            PROVIDER_GROQ -> KEY_GROQ_MODEL
            else -> return
        }
        prefs.edit().putString(prefKey, model).apply()
    }

    fun getVoiceInputProvider(): String = prefs.getString(KEY_VOICE_IN_PROVIDER, PROVIDER_ANDROID_NATIVE) ?: PROVIDER_ANDROID_NATIVE
    fun setVoiceInputProvider(provider: String) {
        prefs.edit().putString(KEY_VOICE_IN_PROVIDER, provider).apply()
    }

    fun getVoiceOutputProvider(): String = prefs.getString(KEY_VOICE_OUT_PROVIDER, PROVIDER_ANDROID_NATIVE) ?: PROVIDER_ANDROID_NATIVE
    fun setVoiceOutputProvider(provider: String) {
        prefs.edit().putString(KEY_VOICE_OUT_PROVIDER, provider).apply()
    }

    fun getAssistantName(): String = prefs.getString(KEY_ASSISTANT_NAME, "JARVIS") ?: "JARVIS"
    fun setAssistantName(name: String) {
        prefs.edit().putString(KEY_ASSISTANT_NAME, name).apply()
    }

    fun getUserName(): String = prefs.getString(KEY_USER_NAME, "Tony Stark") ?: "Tony Stark"
    fun setUserName(name: String) {
        prefs.edit().putString(KEY_USER_NAME, name).apply()
    }

    fun getStorageMode(): String = prefs.getString(KEY_STORAGE_MODE, STORAGE_DEVICE) ?: STORAGE_DEVICE
    fun setStorageMode(mode: String) {
        prefs.edit().putString(KEY_STORAGE_MODE, mode).apply()
    }

    fun isCloudSyncEnabled(): Boolean = prefs.getBoolean(KEY_CLOUD_SYNC_ENABLED, false)
    fun setCloudSyncEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_CLOUD_SYNC_ENABLED, enabled).apply()
    }

    fun isGestureEnabled(): Boolean = prefs.getBoolean(KEY_GESTURE_ENABLED, true)
    fun setGestureEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_GESTURE_ENABLED, enabled).apply()
    }

    fun getGestureSensitivity(): Float = prefs.getFloat(KEY_GESTURE_SENSITIVITY, 0.5f)
    fun setGestureSensitivity(sensitivity: Float) {
        prefs.edit().putFloat(KEY_GESTURE_SENSITIVITY, sensitivity).apply()
    }

    fun getAccentColor(): String = prefs.getString(KEY_ACCENT_COLOR, "ARC_AMBER") ?: "ARC_AMBER"
    fun setAccentColor(accent: String) {
        prefs.edit().putString(KEY_ACCENT_COLOR, accent).apply()
    }

    fun getLastSyncTime(): Long = prefs.getLong(KEY_LAST_SYNC_TIME, 0L)
    fun setLastSyncTime(timestamp: Long) {
        prefs.edit().putLong(KEY_LAST_SYNC_TIME, timestamp).apply()
    }

    fun isSearchGroundingEnabled(): Boolean = prefs.getBoolean(KEY_SEARCH_GROUNDING_ENABLED, true)
    fun setSearchGroundingEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_SEARCH_GROUNDING_ENABLED, enabled).apply()
    }

    fun isMapsGroundingEnabled(): Boolean = prefs.getBoolean(KEY_MAPS_GROUNDING_ENABLED, true)
    fun setMapsGroundingEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_MAPS_GROUNDING_ENABLED, enabled).apply()
    }

    // WorkManager Background Sync Policy Preferences
    fun isSyncChargingRequired(): Boolean = prefs.getBoolean(KEY_SYNC_CHARGING_REQUIRED, true)
    fun setSyncChargingRequired(required: Boolean) {
        prefs.edit().putBoolean(KEY_SYNC_CHARGING_REQUIRED, required).apply()
    }

    fun isSyncWifiRequired(): Boolean = prefs.getBoolean(KEY_SYNC_WIFI_REQUIRED, true)
    fun setSyncWifiRequired(required: Boolean) {
        prefs.edit().putBoolean(KEY_SYNC_WIFI_REQUIRED, required).apply()
    }

    fun getSyncIntervalHours(): Long = prefs.getLong(KEY_SYNC_INTERVAL_HOURS, 6L)
    fun setSyncIntervalHours(hours: Long) {
        prefs.edit().putLong(KEY_SYNC_INTERVAL_HOURS, hours).apply()
    }

    fun getLastSyncStatus(): String = prefs.getString(KEY_LAST_SYNC_STATUS, "STANDBY // READY FOR DISPATCH") ?: "STANDBY // READY FOR DISPATCH"
    fun setLastSyncStatus(status: String) {
        prefs.edit().putString(KEY_LAST_SYNC_STATUS, status).apply()
    }

    fun getLastSyncMaintainedCount(): Int = prefs.getInt(KEY_LAST_SYNC_MAINTAINED_COUNT, 0)
    fun setLastSyncMaintainedCount(count: Int) {
        prefs.edit().putInt(KEY_LAST_SYNC_MAINTAINED_COUNT, count).apply()
    }

    fun getLastSyncLogsCount(): Int = prefs.getInt(KEY_LAST_SYNC_LOGS_COUNT, 0)
    fun setLastSyncLogsCount(count: Int) {
        prefs.edit().putInt(KEY_LAST_SYNC_LOGS_COUNT, count).apply()
    }

    // Dynamic AI Battery Throttling Preferences
    fun isAiThrottlingEnabled(): Boolean = prefs.getBoolean(KEY_AI_THROTTLING_ENABLED, true)
    fun setAiThrottlingEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_AI_THROTTLING_ENABLED, enabled).apply()
    }

    fun getBatteryLowThreshold(): Int = prefs.getInt(KEY_BATTERY_LOW_THRESHOLD, 20)
    fun setBatteryLowThreshold(threshold: Int) {
        prefs.edit().putInt(KEY_BATTERY_LOW_THRESHOLD, threshold.coerceIn(5, 50)).apply()
    }

    fun getBatteryCriticalThreshold(): Int = prefs.getInt(KEY_BATTERY_CRITICAL_THRESHOLD, 10)
    fun setBatteryCriticalThreshold(threshold: Int) {
        prefs.edit().putInt(KEY_BATTERY_CRITICAL_THRESHOLD, threshold.coerceIn(1, 20)).apply()
    }

    fun clearAllData() {
        prefs.edit().clear().apply()
        _onboardingCompletedFlow.value = false
    }
}
