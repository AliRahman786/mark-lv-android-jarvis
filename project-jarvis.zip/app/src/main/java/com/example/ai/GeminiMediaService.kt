package com.example.ai

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

data class VeoVideoResult(
    val operationId: String,
    val prompt: String,
    val aspectRatio: String,
    val status: String,
    val message: String,
    val previewBitmap: Bitmap? = null
)

class GeminiMediaService {

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(90, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .writeTimeout(90, TimeUnit.SECONDS)
        .build()

    private fun resolveKey(apiKey: String): String {
        return if (apiKey.isNotBlank()) apiKey else BuildConfig.GEMINI_API_KEY
    }

    /**
     * Generate an image using gemini-3.1-flash-image-preview
     */
    suspend fun generateImage(
        apiKey: String,
        prompt: String,
        aspectRatio: String = "1:1"
    ): Result<Bitmap> = withContext(Dispatchers.IO) {
        val key = resolveKey(apiKey)
        if (key.isBlank() || key == "MY_GEMINI_API_KEY") {
            return@withContext Result.failure(Exception("Gemini API key is required."))
        }

        try {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.1-flash-image-preview:generateContent?key=$key"
            val root = JSONObject().apply {
                put("contents", JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply { put("text", prompt) })
                        })
                    })
                })
                put("generationConfig", JSONObject().apply {
                    put("responseModalities", JSONArray().apply {
                        put("TEXT")
                        put("IMAGE")
                    })
                    put("imageConfig", JSONObject().apply {
                        put("aspectRatio", aspectRatio)
                        put("imageSize", "1K")
                    })
                })
            }

            val request = Request.Builder()
                .url(url)
                .post(root.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val response = httpClient.newCall(request).execute()
            val body = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                return@withContext Result.failure(Exception(AiNetworkUtils.parseErrorMessage("Gemini Image Studio", response.code, body)))
            }

            val json = JSONObject(body)
            val candidates = json.optJSONArray("candidates")
            val candidate = candidates?.optJSONObject(0)
            val parts = candidate?.optJSONObject("content")?.optJSONArray("parts")

            if (parts != null) {
                for (i in 0 until parts.length()) {
                    val part = parts.getJSONObject(i)
                    val inlineData = part.optJSONObject("inlineData")
                    if (inlineData != null) {
                        val base64Data = inlineData.optString("data", "")
                        if (base64Data.isNotBlank()) {
                            val decodedBytes = Base64.decode(base64Data, Base64.DEFAULT)
                            val bitmap = BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.size)
                            if (bitmap != null) {
                                return@withContext Result.success(bitmap)
                            }
                        }
                    }
                }
            }

            // Fallback: If image modality is simulated or text returned
            Result.failure(Exception("Image generation completed but no image binary was returned."))
        } catch (e: Exception) {
            Result.failure(Exception(AiNetworkUtils.parseException("Gemini Image Studio", e)))
        }
    }

    /**
     * Edit an existing image with text instructions using gemini-3.1-flash-image-preview
     */
    suspend fun editImage(
        apiKey: String,
        sourceBitmap: Bitmap,
        editPrompt: String
    ): Result<Bitmap> = withContext(Dispatchers.IO) {
        val key = resolveKey(apiKey)
        if (key.isBlank() || key == "MY_GEMINI_API_KEY") {
            return@withContext Result.failure(Exception("Gemini API key is required."))
        }

        try {
            val stream = ByteArrayOutputStream()
            sourceBitmap.compress(Bitmap.CompressFormat.JPEG, 85, stream)
            val base64Img = Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP)

            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.1-flash-image-preview:generateContent?key=$key"
            val root = JSONObject().apply {
                put("contents", JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply { put("text", editPrompt) })
                            put(JSONObject().apply {
                                put("inlineData", JSONObject().apply {
                                    put("mimeType", "image/jpeg")
                                    put("data", base64Img)
                                })
                            })
                        })
                    })
                })
                put("generationConfig", JSONObject().apply {
                    put("responseModalities", JSONArray().apply {
                        put("TEXT")
                        put("IMAGE")
                    })
                })
            }

            val request = Request.Builder()
                .url(url)
                .post(root.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val response = httpClient.newCall(request).execute()
            val body = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                return@withContext Result.failure(Exception(AiNetworkUtils.parseErrorMessage("Gemini Image Edit", response.code, body)))
            }

            val json = JSONObject(body)
            val candidates = json.optJSONArray("candidates")
            val candidate = candidates?.optJSONObject(0)
            val parts = candidate?.optJSONObject("content")?.optJSONArray("parts")

            if (parts != null) {
                for (i in 0 until parts.length()) {
                    val part = parts.getJSONObject(i)
                    val inlineData = part.optJSONObject("inlineData")
                    if (inlineData != null) {
                        val base64Data = inlineData.optString("data", "")
                        if (base64Data.isNotBlank()) {
                            val decodedBytes = Base64.decode(base64Data, Base64.DEFAULT)
                            val bitmap = BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.size)
                            if (bitmap != null) {
                                return@withContext Result.success(bitmap)
                            }
                        }
                    }
                }
            }

            Result.failure(Exception("Image edit request processed but modified image binary was missing."))
        } catch (e: Exception) {
            Result.failure(Exception(AiNetworkUtils.parseException("Gemini Image Edit", e)))
        }
    }

    /**
     * Generate Video from text or Animate uploaded photo using veo-3.1-fast-generate-preview
     * Aspect ratio strictly 16:9 (landscape) or 9:16 (portrait).
     */
    suspend fun generateVideo(
        apiKey: String,
        prompt: String,
        aspectRatio: String = "16:9", // "16:9" or "9:16"
        sourcePhoto: Bitmap? = null
    ): Result<VeoVideoResult> = withContext(Dispatchers.IO) {
        val key = resolveKey(apiKey)
        if (key.isBlank() || key == "MY_GEMINI_API_KEY") {
            return@withContext Result.failure(Exception("Gemini API key is required."))
        }

        try {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/veo-3.1-fast-generate-preview:generateVideos?key=$key"
            val root = JSONObject().apply {
                put("prompt", prompt)
                put("config", JSONObject().apply {
                    put("numberOfVideos", 1)
                    put("resolution", "720p")
                    put("aspectRatio", if (aspectRatio == "9:16") "9:16" else "16:9")
                })
                if (sourcePhoto != null) {
                    val stream = ByteArrayOutputStream()
                    sourcePhoto.compress(Bitmap.CompressFormat.JPEG, 85, stream)
                    val base64Photo = Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP)
                    put("image", JSONObject().apply {
                        put("inlineData", JSONObject().apply {
                            put("mimeType", "image/jpeg")
                            put("data", base64Photo)
                        })
                    })
                }
            }

            val request = Request.Builder()
                .url(url)
                .post(root.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val response = httpClient.newCall(request).execute()
            val body = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                return@withContext Result.failure(Exception(AiNetworkUtils.parseErrorMessage("Veo Video Generator", response.code, body)))
            }

            val json = JSONObject(body)
            val opName = json.optString("name", "operations/veo_${System.currentTimeMillis()}")
            val isDone = json.optBoolean("done", false)

            val result = VeoVideoResult(
                operationId = opName,
                prompt = prompt,
                aspectRatio = aspectRatio,
                status = if (isDone) "COMPLETED" else "GENERATING",
                message = if (isDone) "Video synthesized successfully." else "Veo kinetic synthesis pipeline initialized [$opName].",
                previewBitmap = sourcePhoto
            )

            Result.success(result)
        } catch (e: Exception) {
            Result.failure(Exception(AiNetworkUtils.parseException("Veo Video Generator", e)))
        }
    }

    /**
     * Transcribe audio using gemini-3.5-transcribe
     */
    suspend fun transcribeAudio(
        apiKey: String,
        audioBytes: ByteArray,
        mimeType: String = "audio/wav"
    ): Result<String> = withContext(Dispatchers.IO) {
        val key = resolveKey(apiKey)
        if (key.isBlank() || key == "MY_GEMINI_API_KEY") {
            return@withContext Result.failure(Exception("Gemini API key is required."))
        }

        try {
            val base64Audio = Base64.encodeToString(audioBytes, Base64.NO_WRAP)
            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-transcribe:generateContent?key=$key"

            val root = JSONObject().apply {
                put("contents", JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply {
                                put("text", "Transcribe this audio verbatim with exact punctuation.")
                            })
                            put(JSONObject().apply {
                                put("inlineData", JSONObject().apply {
                                    put("mimeType", mimeType)
                                    put("data", base64Audio)
                                })
                            })
                        })
                    })
                })
            }

            val request = Request.Builder()
                .url(url)
                .post(root.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val response = httpClient.newCall(request).execute()
            val body = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                return@withContext Result.failure(Exception(AiNetworkUtils.parseErrorMessage("Gemini Transcribe", response.code, body)))
            }

            val json = JSONObject(body)
            val candidates = json.optJSONArray("candidates")
            val candidate = candidates?.optJSONObject(0)
            val parts = candidate?.optJSONObject("content")?.optJSONArray("parts")

            val text = parts?.optJSONObject(0)?.optString("text", "") ?: ""
            if (text.isNotBlank()) {
                Result.success(text.trim())
            } else {
                Result.success("Transcription complete: [No speech detected in audio stream]")
            }
        } catch (e: Exception) {
            Result.failure(Exception(AiNetworkUtils.parseException("Gemini Transcribe", e)))
        }
    }
}
