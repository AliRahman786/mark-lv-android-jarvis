package com.example.ai

import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GeminiProvider : AiProvider {
    override val id: String = "GEMINI"
    override val displayName: String = "Google Gemini"
    override val supportedModels: List<String> = listOf(
        "gemini-3.5-flash",
        "gemini-3.1-pro-preview",
        "gemini-3.1-flash-lite-preview",
        "gemini-3.8-live",
        "gemini-2.5-flash"
    )
    override val defaultModel: String = "gemini-3.5-flash"

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private fun resolveKey(apiKey: String): String {
        return if (apiKey.isNotBlank()) apiKey else BuildConfig.GEMINI_API_KEY
    }

    override suspend fun testConnection(apiKey: String, model: String): Result<String> = withContext(Dispatchers.IO) {
        val key = resolveKey(apiKey)
        if (key.isBlank() || key == "MY_GEMINI_API_KEY") {
            return@withContext Result.failure(Exception("Gemini API key is required. Please enter a valid key."))
        }

        try {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$key"
            val json = JSONObject().apply {
                put("contents", JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply { put("text", "JARVIS online test. Respond with: READY.") })
                        })
                    })
                })
            }

            val request = Request.Builder()
                .url(url)
                .post(json.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val response = httpClient.newCall(request).execute()
            val body = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                val errorMsg = AiNetworkUtils.parseErrorMessage("Gemini", response.code, body)
                return@withContext Result.failure(Exception(errorMsg))
            }

            Result.success("Gemini $model connection verified successfully.")
        } catch (e: Exception) {
            Result.failure(Exception(AiNetworkUtils.parseException("Gemini", e)))
        }
    }

    override suspend fun generateResponse(
        apiKey: String,
        model: String,
        messages: List<ChatMessage>,
        systemInstruction: String,
        tools: List<ToolDefinition>
    ): Result<AiResponse> = withContext(Dispatchers.IO) {
        val key = resolveKey(apiKey)
        if (key.isBlank() || key == "MY_GEMINI_API_KEY") {
            return@withContext Result.failure(Exception("Gemini API key is not configured."))
        }

        try {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$key"
            val root = JSONObject()

            // System instruction
            if (systemInstruction.isNotBlank()) {
                root.put("systemInstruction", JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply { put("text", systemInstruction) })
                    })
                })
            }

            // Tools declaration (Subsystem function calls + Google Search & Maps Grounding)
            val toolsArray = JSONArray()
            if (tools.isNotEmpty()) {
                val funcDecls = JSONArray()
                for (tool in tools) {
                    val decl = JSONObject().apply {
                        put("name", tool.name)
                        put("description", tool.description)
                        val paramsObj = JSONObject().apply {
                            put("type", "OBJECT")
                            val props = JSONObject()
                            val req = JSONArray()
                            for (p in tool.parameters) {
                                props.put(p.name, JSONObject().apply {
                                    put("type", p.type.uppercase())
                                    put("description", p.description)
                                })
                                if (p.required) req.put(p.name)
                            }
                            put("properties", props)
                            if (req.length() > 0) put("required", req)
                        }
                        put("parameters", paramsObj)
                    }
                    funcDecls.put(decl)
                }
                toolsArray.put(JSONObject().apply { put("functionDeclarations", funcDecls) })
            }

            // Grounding with Google Search and Google Maps for up-to-date accurate intelligence
            if (!model.contains("live")) {
                toolsArray.put(JSONObject().apply { put("googleSearch", JSONObject()) })
                toolsArray.put(JSONObject().apply { put("googleMaps", JSONObject()) })
            }

            if (toolsArray.length() > 0) {
                root.put("tools", toolsArray)
            }

            // Contents
            val contentsArray = JSONArray()
            for (msg in messages) {
                val contentObj = JSONObject()
                contentObj.put("role", if (msg.role == "assistant") "model" else "user")
                val parts = JSONArray()

                if (msg.imageUrlBase64 != null) {
                    parts.put(JSONObject().apply {
                        put("inlineData", JSONObject().apply {
                            put("mimeType", "image/jpeg")
                            put("data", msg.imageUrlBase64)
                        })
                    })
                }

                if (msg.content.isNotBlank()) {
                    parts.put(JSONObject().apply {
                        put("text", msg.content)
                    })
                }

                contentObj.put("parts", parts)
                contentsArray.put(contentObj)
            }
            root.put("contents", contentsArray)

            val request = Request.Builder()
                .url(url)
                .post(root.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val response = httpClient.newCall(request).execute()
            val body = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                val errorMsg = AiNetworkUtils.parseErrorMessage("Gemini", response.code, body)
                return@withContext Result.failure(Exception(errorMsg))
            }

            val respJson = JSONObject(body)
            val candidates = respJson.optJSONArray("candidates")
            if (candidates == null || candidates.length() == 0) {
                return@withContext Result.success(AiResponse("Diagnostic: Empty response from Gemini core."))
            }

            val firstCandidate = candidates.getJSONObject(0)
            val content = firstCandidate.optJSONObject("content")
            val parts = content?.optJSONArray("parts")

            var responseText = ""
            val toolCalls = mutableListOf<ToolCallRequest>()

            if (parts != null) {
                for (i in 0 until parts.length()) {
                    val part = parts.getJSONObject(i)
                    if (part.has("text")) {
                        responseText += part.getString("text")
                    }
                    if (part.has("functionCall")) {
                        val fn = part.getJSONObject("functionCall")
                        val fnName = fn.optString("name")
                        val fnArgs = fn.optJSONObject("args")?.toString() ?: "{}"
                        toolCalls.add(ToolCallRequest(id = "gemini_call_$i", name = fnName, argumentsJson = fnArgs))
                    }
                }
            }

            // Extract Google Search / Maps Grounding Metadata if returned
            val groundingMetadata = firstCandidate.optJSONObject("groundingMetadata")
            if (groundingMetadata != null) {
                val searchQueries = groundingMetadata.optJSONArray("webSearchQueries")
                if (searchQueries != null && searchQueries.length() > 0) {
                    val queries = mutableListOf<String>()
                    for (q in 0 until searchQueries.length()) {
                        queries.add("\"${searchQueries.getString(q)}\"")
                    }
                    responseText += "\n\n[GOOGLE SEARCH GROUNDING: ${queries.joinToString(", ")}]"
                }
            }

            Result.success(AiResponse(text = responseText.trim(), toolCalls = toolCalls))
        } catch (e: Exception) {
            Result.failure(Exception(AiNetworkUtils.parseException("Gemini", e)))
        }
    }

    override suspend fun generateStream(
        apiKey: String,
        model: String,
        messages: List<ChatMessage>,
        systemInstruction: String,
        tools: List<ToolDefinition>,
        onChunk: (String) -> Unit
    ): Result<AiResponse> {
        // Fallback to generateResponse and stream output to listener
        val res = generateResponse(apiKey, model, messages, systemInstruction, tools)
        if (res.isSuccess) {
            val text = res.getOrNull()?.text ?: ""
            onChunk(text)
        }
        return res
    }
}
