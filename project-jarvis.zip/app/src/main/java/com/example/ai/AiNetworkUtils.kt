package com.example.ai

import org.json.JSONObject
import java.net.SocketTimeoutException
import java.net.UnknownHostException

object AiNetworkUtils {

    fun parseErrorMessage(providerName: String, code: Int, body: String): String {
        val detail = try {
            val json = JSONObject(body)
            json.optJSONObject("error")?.optString("message")
                ?: json.optString("message", "")
        } catch (_: Exception) {
            ""
        }.ifBlank { "HTTP $code" }

        return when (code) {
            429 -> "[$providerName Rate Limit Exceeded // 429] $detail"
            401, 403 -> "[$providerName Authentication Failed // $code] Invalid API key or permission denied."
            404 -> "[$providerName Model Not Found // 404] $detail"
            500, 502, 503, 504 -> "[$providerName Server Outage // $code] Neural servers temporarily unavailable. Please retry."
            else -> "[$providerName Error // $code] $detail"
        }
    }

    fun parseException(providerName: String, e: Exception): String {
        return when (e) {
            is SocketTimeoutException -> "[$providerName Timeout] Network connection timed out. Check connectivity."
            is UnknownHostException -> "[$providerName Offline] Unable to reach network servers. Ensure device is online."
            else -> "[$providerName Network Error] ${e.localizedMessage ?: "Unknown communication failure"}"
        }
    }
}
