package com.example.ai

interface AiProvider {
    val id: String
    val displayName: String
    val supportedModels: List<String>
    val defaultModel: String

    suspend fun testConnection(apiKey: String, model: String): Result<String>

    suspend fun generateResponse(
        apiKey: String,
        model: String,
        messages: List<ChatMessage>,
        systemInstruction: String,
        tools: List<ToolDefinition>
    ): Result<AiResponse>

    suspend fun generateStream(
        apiKey: String,
        model: String,
        messages: List<ChatMessage>,
        systemInstruction: String,
        tools: List<ToolDefinition>,
        onChunk: (String) -> Unit
    ): Result<AiResponse>
}
