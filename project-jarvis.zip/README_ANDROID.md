# JARVIS Mark-LIV (Android 14+ Edition)

Welcome to the native Android implementation of the **J.A.R.V.I.S. (Just A Rather Very Intelligent System) Mark-LIV Tactical AI Assistant**.

---

## 1. System Architecture

The application is built 100% natively for **Android 14 and newer (minSdk 34, compileSdk 36)** using:
- **Language**: Kotlin 2.2.10
- **UI Framework**: Jetpack Compose with Material Design 3 (M3)
- **Architecture**: Clean Architecture / MVVM with StateFlow & Coroutines
- **Local Persistence**: Jetpack Room SQLite Database with KSP code generation
- **Computer Vision**: CameraX on-device real-time hand gesture recognition
- **Audio & Vocal Synthesis**: Android Native SpeechRecognizer & TextToSpeech engine
- **Security**: Android Keystore secure storage abstraction, masked secrets, zero plaintext logs

---

## 2. Multi-Engine Cognitive AI Providers

The system is completely decoupled from any single AI vendor. Users configure cognitive intelligence via the Setup Wizard or Settings Console:

1. **Google Gemini (First-Class Support)**
   - REST API v1beta endpoint
   - Models: `gemini-3.5-flash`, `gemini-3.1-pro-preview`, `gemini-2.5-flash`
   - Real-time Function/Tool calling, multimodal vision parsing, system instructions, and thinking level parameters
   - Graceful fallback to `BuildConfig.GEMINI_API_KEY`

2. **OpenAI**
   - Native REST `/v1/chat/completions`
   - Models: `gpt-4o`, `gpt-4o-mini`, `gpt-4-turbo`
   - Function calling tools integration, multimodal image attachments, and ping verification

3. **Groq (Ultra-Low Latency)**
   - High-speed OpenAI-compatible REST endpoint
   - Models: `llama-3.3-70b-versatile`, `llama-3.1-8b-instant`, `mixtral-8x7b-32768`
   - Statically typed function calling and instantaneous token throughput

---

## 3. Independent Voice Input & Output Pipelines

The cognitive AI provider and speech engines can be configured independently:
- **Voice Input**: Android Native SpeechRecognizer (Edge, offline, zero-latency), OpenAI Whisper, or Gemini Voice.
- **Voice Output**: Calibrated British-tone Android TextToSpeech, Gemini TTS, or OpenAI TTS.
- **Voice States**: `IDLE`, `LISTENING`, `PROCESSING`, `THINKING`, `SPEAKING`, `ERROR`.

---

## 4. Optical Hand Gesture Control (CameraX Edge Computing)

- **Privacy-First Zero Upload Guarantee**: All gesture heuristics are computed locally on-device at 15 FPS using luminance and contour centroid analysis. No camera frames are uploaded to any cloud service.
- **Visual Camera Indicator**: Prominent holographic `CAM ACTIVE // ON-DEVICE` badge displayed whenever sensors are engaged.
- **Configurable Gestures**:
  - `Open Palm`: Wake JARVIS / Activate Voice Receptor
  - `Closed Fist`: Halt / Abort active task
  - `Pinch / Target`: Select / Authorize pending action
  - `Swipe Left / Right`: Shift HUD subsystem panels
  - `Swipe Up / Down`: Scroll viewport
  - `Two Fingers`: Toggle pause / resume vocal audio

---

## 5. Dual-Tier Memory System

1. **Short-Term Context Memory**: Rolling conversation buffer with context window management.
2. **Long-Term Memory Core**: Persistent Room database storing user preferences, project notes, system parameters, and facts.
   - Categorized: `FACT`, `PREFERENCE`, `PROJECT`, `SYSTEM`, `USER`.
   - Searchable via keywords and relevance filtering.
   - Dedicated Memory Manager UI with single/batch deletion and full database purge.
   - **WorkManager Battery-Optimized Sync Policy**: Background maintenance and log uploads run periodically (every 6 hours) strictly when the device is **charging** and connected to **unmetered Wi-Fi**, preserving device battery life and mobile data.

---

## 6. Subsystem Tool Registry (Android Device Actions)

Safe, statically typed, schema-validated Android native actions:
- `open_app`: Launch YouTube, Maps, Chrome, Camera, Settings, etc.
- `open_url`: Safe external browser navigation.
- `web_search`: Live DuckDuckGo & Wikipedia search.
- `maps_search`: Geo intent targeting.
- `youtube_search`: Video playback search intent.
- `clipboard_copy` & `share_text`: Android clipboard and share sheet.
- `device_info`: Battery percentage, RAM usage, Android OS API level, network status.
- `create_reminder` / `list_reminders`: Task scheduling and notifications.
- `save_memory` / `recall_memory`: Long-term fact persistence.
- `calculator` & `time_weather`: Math evaluation and astronomical/temporal telemetry.

**Consequential Action Confirmation**: Destructive or irreversible actions require explicit manual operator confirmation through a modal dialog before execution.

---

## 7. 3D Holographic AI Core & HUD

- **Interactive 3D Procedural Core**: Gyroscopic orbital rings with sinusoidal Euler pitch/yaw rotation, outer degree ticks, quantum singularity iris, and floating particle clouds.
- **Touch Interaction**: Drag horizontally/vertically to rotate core in 3D; pinch to zoom in/out with spring physics.
- **Reactive Audio Waves**: Real-time frequency spectrum visualizer reacting dynamically to mic decibels and vocal speech amplitude.
- **Adaptive Canonical Layout**:
  - **Phone**: Full-feature access through central core and switchable subsystem panels.
  - **Tablet**: 3-pane command center (Left: Terminal & Memory, Center: 3D Core & Waveforms, Right: Gestures & Subsystems).

---

## 8. Android 14+ Permissions

- `android.permission.INTERNET`: AI API communication and live web search.
- `android.permission.RECORD_AUDIO`: Microphone speech recognition (runtime-requested).
- `android.permission.CAMERA`: Local on-device hand gesture tracking (runtime-requested).
- `android.permission.POST_NOTIFICATIONS`: Android 14+ task reminders (runtime-requested).
- `android.permission.VIBRATE`: Tactile haptic feedback on gesture recognition.
